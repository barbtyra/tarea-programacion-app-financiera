// Playwright sólo de QA: instalado fuera del proyecto, en TEMP.
const fs=require('fs'), path=require('path'), assert=require('assert/strict');
const {chromium}=require(path.join(process.env.TEMP,'balance-fase3-browser','node_modules','playwright'));
const axe=fs.readFileSync(path.join(process.env.TEMP,'balance-fase3-browser','node_modules','axe-core','axe.min.js'),'utf8');
const cfg=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const faults=[], results=[];
async function main(){
  const browser=await chromium.launch({executablePath:'C:/Program Files/BraveSoftware/Brave-Browser/Application/brave.exe',headless:true});
  try {
    const context=await browser.newContext({viewport:{width:1440,height:1000},locale:'es-PY', reducedMotion:'reduce'});
    const page=await context.newPage();
    page.on('pageerror',e=>faults.push({javascript:e.message}));
    page.on('response',r=>{if(r.status()>=500)faults.push({http:r.status(),url:r.url()});});
    await page.goto(cfg.base+'/login');
    await page.locator('[name=email]').fill(cfg.email);
    await page.locator('[name=password]').fill('ContraseñaIncorrecta');
    await Promise.all([page.waitForNavigation(),page.getByRole('button',{name:'Iniciar sesión'}).click()]);
    assert.equal(await page.locator('[name=email]').inputValue(),cfg.email);
    assert.equal(await page.locator('[name=password]').inputValue(),'');
    await page.locator('[name=password]').fill(cfg.password);
    await Promise.all([page.waitForNavigation(),page.getByRole('button',{name:'Iniciar sesión'}).click()]);
    assert.equal(new URL(page.url()).pathname,'/');
    results.push('Autenticación real: correo conservado, contraseña excluida y sesión válida');
    const routes=[['resumen','/'],['cuentas','/cuentas'],['historial','/historial'],['gasto','/gastos'],
      ['ingreso','/ingresos'],['transferencia','/transferencias'],['debito','/tarjetas-debito'],['credito','/tarjetas-credito'],
      ['cuotas','/tarjetas-credito/'+cfg.card],['facturas','/facturas'],['deudas','/deudas'],['presupuesto','/presupuesto'],
      ['metas','/metas'],['grupos','/grupos'],['grupo','/grupos/'+cfg.group],['vaquita','/vaquitas/'+cfg.pool],
      ['reportes','/reportes'],['configuracion','/configuracion'],['categorias','/categorias'],['detalle','/movimientos/'+cfg.tx],
      ['edicion','/movimientos/'+cfg.tx+'/editar']];
    for(const width of [375,768,1440]){
      await page.setViewportSize({width,height:width===375?812:1000});
      for(const [label,route] of routes){
        const response=await page.goto(cfg.base+route);assert.equal(response.status(),200,route);
        await page.locator('h1').waitFor();
        // Abrir detalles para comprobar también tablas/formularios desplegables.
        if(['cuotas','cuentas','metas','facturas','debito'].includes(label))
          await page.locator('details').evaluateAll(nodes=>nodes.forEach(el=>el.open=true));
        const metrics=await page.evaluate(()=>{
          const width=innerWidth;
          return {width,scroll:document.documentElement.scrollWidth,
            overflow:[...document.querySelectorAll('main *')].filter(el=>{
              if(el.closest('.table-scroll')||el.closest('dialog:not([open])'))return false;
              const r=el.getBoundingClientRect();return r.width>0&&(r.right>width+1||r.left< -1);
            }).slice(0,8).map(el=>({tag:el.tagName,cls:el.className,text:el.textContent.slice(0,55)}))};
        });
        if(metrics.scroll>width+1)faults.push({route,width,layout:metrics});
        if(width===1440&&['resumen','gasto','configuracion','presupuesto'].includes(label)){
          await page.evaluate(axe);
          const a11y=await page.evaluate(async()=>{
            const result=await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa']}});
            return result.violations.map(v=>({rule:v.id,impact:v.impact,nodes:v.nodes.slice(0,3).map(n=>({selector:n.target,detail:n.failureSummary}))}));
          });
          for(const item of a11y)faults.push({route,accessibility:item});
        }
        await page.screenshot({path:path.join(cfg.output,`${label}-${width}.png`),fullPage:true});
      }
      results.push(`${routes.length} pantallas reales capturadas a ${width}px`);
    }
    await page.setViewportSize({width:375,height:812});
    await page.goto(cfg.base+'/gastos');
    await page.locator('[name=amount]').fill('125.50');
    await page.locator('[name=description]').fill('Formulario que debe conservarse');
    await page.locator('[name=payment_method]').selectOption('ACCOUNT:'+cfg.cash);
    await page.locator('[name=payment_amount]').fill('100');
    await page.getByRole('button',{name:'Agregar otro medio'}).click();
    await page.locator('[name=payment_method]').nth(1).selectOption('ACCOUNT:'+cfg.bank);
    await page.locator('[name=payment_amount]').nth(1).fill('20');
    await Promise.all([page.waitForNavigation(),page.getByRole('button',{name:'Guardar gasto'}).click()]);
    assert.equal(await page.locator('.mensaje.error').count(),1);
    assert.equal(await page.locator('[name=description]').inputValue(),'Formulario que debe conservarse');
    assert.deepEqual(await page.locator('[name=payment_amount]').evaluateAll(xs=>xs.map(x=>x.value)),['100','20']);
    await page.screenshot({path:path.join(cfg.output,'formulario-error-375.png'),fullPage:true});
    await page.reload();
    assert.equal(await page.locator('[name=description]').inputValue(),'Formulario que debe conservarse');
    results.push('Formulario real conserva importes y múltiples medios ante error y recarga');
    await page.goto(cfg.base+'/movimientos/'+cfg.tx);
    const voidForm=page.locator('form[action$="/anular"]');
    await voidForm.locator('[name=reason]').fill('Prueba de diálogo, se cancelará');
    await voidForm.locator('button').click();
    await page.locator('#confirm-dialog[open]').waitFor();
    await page.screenshot({path:path.join(cfg.output,'confirmacion-375.png'),fullPage:true});
    await page.locator('#confirm-cancel').click();
    assert.equal(await page.locator('#confirm-dialog[open]').count(),0);
    results.push('Confirmación real: cancelar no envía la operación');
    await page.locator('.menu-toggle').click();
    assert.equal(await page.locator('.menu-toggle').getAttribute('aria-expanded'),'true');
    assert(await page.evaluate(()=>!!document.activeElement.closest('.sidebar')));
    assert(await page.locator('.app-shell').evaluate(el=>el.inert));
    await page.locator('.sidebar a').last().focus();await page.keyboard.press('Tab');
    assert(await page.locator('.sidebar a').first().evaluate(el=>el===document.activeElement));
    await page.screenshot({path:path.join(cfg.output,'menu-375.png'),fullPage:true});
    await page.keyboard.press('Escape');
    assert.equal(await page.locator('.menu-toggle').getAttribute('aria-expanded'),'false');
    assert(await page.locator('.menu-toggle').evaluate(el=>el===document.activeElement));
    // Un menú cerrado debe quedar fuera del recorrido de teclado.
    await page.goto(cfg.base+'/');
    await page.keyboard.press('Tab'); await page.keyboard.press('Tab');
    if(await page.evaluate(()=>!!document.activeElement.closest('.sidebar')))
      faults.push({accessibility:'El menú móvil cerrado recibe foco de teclado'});
    results.push('Menú móvil: apertura/cierre comprobados');
    fs.writeFileSync(path.join(cfg.output,'navegador-resultados.json'),JSON.stringify({results,faults},null,2));
    await page.setViewportSize({width:1440,height:1000});
    assert.equal(await page.locator('.sidebar').evaluate(el=>el.inert),false);
    // Verificar que una interrupción después del COMMIT se recupera sin duplicar.
    await page.goto(cfg.base+'/gastos');
    for(const button of await page.getByRole('button',{name:'Quitar medio de pago'}).all())await button.click();
    await page.locator('[name=amount]').fill('52.37');
    await page.locator('[name=payment_method]').selectOption('ACCOUNT:'+cfg.cash);
    await page.locator('[name=payment_amount]').fill('52.37');
    await page.locator('[name=description]').fill('Respuesta interrumpida fase 3');
    const requestKey=await page.locator('form[method=post] [name=_request_id]').inputValue();
    const cookiesBefore=await context.cookies();
    await page.route('**/gastos',async route=>{
      if(route.request().method()!=='POST')return route.continue();
      await route.fetch({maxRedirects:0}); // El servidor ya confirmó la escritura.
      // route.fetch comparte cookies: retirar la cabecera que el cliente no recibió.
      await context.addCookies(cookiesBefore);
      await route.abort('failed');
    });
    await Promise.all([page.waitForEvent('requestfailed',{predicate:r=>r.method()==='POST'&&r.url().endsWith('/gastos')}),page.getByRole('button',{name:'Guardar gasto'}).click()]);
    await page.unroute('**/gastos');
    await page.goto(cfg.base+'/gastos');
    assert.equal(await page.locator('[name=description]').inputValue(),'Respuesta interrumpida fase 3');
    assert.equal(await page.locator('form[method=post] [name=_request_id]').inputValue(),requestKey);
    await Promise.all([page.waitForNavigation(),page.getByRole('button',{name:'Guardar gasto'}).click()]);
    results.push('Respuesta interrumpida: borrador y clave recuperados; reintento confirmado por servidor');
    // Contraste y disposición del tema oscuro guardado en MariaDB.
    await page.goto(cfg.base+'/configuracion');
    await page.locator('[name=theme]').selectOption('dark');
    await Promise.all([page.waitForNavigation(),page.getByRole('button',{name:'Guardar preferencias y perfil'}).click()]);
    assert.equal(await page.locator('html').getAttribute('data-theme'),'dark');
    await page.goto(cfg.base+'/');
    await page.screenshot({path:path.join(cfg.output,'resumen-oscuro-1440.png'),fullPage:true});
    await page.evaluate(axe);
    const dark=await page.evaluate(async()=>(await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa']}})).violations.map(v=>({rule:v.id,nodes:v.nodes.slice(0,3).map(n=>({selector:n.target,detail:n.failureSummary}))})));
    for(const item of dark)faults.push({theme:'dark',accessibility:item});
    results.push('Tema oscuro persistido y capturado');
    fs.writeFileSync(path.join(cfg.output,'navegador-resultados.json'),JSON.stringify({results,faults},null,2));
    console.log(JSON.stringify({results,faults},null,2));
    assert.equal(faults.length,0,'La revisión de navegador detectó incidencias');
  } finally {await browser.close();}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
