"""Pruebas reales HTTP/MariaDB en una base temporal vacía, eliminada al terminar."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import date,timedelta
from decimal import Decimal
from urllib.error import HTTPError,URLError
from urllib.parse import urlencode
from urllib.request import urlopen
from uuid import uuid4

import mysql.connector

ROOT=Path(__file__).resolve().parent
BASE='http://127.0.0.1:5001'
TODAY=date.today()
RESULTS=[]


def ok(message):
    RESULTS.append(message)
    print('OK:',message,flush=True)


def run_tests():
    import verificar_fase1 as anterior
    anterior.BASE=BASE
    original=anterior.Cliente.pedir

    def pedir(self,path,data=None,error=False):
        if data is not None:
            if not getattr(self,'csrf',None):self.pedir('/login')
            data=dict(data);data.setdefault('_csrf',self.csrf);data.setdefault('_request_id',str(uuid4()))
        result=original(self,path,data,error)
        found=re.search(r'name="_csrf" value="([^"]+)"',result)
        if found:self.csrf=found[1]
        self.last_html=result
        return result
    anterior.Cliente.pedir=pedir
    C=anterior.Cliente;one=anterior.uno;sql=anterior.sql;balance=anterior.saldo
    anterior.probar()
    ok('Compatibilidad: todos los flujos de fase 1 sobre la nueva aplicación')
    from conexion import obtener_conexion
    from finanzas import (consultar,ciclo,dinero,estado_ciclos,estado_deuda,saldo_credito,sumar_meses)
    from automatizacion import automatizar
    from analitica import eventos,panel

    def fresh():
        client=C();user=client.registrar()
        cash=one("SELECT id FROM accounts WHERE user_id=%s AND type='CASH'",(user,))['id']
        return client,user,cash

    def scalar(query,args=()):return one(query,args)['n']
    income_cat=one("SELECT id FROM categories WHERE kind='INCOME' AND user_id IS NULL LIMIT 1")['id']
    expense_cat=one("SELECT id FROM categories WHERE kind='EXPENSE' AND user_id IS NULL LIMIT 1")['id']
    c,user,cash=fresh()

    def income(client,account,amount,description,on=TODAY):
        client.pedir('/ingresos',{'account_id':account,'category_id':income_cat,'amount':str(amount),'description':description,'occurred_at':on.isoformat()})

    def expense(client,who,account,amount,description,on=TODAY,extra=None):
        payload={'category_id':expense_cat,'amount':str(amount),'description':description,'occurred_at':on.isoformat(),'payment_method':'ACCOUNT:'+account,'payment_amount':str(amount),'installment_count':'1'}
        payload.update(extra or {})
        client.pedir('/gastos',payload)
        return one('SELECT id FROM financial_transactions WHERE user_id=%s AND description=%s',(who,description))['id']

    def raw_post(client,path,payload):
        payload={'_csrf':client.csrf,'_request_id':str(uuid4()),**payload}
        try:
            with client.http.open(BASE+path,urlencode(payload,doseq=True).encode(),timeout=15) as result:return result.status,result.read()
        except HTTPError as error:return error.code,error.read()

    invalid_password='ContrasenaIncorrectaDePrueba'
    anonymous=C();anonymous.pedir('/login',{'email':'correo-preservado@example.invalid','password':invalid_password},error=True)
    assert 'value="correo-preservado@example.invalid"' in anonymous.last_html and invalid_password not in anonymous.last_html
    status,_=raw_post(c,'/cuentas',{'name':'Sin CSRF','type':'SAVINGS','_csrf':'invalido'})
    assert status==400
    income(c,cash,10000,'Ingreso para pruebas ampliadas')
    key=str(uuid4());payload={'category_id':expense_cat,'amount':'123.45','description':'Idempotencia','occurred_at':TODAY.isoformat(),'payment_method':'ACCOUNT:'+cash,'payment_amount':'123.45','_request_id':key}
    before=balance(cash)
    with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(lambda _:c.pedir('/gastos',payload),range(2)))
    assert balance(cash)==before-Decimal('123.45')
    assert scalar("SELECT COUNT(*) n FROM financial_transactions WHERE user_id=%s AND description='Idempotencia'",(user,))==1
    status,_=raw_post(c,'/gastos',{**payload,'description':'Datos diferentes'})
    assert status==409
    for value in ['NaN','Infinity','0.001','-1','10000000000000000']:
        try:dinero(value)
        except ValueError:pass
        else:raise AssertionError('Importe inválido aceptado: '+value)
    ok('Correo conservado, contraseña excluida, CSRF y duplicados concurrentes sin doble COMMIT')

    c.pedir('/cuentas',{'name':'Banco de prueba','type':'SAVINGS','initial_balance':'500'})
    bank=one("SELECT id FROM accounts WHERE user_id=%s AND name='Banco de prueba'",(user,))['id']
    assert balance(bank)==Decimal('500')
    # Una cuenta repetida debe validar la suma, no cada incremento por separado.
    split_edit=expense(c,user,bank,'425','Medio repetido',extra={'payment_method':['ACCOUNT:'+bank,'ACCOUNT:'+bank],'payment_amount':['212.50','212.50']})
    split_ids=[p['id'] for p in sql('SELECT id FROM expense_payments WHERE expense_transaction_id=%s ORDER BY id',(split_edit,))]
    c.pedir('/movimientos/'+split_edit+'/editar',{'revision':'1','description':'No sobregirar','occurred_at':TODAY.isoformat(),'category_id':expense_cat,'payment_id':split_ids,'payment_amount':['287.50','287.50']},error=True)
    assert balance(bank)==Decimal('75')
    c.pedir('/movimientos/'+split_edit+'/editar',{'revision':'1','description':'Distribución corregida','occurred_at':TODAY.isoformat(),'category_id':expense_cat,'payment_id':split_ids,'payment_amount':['424.99','0.01']})
    assert balance(bank)==Decimal('75')
    c.pedir('/movimientos/'+split_edit+'/anular',{'reason':'Restaurar saldo de prueba'})
    assert balance(bank)==Decimal('500')
    c.pedir('/cuentas/'+bank+'/editar',{'name':'Banco editado','type':'CHECKING'})
    c.pedir('/cuentas/'+bank+'/archivar',{},error=True)
    c.pedir('/cuentas',{'name':'Archivable','type':'OTHER'})
    empty=one("SELECT id FROM accounts WHERE user_id=%s AND name='Archivable'",(user,))['id']
    c.pedir('/cuentas/'+empty+'/archivar',{})
    assert one('SELECT status FROM accounts WHERE id=%s',(empty,))['status']=='ARCHIVED'
    c.pedir('/cuentas/'+empty+'/restaurar',{})
    c.pedir('/tarjetas-debito',{'account_id':bank,'last_four':'9911','brand':'Marca','status':'ACTIVE'})
    debit=one('SELECT id FROM debit_cards WHERE account_id=%s',(bank,))['id']
    c.pedir('/tarjetas-debito/'+debit+'/editar',{'brand':'Actualizada','last_four':'9912','status':'BLOCKED'})
    assert one('SELECT status FROM debit_cards WHERE id=%s',(debit,))['status']=='BLOCKED'
    c.pedir('/tarjetas-debito/'+debit+'/editar',{'brand':'Actualizada','last_four':'9912','status':'ACTIVE'})
    ok('Saldo inicial sin ingreso; edición, archivo/restauración de cuenta y estados de débito')

    # Edición y anulación conservan movimientos, auditoría y una contrapartida exacta.
    income(c,cash,50,'Ingreso editable')
    editable=one("SELECT id FROM financial_transactions WHERE user_id=%s AND description='Ingreso editable'",(user,))['id']
    before=balance(cash)
    c.pedir('/movimientos/'+editable+'/editar',{'revision':'1','description':'Ingreso corregido','occurred_at':TODAY.isoformat(),'amount':'70','account_id':cash,'category_id':income_cat})
    assert balance(cash)==before+20
    c.pedir('/movimientos/'+editable+'/editar',{'revision':'1','description':'Revisión obsoleta','occurred_at':TODAY.isoformat(),'amount':'80','account_id':cash,'category_id':income_cat},error=True)
    assert balance(cash)==before+20
    c.pedir('/movimientos/'+editable+'/anular',{'revision':'2','reason':'Prueba de reversión'})
    assert balance(cash)==before-50
    assert one('SELECT voided_at FROM financial_transactions WHERE id=%s',(editable,))['voided_at']
    assert scalar('SELECT COUNT(*) n FROM transaction_audit WHERE transaction_id=%s',(editable,))==2
    tx=expense(c,user,bank,10,'Gasto editable')
    payment=one('SELECT id FROM expense_payments WHERE expense_transaction_id=%s',(tx,))['id']
    before=balance(bank)
    c.pedir('/movimientos/'+tx+'/editar',{'revision':'1','description':'Gasto corregido','occurred_at':TODAY.isoformat(),'category_id':expense_cat,'payment_id':payment,'payment_amount':'13.01'})
    assert balance(bank)==before-Decimal('3.01')
    c.pedir('/gastos/'+tx+'/reintegro',{'amount':'3.01','occurred_at':TODAY.isoformat()})
    refund=one('SELECT transaction_id FROM refunds WHERE expense_transaction_id=%s',(tx,))['transaction_id']
    c.pedir('/movimientos/'+tx+'/anular',{'reason':'No debe pasar'},error=True)
    c.pedir('/movimientos/'+refund+'/anular',{'reason':'Anular devolución'})
    c.pedir('/movimientos/'+tx+'/anular',{'reason':'Anular gasto corregido'})
    assert balance(bank)==Decimal('500')
    c.pedir('/transferencias',{'source_account_id':cash,'destination_account_id':bank,'amount':'100','occurred_at':TODAY.isoformat(),'description':'Invertir origen de transferencia'})
    flip=one("SELECT id FROM financial_transactions WHERE user_id=%s AND description='Invertir origen de transferencia'",(user,))['id']
    c.pedir('/movimientos/'+flip+'/editar',{'revision':'1','description':'No sobregirar al invertir','occurred_at':TODAY.isoformat(),'amount':'550','source_account_id':bank,'destination_account_id':cash},error=True)
    assert balance(bank)==Decimal('600')
    c.pedir('/movimientos/'+flip+'/editar',{'revision':'1','description':'Transferencia invertida','occurred_at':TODAY.isoformat(),'amount':'400','source_account_id':bank,'destination_account_id':cash})
    assert balance(bank)==Decimal('100')
    c.pedir('/movimientos/'+flip+'/anular',{'reason':'Restaurar saldo de prueba'})
    assert balance(bank)==Decimal('500')
    c.pedir('/transferencias',{'source_account_id':cash,'destination_account_id':bank,'amount':'20','occurred_at':TODAY.isoformat(),'description':'Transferencia editable'})
    transfer=one("SELECT id FROM financial_transactions WHERE user_id=%s AND description='Transferencia editable'",(user,))['id']
    c.pedir('/movimientos/'+transfer+'/editar',{'revision':'1','description':'Transferencia corregida','occurred_at':TODAY.isoformat(),'amount':'30','source_account_id':cash,'destination_account_id':bank})
    assert balance(bank)==Decimal('530')
    c.pedir('/movimientos/'+transfer+'/anular',{'reason':'Prueba'})
    assert balance(bank)==Decimal('500')
    ok('Edición con revisión, anulaciones auditadas, transferencias y dependencias de reintegros')

    c.pedir('/tarjetas-credito',{'name':'Cuotas exactas','last_four':'7788','credit_limit':'10000','annual_interest_rate':'0','closing_day':'31','due_day':'5','status':'ACTIVE'})
    card=one("SELECT id FROM credit_cards WHERE user_id=%s AND name='Cuotas exactas'",(user,))['id']
    card_expense=expense(c,user,cash,'100.01','Cuotas exactas de prueba',extra={'payment_method':'CREDIT:'+card,'payment_amount':'100.01','installment_count':'3'})
    plan=one('SELECT ip.* FROM installment_plans ip JOIN credit_card_charges cc ON cc.id=ip.credit_card_charge_id JOIN expense_payments ep ON ep.id=cc.expense_payment_id WHERE ep.expense_transaction_id=%s',(card_expense,))
    parts=sql('SELECT ci.*,cy.due_on FROM card_installments ci JOIN credit_card_cycles cy ON cy.id=ci.credit_card_cycle_id WHERE ci.installment_plan_id=%s ORDER BY installment_number',(plan['id'],))
    assert sum(p['due_amount'] for p in parts)==Decimal('100.01')
    assert len({p['credit_card_cycle_id'] for p in parts})==3
    assert [p['due_amount'] for p in parts]==[Decimal('33.34'),Decimal('33.34'),Decimal('33.33')]
    assert len({(p['due_on'].year,p['due_on'].month) for p in parts})==3
    # Reproducir el formato antiguo: todas las cuotas en un ciclo y redondeo sobrante.
    cn=obtener_conexion();cur=cn.cursor()
    try:
        cur.execute('UPDATE card_installments SET credit_card_cycle_id=%s,due_amount=%s WHERE installment_plan_id=%s',(parts[0]['credit_card_cycle_id'],Decimal('33.34'),plan['id']))
        cn.commit()
    finally:cur.close();cn.close()
    from migrar_datos_fase2 import migrar_planes_legacy
    assert migrar_planes_legacy()['corregidos']==1
    repaired=sql('SELECT * FROM card_installments WHERE installment_plan_id=%s ORDER BY installment_number',(plan['id'],))
    assert len({p['credit_card_cycle_id'] for p in repaired})==3 and sum(p['due_amount'] for p in repaired)==Decimal('100.01')
    c.pedir('/tarjetas-credito/'+card+'/pagar',{'account_id':cash,'amount':'33.34','occurred_at':TODAY.isoformat()})
    assert one('SELECT status FROM card_installments WHERE id=%s',(parts[0]['id'],))['status']=='PAID'
    payment_tx=one('SELECT transaction_id FROM credit_card_payments WHERE credit_card_id=%s',(card,))['transaction_id']
    c.pedir('/movimientos/'+payment_tx+'/anular',{'reason':'Revertir pago'})
    assert one('SELECT status FROM card_installments WHERE id=%s',(parts[0]['id'],))['status']=='PENDING'
    c.pedir('/tarjetas-credito/'+card)
    cn=obtener_conexion();cur=cn.cursor(dictionary=True)
    try:
        leap=ciclo(cur,card,date(2028,2,29));assert leap['closes_on']==date(2028,2,29) and leap['due_on']==date(2028,3,5)
        assert saldo_credito(cur,card)==Decimal('100.01')
        cn.rollback()
    finally:cur.close();cn.close()
    ok('Cuotas exactas con último redondeo, ciclos mensuales, año bisiesto y pago/anulación de cuota')

    issued=TODAY-timedelta(days=30)
    c.pedir('/deudas',{'contact_name':'Préstamo con interés','direction':'PAYABLE','original_amount':'10000','annual_interest_rate':'36.5','issued_on':issued.isoformat(),'disbursement_account_id':cash,'description':'Interés diario probado'})
    debt=one("SELECT id,disbursement_transaction_id FROM debts WHERE created_by_user_id=%s AND description='Interés diario probado'",(user,))
    c.pedir('/deudas/'+debt['id']+'/pagar',{'account_id':cash,'amount':'3100','occurred_at':TODAY.isoformat()})
    payment=one('SELECT * FROM debt_payments WHERE debt_id=%s',(debt['id'],))
    assert payment['interest_amount']==Decimal('300') and payment['principal_amount']==Decimal('2800')
    c.pedir('/movimientos/'+debt['disbursement_transaction_id']+'/anular',{'reason':'Tiene pagos'},error=True)
    c.pedir('/deudas/'+debt['id']+'/pagar',{'payment_method':'DEBIT:'+debit,'amount':'100','occurred_at':TODAY.isoformat()})
    c.pedir('/deudas/'+debt['id']+'/pagar',{'payment_method':'CREDIT:'+card,'amount':'100','occurred_at':TODAY.isoformat(),'installment_count':'2','interest_free':'1'})
    c.pedir('/tarjetas-credito/'+card)
    c.pedir('/deudas')
    cn=obtener_conexion();cur=cn.cursor(dictionary=True)
    try:assert estado_deuda(cur,debt['id'],user)['principal']==Decimal('7000')
    finally:cur.close();cn.close()
    c.pedir('/movimientos/'+payment['transaction_id']+'/anular',{'reason':'Reabrir capital e interés'},error=True)
    for pay in sql('SELECT transaction_id FROM debt_payments WHERE debt_id=%s ORDER BY payment_order DESC',(debt['id'],)):
        c.pedir('/movimientos/'+pay['transaction_id']+'/anular',{'reason':'Anulación en orden inverso'})
    ok('Préstamo con entrega, interés simple diario y pagos parciales desde cuenta/débito/crédito')

    # Usuario dedicado para avanzar el reloj sin afectar los demás casos.
    auto,auto_user,auto_cash=fresh()
    auto.pedir('/facturas',{'name':'Regla día 31','category_id':expense_cat,'frequency':'MONTHLY','expected_amount':'100','next_due_on':f'{TODAY.year}-01-31'})
    rule=one("SELECT id FROM recurring_rules WHERE user_id=%s AND name='Regla día 31'",(auto_user,))['id']
    generated=sql('SELECT id,due_on FROM bills WHERE recurring_rule_id=%s ORDER BY due_on',(rule,))
    assert date(TODAY.year,2,28) in [r['due_on'] for r in generated] or date(TODAY.year,2,29) in [r['due_on'] for r in generated]
    assert date(TODAY.year,3,31) in [r['due_on'] for r in generated]
    with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(lambda _:automatizar(auto_user),range(2)))
    assert scalar('SELECT COUNT(*) n FROM bills WHERE recurring_rule_id=%s',(rule,))==len(generated)
    first=generated[0]['id']
    auto.pedir('/facturas/'+first+'/editar',{'description':'Importe real','amount':'125','due_on':generated[0]['due_on'].isoformat()})
    auto.pedir('/facturas/'+first+'/pagar',{'account_id':auto_cash,'occurred_at':TODAY.isoformat()})
    auto.pedir('/facturas/'+first+'/pagar',{'account_id':auto_cash,'occurred_at':TODAY.isoformat()},error=True)
    assert scalar('SELECT COUNT(*) n FROM expenses e JOIN financial_transactions ft ON ft.id=e.transaction_id WHERE ft.user_id=%s',(auto_user,))==1
    rule_data=one('SELECT * FROM recurring_rules WHERE id=%s',(rule,))
    auto.pedir('/recurrentes/'+rule+'/editar',{'name':'Regla pausada sin perder el día 31','expected_amount':'100','frequency':'MONTHLY','next_due_on':rule_data['next_due_on'].isoformat()})
    assert one('SELECT anchor_day FROM recurring_rules WHERE id=%s',(rule,))['anchor_day']==31
    auto.pedir('/tarjetas-credito',{'name':'Interés vencido','last_four':'1122','credit_limit':'100000','annual_interest_rate':'24','closing_day':str(TODAY.day),'due_day':str(min(28,TODAY.day+1)),'status':'ACTIVE'})
    auto_card=one('SELECT id FROM credit_cards WHERE user_id=%s',(auto_user,))['id']
    expense(auto,auto_user,auto_cash,'1000','Saldo para interés',extra={'payment_method':'CREDIT:'+auto_card,'payment_amount':'1000'})
    future=sumar_meses(TODAY,2)+timedelta(days=2)
    automatizar(auto_user,future)
    count=scalar('SELECT COUNT(*) n FROM credit_card_interests WHERE credit_card_id=%s',(auto_card,))
    assert count>=1
    automatizar(auto_user,future)
    assert scalar('SELECT COUNT(*) n FROM credit_card_interests WHERE credit_card_id=%s',(auto_card,))==count
    assert scalar('SELECT COUNT(*) n FROM credit_card_cycles WHERE credit_card_id=%s AND closed_at IS NOT NULL',(auto_card,))>=2
    ok('Recurrencia de fin de mes, generación concurrente sin duplicados, pago único e interés/cierre automático recuperable')

    owner,owner_id,owner_cash=fresh();member,member_id,member_cash=fresh();outsider,outsider_id,outsider_cash=fresh()
    owner.pedir('/grupos',{'name':'Grupo privado de prueba'})
    group=one('SELECT id FROM `groups` WHERE owner_user_id=%s',(owner_id,))['id']
    member_email=one('SELECT email FROM users WHERE id=%s',(member_id,))['email']
    owner.pedir('/grupos/'+group+'/invitar',{'email':member_email})
    invite=one('SELECT id FROM group_invitations WHERE group_id=%s',(group,))['id']
    member.pedir('/invitaciones/'+invite+'/responder',{'action':'accept'})
    owner.pedir('/grupos/'+group+'/vaquitas',{'name':'Fondo real de prueba','target_amount':'2000'})
    pool=one('SELECT id FROM pools WHERE group_id=%s',(group,))['id']
    for client in [outsider]:
        for route in ['/grupos/'+group,'/vaquitas/'+pool]:
            try:client.pedir(route)
            except HTTPError as error:assert error.code==404
            else:raise AssertionError('Grupo privado expuesto')
    for client,account in [(owner,owner_cash),(member,member_cash)]:client.pedir('/vaquitas/'+pool+'/aportar',{'account_id':account,'amount':'500.01','occurred_at':TODAY.isoformat(),'action':'contribute'})
    owner.pedir('/vaquitas/'+pool+'/gastar',{'amount':'100.01','description':'Gasto repartido','occurred_at':TODAY.isoformat(),'participants':[owner_id,member_id]})
    shared=one('SELECT id,transaction_id FROM pool_expenses WHERE pool_id=%s',(pool,))
    assert scalar('SELECT SUM(amount) n FROM pool_expense_shares WHERE pool_expense_id=%s',(shared['id'],))==Decimal('100.01')
    from gestion import saldo_vaquita
    cn=obtener_conexion();cur=cn.cursor(dictionary=True)
    try:assert saldo_vaquita(cur,pool)==Decimal('900.01')
    finally:cur.close();cn.close()
    owner.pedir('/vaquitas/'+pool+'/estado',{'status':'CLOSED'},error=True)
    member.pedir('/vaquitas/'+pool+'/gastar',{'amount':'10','description':'Sin permiso','occurred_at':TODAY.isoformat()},error=True)
    member.pedir('/vaquitas/'+pool+'/aportar',{'account_id':member_cash,'amount':'100','occurred_at':TODAY.isoformat(),'action':'withdraw'})
    assert balance(member_cash)==Decimal('-400.01')
    assert sum(e['amount'] for e in eventos(owner_id,TODAY,TODAY+timedelta(days=1)) if e['kind']=='expense') in {Decimal('50.00'),Decimal('50.01')}
    owner.pedir('/movimientos/'+shared['transaction_id']+'/anular',{'reason':'Reponer fondo compartido'})
    owner.pedir('/vaquitas/'+pool)
    ok('Invitaciones aceptadas, privacidad de grupos, aportes/retiros, reparto exacto y reversión compartida')

    analyst,analyst_id,analyst_cash=fresh()
    month=TODAY.replace(day=1)
    for index,amount in [(-3,120),(-2,240),(-1,360)]:
        on=sumar_meses(month,index)+timedelta(days=9)
        income(analyst,analyst_cash,900,'Ingreso trimestre '+str(index),on)
        expense(analyst,analyst_id,analyst_cash,amount,'Gasto trimestre '+str(index),on)
    prior=one("SELECT id FROM financial_transactions WHERE user_id=%s AND description='Gasto trimestre -1'",(analyst_id,))['id']
    analyst.pedir('/gastos/'+prior+'/reintegro',{'amount':'30','occurred_at':(sumar_meses(month,-1)+timedelta(days=14)).isoformat()})
    analyst.pedir('/presupuesto/guardar',{'month':month.strftime('%Y-%m'),'category_id':expense_cat,'amount':'1000'})
    analyst.pedir('/presupuesto')
    assert '230' in analyst.last_html and '900' in analyst.last_html
    budget=one('SELECT id FROM category_budgets WHERE user_id=%s',(analyst_id,))['id']
    analyst.pedir('/presupuesto/'+budget+'/quitar',{})
    archived=one('SELECT amount,is_active FROM category_budgets WHERE id=%s',(budget,))
    assert archived['amount']==1000 and not archived['is_active']
    analyst.pedir('/presupuesto/guardar',{'month':month.strftime('%Y-%m'),'category_id':expense_cat,'amount':'1000'})
    assert one('SELECT is_active FROM category_budgets WHERE id=%s',(budget,))['is_active']
    quarter=eventos(analyst_id,sumar_meses(month,-3),month)
    assert sum(e['amount'] for e in quarter if e['kind']=='expense')==690
    expense(analyst,analyst_id,analyst_cash,'10.01','=1+1')
    analyst.pedir('/historial?q=%3D1%2B1&type=EXPENSE')
    assert '=1+1' in analyst.last_html
    with analyst.http.open(BASE+'/reportes.csv?start='+month.isoformat()+'&end='+TODAY.isoformat()) as response:
        csv=response.read().decode('utf-8-sig');assert "'=1+1" in csv and '10.01' in csv
    with analyst.http.open(BASE+'/reportes.pdf') as response:
        pdf=response.read();assert pdf.startswith(b'%PDF-') and len(pdf)>1500
    analyst.pedir('/configuracion',{'full_name':'Perfil probado','email':one('SELECT email FROM users WHERE id=%s',(analyst_id,))['email'],'theme':'dark','hide_balances':'1','monthly_income':'1200'})
    analyst.pedir('/configuracion')
    assert 'data-theme="dark"' in analyst.last_html and 'ocultar-saldos' in analyst.last_html
    preferences=one('SELECT * FROM user_preferences WHERE user_id=%s',(analyst_id,))
    assert preferences['monthly_income']==1200
    analyst.pedir('/configuracion',{'full_name':'Perfil probado','email':one('SELECT email FROM users WHERE id=%s',(analyst_id,))['email'],'theme':'light','monthly_income':'1200','current_password':'PruebaFase1-2026','new_password':'NuevaClaveFase2-2026','password_confirmation':'NuevaClaveFase2-2026'})
    analyst.pedir('/salir');analyst.pedir('/login',{'email':one('SELECT email FROM users WHERE id=%s',(analyst_id,))['email'],'password':'NuevaClaveFase2-2026'})
    ok('Promedio trimestral neto, presupuestos, filtros, CSV seguro, PDF y preferencias/contraseña persistentes')

    # Revisar todo enlace/formulario del menú y detalle con datos reales de prueba.
    paths=['/','/cuentas','/ingresos','/gastos','/transferencias','/historial','/tarjetas-debito','/tarjetas-credito','/facturas','/deudas','/presupuesto','/metas','/categorias','/grupos','/reportes','/configuracion']
    for route in paths:c.pedir(route)
    for record in sql('SELECT id FROM financial_transactions WHERE user_id=%s',(user,)):
        c.pedir('/movimientos/'+record['id'])
    for endpoint in ['/movimientos/'+editable,'/tarjetas-credito/'+card]:
        try:outsider.pedir(endpoint)
        except HTTPError as error:assert error.code in {403,404}
        else:assert 'Ingreso corregido' not in outsider.last_html and 'Cuotas exactas' not in outsider.last_html
    # Snapshot para inspección visual opcional: únicamente datos de esta base desechable.
    c.pedir('/gastos')
    (ROOT/'backups'/'fase2_formulario_prueba.html').write_text(c.last_html,encoding='utf-8')
    c.pedir('/gastos',{'category_id':expense_cat,'amount':'125.50','description':'Compra que debe conservarse','occurred_at':TODAY.isoformat(),'payment_method':['ACCOUNT:'+cash,'ACCOUNT:'+bank],'payment_amount':['100','20'],'installment_count':'1'},error=True)
    (ROOT/'backups'/'fase2_formulario_error_prueba.html').write_text(c.last_html,encoding='utf-8')
    c.pedir('/movimientos/'+card_expense)
    (ROOT/'backups'/'fase2_detalle_prueba.html').write_text(c.last_html,encoding='utf-8')
    c.pedir('/')
    snapshot=ROOT/'backups'/'fase2_dashboard_prueba.html';snapshot.write_text(c.last_html,encoding='utf-8')
    ok('Navegación con datos, detalles y autorización entre usuarios; snapshot visual sólo de prueba')


def main():
    (ROOT/'backups').mkdir(exist_ok=True)
    db='app_finanzas_pruebas_fase2_'+uuid4().hex[:10]
    admin=mysql.connector.connect(host=os.environ.get('DB_HOST','127.0.0.1'),port=int(os.environ.get('DB_PORT','3306')),user=os.environ.get('DB_USER','root'),password=os.environ.get('DB_PASSWORD',''))
    server=None;log=None
    try:
        cur=admin.cursor();cur.execute('CREATE DATABASE `'+db+'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');cur.close()
        executable=Path('C:/xampp/mysql/bin/mysqldump.exe')
        source=os.environ.get('DB_NAME','app_finanzas')
        shape=subprocess.run([str(executable),'--host=127.0.0.1','--user=root','--no-data','--default-character-set=utf8mb4',source],capture_output=True,check=True).stdout
        subprocess.run(['C:/xampp/mysql/bin/mysql.exe','--host=127.0.0.1','--user=root','--default-character-set=utf8mb4',db],input=shape,check=True)
        os.environ['DB_NAME']=db;env=os.environ.copy();env['FLASK_DEBUG']='0';env['PYTHONIOENCODING']='utf-8'
        log=(ROOT/'fase2_http_pruebas.log').open('w',encoding='utf-8')
        server=subprocess.Popen([sys.executable,'-m','flask','--app','app','run','--host','127.0.0.1','--port','5001','--no-reload'],cwd=ROOT,env=env,stdout=log,stderr=log,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        for _ in range(120):
            if server.poll() is not None:raise RuntimeError('El servidor de prueba no inició; revise fase2_http_pruebas.log')
            try:
                with urlopen(BASE+'/login',timeout=1) as response:
                    if response.status==200:break
            except (URLError,TimeoutError):time.sleep(.15)
        else:raise RuntimeError('Tiempo de inicio de Flask excedido')
        print('Base temporal:',db,flush=True)
        run_tests()
        print('RESULTADO:',len(RESULTS),'grupos ampliados correctos.',flush=True)
    finally:
        if server:
            server.terminate()
            try:server.wait(timeout=8)
            except subprocess.TimeoutExpired:server.kill();server.wait()
        if log:log.close()
        # El nombre es generado aquí, nunca procede del usuario ni apunta a app_finanzas.
        assert re.fullmatch(r'app_finanzas_pruebas_fase2_[a-f0-9]{10}',db)
        cur=admin.cursor();cur.execute('DROP DATABASE `'+db+'`');cur.close();admin.close()
        print('Base temporal eliminada; app_finanzas conservada.',flush=True)


if __name__=='__main__':main()
