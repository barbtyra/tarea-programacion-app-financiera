"""Protección de formularios, contexto visual y respuestas de error recuperables."""
import hashlib
import hmac
import secrets
from pathlib import Path
from uuid import UUID, uuid4

from flask import abort, flash, g, redirect, render_template, request, session
from markupsafe import Markup, escape
from werkzeug.exceptions import HTTPException

from conexion import obtener_conexion
from finanzas import consultar


def instalar_experiencia(app):
    asset_version = str(max((Path(app.static_folder) / name).stat().st_mtime_ns for name in ['css/styles.css', 'js/app.js']))
    @app.before_request
    def preparar_peticion():
        g.track_operation = False
        if request.endpoint == 'static':
            return None
        session.setdefault('_csrf', secrets.token_urlsafe(32))
        session.setdefault('_form_scope', str(uuid4()))
        if session.get('user_id'):
            cn = obtener_conexion()
            try:
                cur = cn.cursor(dictionary=True)
                g.profile = consultar(cur, 'SELECT id,full_name,email FROM users WHERE id=%s AND deleted_at IS NULL', (session['user_id'],), True)
                if not g.profile:
                    session.clear()
                    return redirect('/login')
                g.preferences = consultar(cur, 'SELECT * FROM user_preferences WHERE user_id=%s', (session['user_id'],), True) or {'theme': 'light', 'hide_balances': False, 'monthly_income': None}
                cur.close()
            finally:
                cn.close()
        if request.method == 'POST':
            if not hmac.compare_digest(request.form.get('_csrf', ''), session['_csrf']):
                abort(400, description='La sesión del formulario venció. Recargue la página; su borrador permanece en esta pestaña.')
            try:
                operation = str(UUID(request.form.get('_request_id', '')))
            except (ValueError, AttributeError):
                abort(400, description='Falta la identificación del formulario. Recargue la página antes de continuar.')
            g.operation_id = operation
            g.operation_scope = session['_form_scope']
            values = [(key, request.form.getlist(key)) for key in sorted(request.form) if key not in {'_csrf', '_request_id'}]
            g.operation_fingerprint = hmac.new(app.secret_key.encode(), (request.path + repr(values)).encode(), hashlib.sha256).hexdigest()
            lock = hashlib.sha256((g.operation_scope + operation).encode()).hexdigest()
            cn = obtener_conexion()
            g.operation_lock = cn
            g.lock_name = lock
            cur = cn.cursor(dictionary=True)
            if not consultar(cur, 'SELECT GET_LOCK(%s,10) acquired', (lock,), True)['acquired']:
                abort(409, description='Esta operación sigue en curso. Espere unos segundos y revise el historial.')
            receipt = consultar(cur, 'SELECT * FROM operation_receipts WHERE user_scope=%s AND request_id=%s', (g.operation_scope, operation), True)
            cur.close()
            if receipt:
                if not hmac.compare_digest(receipt['fingerprint'], g.operation_fingerprint):
                    abort(409, description='Ese formulario ya se utilizó con otros datos. Recargue la página para iniciar una operación nueva.')
                flash('Esta operación ya fue guardada. No se creó un duplicado.', 'ok')
                session['_completed_operation'] = operation
                return redirect(receipt['redirect_to'] or '/')
        if session.get('user_id') and request.endpoint != 'static':
            from automatizacion import automatizar
            try:
                automatizar(session['user_id'])
            except Exception:
                app.logger.exception('Actualización automática pendiente')
                flash('La actualización automática no pudo completarse. Sus datos se conservan; se reintentará en el próximo acceso.', 'error')
        g.track_operation = True

    @app.after_request
    def terminar_peticion(response):
        if getattr(g, 'receipt_saved', False):
            session['_completed_operation'] = g.operation_id
        if getattr(g, 'receipt_saved', False) and response.status_code in (301, 302, 303):
            cn = None
            try:
                cn = obtener_conexion()
                g.track_operation = False
                cur = cn.cursor()
                cur.execute('UPDATE operation_receipts SET redirect_to=%s WHERE user_scope=%s AND request_id=%s', (response.headers.get('Location', '/')[:255], g.operation_scope, g.operation_id))
                cn.commit()
                cur.close()
            except Exception:
                if cn:
                    cn.rollback()
                app.logger.exception('El movimiento fue guardado; no se pudo actualizar su destino de navegación')
            finally:
                if cn:
                    cn.close()
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Referrer-Policy'] = 'same-origin'
        response.headers['Cache-Control'] = 'no-store' if request.endpoint != 'static' else 'public, max-age=3600'
        response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        return response

    @app.teardown_request
    def soltar_bloqueo(error=None):
        cn = getattr(g, 'operation_lock', None)
        if cn:
            g.operation_lock = None
            try:
                cur = cn.cursor()
                cur.execute('SELECT RELEASE_LOCK(%s)', (g.lock_name,))
                cur.fetchone()
                cur.close()
            finally:
                cn.close()

    @app.context_processor
    def contexto():
        def tokens():
            return Markup('<input type="hidden" name="_csrf" value="{}"><input type="hidden" name="_request_id" value="{}">').format(escape(session.get('_csrf', '')), str(uuid4()))
        safe = {k: v for k, v in request.form.to_dict(flat=False).items() if k not in {'password', 'password_confirmation', 'current_password', 'new_password', '_csrf', '_request_id'}}
        completed = g.operation_id if getattr(g, 'receipt_saved', False) else session.pop('_completed_operation', None)
        return dict(form_tokens=tokens, posted_values=safe, completed_operation=completed, asset_version=asset_version, profile=getattr(g, 'profile', None), preferences=getattr(g, 'preferences', {}))

    @app.errorhandler(Exception)
    def mostrar_error(error):
        if isinstance(error, HTTPException):
            code, message = error.code, error.description
        else:
            app.logger.exception('Error atendiendo %s', request.path)
            code = 500
            message = 'No pudimos completar la respuesta. Sus datos se conservan. Revise el historial antes de repetir una operación.'
        return render_template('error.html', code=code, message=message), code
