-- Versión adaptada para MariaDB/XAMPP
-- UUID se almacena como CHAR(36); los UUID se generan desde Python.
-- También se corrigió la dirección de varias FK 1:1 exportadas al revés por dbdiagram.
-- El modelo funcional original se mantiene.

CREATE TABLE `users` (
  `id` CHAR(36) PRIMARY KEY,
  `full_name` varchar(150) NOT NULL,
  `email` varchar(254) UNIQUE NOT NULL,
  `password_hash` varchar(255) NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
);

CREATE TABLE `currencies` (
  `code` char(3) PRIMARY KEY COMMENT 'ISO 4217. Ej.: PYG, USD. No hay conversión en esta versión.',
  `name` varchar(60) NOT NULL,
  `symbol` varchar(8),
  `decimal_places` int NOT NULL DEFAULT 2
);

CREATE TABLE `institutions` (
  `id` CHAR(36) PRIMARY KEY,
  `name` varchar(150) UNIQUE NOT NULL
);

CREATE TABLE `accounts` (
  `id` CHAR(36) PRIMARY KEY,
  `user_id` CHAR(36) NOT NULL,
  `institution_id` CHAR(36),
  `currency_code` char(3) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` ENUM ('CASH', 'SAVINGS', 'CHECKING', 'DIGITAL', 'OTHER') NOT NULL,
  `status` ENUM ('ACTIVE', 'ARCHIVED') NOT NULL DEFAULT 'ACTIVE',
  `interest_rate` decimal(9,6) COMMENT 'Tasa informativa; no genera movimientos por sí sola.',
  `opened_at` date,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `debit_cards` (
  `id` CHAR(36) PRIMARY KEY,
  `account_id` CHAR(36) NOT NULL,
  `brand` varchar(40),
  `last_four` char(4) NOT NULL,
  `expires_on` date,
  `status` ENUM ('ACTIVE', 'BLOCKED', 'EXPIRED', 'ARCHIVED') NOT NULL DEFAULT 'ACTIVE',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `credit_cards` (
  `id` CHAR(36) PRIMARY KEY,
  `user_id` CHAR(36) NOT NULL,
  `institution_id` CHAR(36),
  `currency_code` char(3) NOT NULL,
  `name` varchar(100) NOT NULL,
  `brand` varchar(40),
  `last_four` char(4) NOT NULL,
  `credit_limit` decimal(18,2) NOT NULL,
  `annual_interest_rate` decimal(9,6) COMMENT 'Tasa nominal anual o la convención definida por la app.',
  `closing_day` smallint NOT NULL COMMENT '1..31; se ajusta al último día válido del mes.',
  `due_day` smallint NOT NULL COMMENT '1..31; se ajusta al último día válido del mes.',
  `status` ENUM ('ACTIVE', 'BLOCKED', 'EXPIRED', 'ARCHIVED') NOT NULL DEFAULT 'ACTIVE',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `financial_transactions` (
  `id` CHAR(36) PRIMARY KEY,
  `user_id` CHAR(36) NOT NULL,
  `currency_code` char(3) NOT NULL,
  `type` ENUM ('INCOME', 'INITIAL_BALANCE', 'EXPENSE', 'TRANSFER', 'CARD_PAYMENT', 'CARD_INTEREST', 'REFUND', 'DEBT_DISBURSEMENT', 'DEBT_PAYMENT', 'POOL_CONTRIBUTION', 'POOL_EXPENSE', 'ADJUSTMENT') NOT NULL,
  `occurred_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` varchar(255),
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `account_entries` (
  `id` CHAR(36) PRIMARY KEY,
  `transaction_id` CHAR(36) NOT NULL,
  `account_id` CHAR(36) NOT NULL,
  `amount` decimal(18,2) NOT NULL COMMENT 'CHECK amount <> 0. Positivo = entrada; negativo = salida.',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `categories` (
  `id` CHAR(36) PRIMARY KEY,
  `user_id` CHAR(36) COMMENT 'NULL = categoría predeterminada del sistema.',
  `kind` ENUM ('INCOME', 'EXPENSE') NOT NULL,
  `name` varchar(80) NOT NULL,
  `is_active` boolean NOT NULL DEFAULT true
);

CREATE TABLE `expenses` (
  `transaction_id` CHAR(36) PRIMARY KEY,
  `category_id` CHAR(36) NOT NULL,
  `merchant` varchar(150),
  `total_amount` decimal(18,2) NOT NULL
);

CREATE TABLE `expense_payments` (
  `id` CHAR(36) PRIMARY KEY,
  `expense_transaction_id` CHAR(36) NOT NULL,
  `account_id` CHAR(36),
  `debit_card_id` CHAR(36),
  `credit_card_id` CHAR(36),
  `amount` decimal(18,2) NOT NULL
);

CREATE TABLE `expense_splits` (
  `id` CHAR(36) PRIMARY KEY,
  `expense_transaction_id` CHAR(36) NOT NULL,
  `party_id` CHAR(36) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `generated_debt_id` CHAR(36) UNIQUE
);

CREATE TABLE `incomes` (
  `transaction_id` CHAR(36) PRIMARY KEY,
  `category_id` CHAR(36) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `is_projectable` boolean NOT NULL DEFAULT true
);

CREATE TABLE `transfers` (
  `transaction_id` CHAR(36) PRIMARY KEY,
  `source_account_id` CHAR(36) NOT NULL,
  `destination_account_id` CHAR(36) NOT NULL,
  `amount` decimal(18,2) NOT NULL
);

CREATE TABLE `refunds` (
  `transaction_id` CHAR(36) PRIMARY KEY,
  `expense_transaction_id` CHAR(36) NOT NULL,
  `amount` decimal(18,2) NOT NULL
);

CREATE TABLE `refund_allocations` (
  `id` CHAR(36) PRIMARY KEY,
  `refund_transaction_id` CHAR(36) NOT NULL,
  `expense_payment_id` CHAR(36) NOT NULL COMMENT 'Parte del medio de pago original que se está reintegrando.',
  `account_id` CHAR(36),
  `credit_card_id` CHAR(36),
  `amount` decimal(18,2) NOT NULL
);

CREATE TABLE `recurring_rules` (
  `id` CHAR(36) PRIMARY KEY,
  `user_id` CHAR(36) NOT NULL,
  `category_id` CHAR(36) NOT NULL,
  `currency_code` char(3) NOT NULL,
  `name` varchar(120) NOT NULL,
  `merchant` varchar(150),
  `frequency` ENUM ('WEEKLY', 'MONTHLY', 'QUARTERLY', 'YEARLY') NOT NULL,
  `is_variable_amount` boolean NOT NULL DEFAULT false,
  `expected_amount` decimal(18,2) COMMENT 'Monto fijo o última estimación; para variables se recalcula desde facturas pagadas.',
  `next_due_on` date NOT NULL,
  `is_active` boolean NOT NULL DEFAULT true
);

CREATE TABLE `bills` (
  `id` CHAR(36) PRIMARY KEY,
  `recurring_rule_id` CHAR(36),
  `user_id` CHAR(36) NOT NULL,
  `currency_code` char(3) NOT NULL,
  `category_id` CHAR(36) NOT NULL,
  `description` varchar(255) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `due_on` date NOT NULL,
  `status` ENUM ('PENDING', 'PAID', 'CANCELLED', 'OVERDUE') NOT NULL DEFAULT 'PENDING',
  `paid_expense_transaction_id` CHAR(36) UNIQUE,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `credit_card_cycles` (
  `id` CHAR(36) PRIMARY KEY,
  `credit_card_id` CHAR(36) NOT NULL,
  `starts_on` date NOT NULL,
  `closes_on` date NOT NULL,
  `due_on` date NOT NULL,
  `minimum_payment` decimal(18,2) COMMENT 'Calculado o informado al cerrar el extracto.',
  `statement_balance` decimal(18,2) COMMENT 'Snapshot al cierre; no es el saldo vivo de la tarjeta.',
  `closed_at` timestamp NULL DEFAULT NULL
);

CREATE TABLE `credit_card_charges` (
  `id` CHAR(36) PRIMARY KEY,
  `expense_payment_id` CHAR(36) UNIQUE,
  `debt_payment_source_id` CHAR(36) UNIQUE,
  `initial_cycle_id` CHAR(36) COMMENT 'Para un pago único; en cuotas, las cuotas se asignan individualmente.',
  `financing_type` ENUM ('ONE_TIME', 'INSTALLMENT_NO_INTEREST', 'INSTALLMENT_WITH_INTEREST') NOT NULL,
  `principal_amount` decimal(18,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `installment_plans` (
  `id` CHAR(36) PRIMARY KEY,
  `credit_card_charge_id` CHAR(36) UNIQUE NOT NULL,
  `installment_count` smallint NOT NULL,
  `periodic_interest_rate` decimal(9,6) NOT NULL DEFAULT 0,
  `financed_total` decimal(18,2) NOT NULL,
  `installment_amount` decimal(18,2) NOT NULL,
  `first_due_on` date NOT NULL
);

CREATE TABLE `card_installments` (
  `id` CHAR(36) PRIMARY KEY,
  `installment_plan_id` CHAR(36) NOT NULL,
  `credit_card_cycle_id` CHAR(36),
  `installment_number` smallint NOT NULL,
  `due_amount` decimal(18,2) NOT NULL,
  `status` ENUM ('PENDING', 'BILLED', 'PAID', 'CANCELLED') NOT NULL DEFAULT 'PENDING'
);

CREATE TABLE `credit_card_payments` (
  `transaction_id` CHAR(36) PRIMARY KEY,
  `credit_card_id` CHAR(36) NOT NULL,
  `credit_card_cycle_id` CHAR(36) COMMENT 'Extracto al que se imputa; puede ser NULL para pago a cuenta.',
  `amount` decimal(18,2) NOT NULL
);

CREATE TABLE `credit_card_interests` (
  `transaction_id` CHAR(36) PRIMARY KEY,
  `credit_card_id` CHAR(36) NOT NULL,
  `credit_card_cycle_id` CHAR(36),
  `amount` decimal(18,2) NOT NULL,
  `rate_applied` decimal(9,6)
);

CREATE TABLE `external_contacts` (
  `id` CHAR(36) PRIMARY KEY,
  `owner_user_id` CHAR(36) NOT NULL,
  `name` varchar(150) NOT NULL,
  `phone` varchar(40),
  `email` varchar(254),
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `parties` (
  `id` CHAR(36) PRIMARY KEY,
  `user_id` CHAR(36),
  `external_contact_id` CHAR(36),
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `debts` (
  `id` CHAR(36) PRIMARY KEY,
  `created_by_user_id` CHAR(36) NOT NULL,
  `creditor_party_id` CHAR(36) NOT NULL,
  `debtor_party_id` CHAR(36) NOT NULL,
  `currency_code` char(3) NOT NULL,
  `description` varchar(255),
  `original_amount` decimal(18,2) NOT NULL,
  `annual_interest_rate` decimal(9,6) NOT NULL DEFAULT 0,
  `issued_on` date NOT NULL,
  `due_on` date,
  `status` ENUM ('OPEN', 'SETTLED', 'CANCELLED') NOT NULL DEFAULT 'OPEN'
);

CREATE TABLE `debt_payments` (
  `id` CHAR(36) PRIMARY KEY,
  `debt_id` CHAR(36) NOT NULL,
  `transaction_id` CHAR(36) UNIQUE NOT NULL,
  `amount` decimal(18,2) NOT NULL
);

CREATE TABLE `debt_payment_sources` (
  `id` CHAR(36) PRIMARY KEY,
  `debt_payment_id` CHAR(36) NOT NULL,
  `account_id` CHAR(36),
  `debit_card_id` CHAR(36),
  `credit_card_id` CHAR(36),
  `amount` decimal(18,2) NOT NULL
);

CREATE TABLE `friendships` (
  `id` CHAR(36) PRIMARY KEY,
  `requester_user_id` CHAR(36) NOT NULL,
  `addressee_user_id` CHAR(36) NOT NULL,
  `status` ENUM ('PENDING', 'ACCEPTED', 'BLOCKED') NOT NULL DEFAULT 'PENDING',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `groups` (
  `id` CHAR(36) PRIMARY KEY,
  `owner_user_id` CHAR(36) NOT NULL,
  `name` varchar(120) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `group_members` (
  `group_id` CHAR(36) NOT NULL,
  `user_id` CHAR(36) NOT NULL,
  `joined_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`group_id`, `user_id`)
);

CREATE TABLE `pools` (
  `id` CHAR(36) PRIMARY KEY,
  `group_id` CHAR(36) NOT NULL,
  `currency_code` char(3) NOT NULL,
  `name` varchar(120) NOT NULL,
  `target_amount` decimal(18,2),
  `target_date` date,
  `status` ENUM ('OPEN', 'CLOSED', 'CANCELLED') NOT NULL DEFAULT 'OPEN',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `pool_contributions` (
  `id` CHAR(36) PRIMARY KEY,
  `pool_id` CHAR(36) NOT NULL,
  `member_user_id` CHAR(36) NOT NULL,
  `transaction_id` CHAR(36) UNIQUE NOT NULL,
  `amount` decimal(18,2) NOT NULL
);

CREATE TABLE `pool_expenses` (
  `id` CHAR(36) PRIMARY KEY,
  `pool_id` CHAR(36) NOT NULL,
  `paid_by_user_id` CHAR(36) NOT NULL,
  `transaction_id` CHAR(36) UNIQUE NOT NULL,
  `description` varchar(255) NOT NULL,
  `amount` decimal(18,2) NOT NULL
);

CREATE TABLE `saving_goals` (
  `id` CHAR(36) PRIMARY KEY,
  `user_id` CHAR(36) NOT NULL,
  `account_id` CHAR(36) NOT NULL,
  `currency_code` char(3) NOT NULL,
  `name` varchar(120) NOT NULL,
  `target_amount` decimal(18,2) NOT NULL,
  `target_date` date,
  `is_active` boolean NOT NULL DEFAULT true,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `goal_reservations` (
  `id` CHAR(36) PRIMARY KEY,
  `saving_goal_id` CHAR(36) NOT NULL,
  `amount_delta` decimal(18,2) NOT NULL COMMENT 'Positivo reserva; negativo libera. No afecta el saldo de cuenta.',
  `reserved_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `note` varchar(255)
);

CREATE INDEX `accounts_index_0` ON `accounts` (`user_id`, `status`);

CREATE UNIQUE INDEX `debit_cards_index_1` ON `debit_cards` (`account_id`, `last_four`);

CREATE INDEX `credit_cards_index_2` ON `credit_cards` (`user_id`, `status`);

CREATE INDEX `financial_transactions_index_3` ON `financial_transactions` (`user_id`, `occurred_at`);

CREATE INDEX `account_entries_index_4` ON `account_entries` (`account_id`, `created_at`);

CREATE UNIQUE INDEX `categories_index_5` ON `categories` (`user_id`, `kind`, `name`);

CREATE INDEX `expense_payments_index_6` ON `expense_payments` (`expense_transaction_id`);

CREATE UNIQUE INDEX `expense_splits_index_7` ON `expense_splits` (`expense_transaction_id`, `party_id`);

CREATE INDEX `bills_index_8` ON `bills` (`user_id`, `status`, `due_on`);

CREATE UNIQUE INDEX `credit_card_cycles_index_9` ON `credit_card_cycles` (`credit_card_id`, `closes_on`);

CREATE UNIQUE INDEX `card_installments_index_10` ON `card_installments` (`installment_plan_id`, `installment_number`);

CREATE UNIQUE INDEX `parties_index_11` ON `parties` (`user_id`);

CREATE UNIQUE INDEX `parties_index_12` ON `parties` (`external_contact_id`);

CREATE INDEX `debt_payment_sources_index_13` ON `debt_payment_sources` (`debt_payment_id`);

CREATE UNIQUE INDEX `friendships_index_14` ON `friendships` (`requester_user_id`, `addressee_user_id`);

ALTER TABLE `expense_payments` COMMENT = 'CHECK: exactamente uno de account_id, debit_card_id, credit_card_id es NOT NULL. CHECK amount > 0. La suma de las filas por expense_transaction_id debe ser expenses.total_amount. Para debito, el asiento sale de debit_cards.account_id.';

ALTER TABLE `expense_splits` COMMENT = 'CHECK amount > 0. La suma de las partes debe ser expenses.total_amount. generated_debt_id es opcional; si existe, corresponde a la parte de ese participante y no debe crear una segunda deuda.';

ALTER TABLE `refund_allocations` COMMENT = 'CHECK: exactamente uno de account_id y credit_card_id es NOT NULL. CHECK amount > 0. La suma de asignaciones debe ser refunds.amount.';

ALTER TABLE `credit_card_charges` COMMENT = 'CHECK: exactamente uno de expense_payment_id y debt_payment_source_id es NOT NULL. La fuente elegida debe tener credit_card_id NOT NULL. La tarjeta se obtiene de esa fuente; principal_amount debe coincidir con su importe.';

ALTER TABLE `parties` COMMENT = 'CHECK: exactamente uno de user_id y external_contact_id es NOT NULL.';

ALTER TABLE `debt_payments` COMMENT = 'financial_transactions.occurred_at es la fecha de pago. CHECK amount > 0. La suma de debt_payment_sources.amount debe ser amount. Si se usa credito, baja esta deuda y nace un cargo en la tarjeta; no se crea un gasto.';

ALTER TABLE `debt_payment_sources` COMMENT = 'CHECK: exactamente uno de account_id, debit_card_id, credit_card_id es NOT NULL. CHECK amount > 0. Cuenta o debito crea account_entry negativo. Credito crea credit_card_charge sin salida inmediata de una cuenta.';

ALTER TABLE `accounts` ADD FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

ALTER TABLE `accounts` ADD FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`);

ALTER TABLE `accounts` ADD FOREIGN KEY (`currency_code`) REFERENCES `currencies` (`code`);

ALTER TABLE `debit_cards` ADD FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`);

ALTER TABLE `credit_cards` ADD FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

ALTER TABLE `credit_cards` ADD FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`);

ALTER TABLE `credit_cards` ADD FOREIGN KEY (`currency_code`) REFERENCES `currencies` (`code`);

ALTER TABLE `financial_transactions` ADD FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

ALTER TABLE `financial_transactions` ADD FOREIGN KEY (`currency_code`) REFERENCES `currencies` (`code`);

ALTER TABLE `account_entries` ADD FOREIGN KEY (`transaction_id`) REFERENCES `financial_transactions` (`id`);

ALTER TABLE `account_entries` ADD FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`);

ALTER TABLE `categories` ADD FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

ALTER TABLE `expenses` ADD FOREIGN KEY (`transaction_id`) REFERENCES `financial_transactions` (`id`);

ALTER TABLE `expenses` ADD FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

ALTER TABLE `expense_splits` ADD FOREIGN KEY (`expense_transaction_id`) REFERENCES `expenses` (`transaction_id`);

ALTER TABLE `expense_splits` ADD FOREIGN KEY (`party_id`) REFERENCES `parties` (`id`);

ALTER TABLE `expense_splits` ADD FOREIGN KEY (`generated_debt_id`) REFERENCES `debts` (`id`);

ALTER TABLE `expense_payments` ADD FOREIGN KEY (`expense_transaction_id`) REFERENCES `expenses` (`transaction_id`);

ALTER TABLE `expense_payments` ADD FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`);

ALTER TABLE `expense_payments` ADD FOREIGN KEY (`debit_card_id`) REFERENCES `debit_cards` (`id`);

ALTER TABLE `expense_payments` ADD FOREIGN KEY (`credit_card_id`) REFERENCES `credit_cards` (`id`);

ALTER TABLE `incomes` ADD FOREIGN KEY (`transaction_id`) REFERENCES `financial_transactions` (`id`);

ALTER TABLE `incomes` ADD FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

ALTER TABLE `transfers` ADD FOREIGN KEY (`transaction_id`) REFERENCES `financial_transactions` (`id`);

ALTER TABLE `transfers` ADD FOREIGN KEY (`source_account_id`) REFERENCES `accounts` (`id`);

ALTER TABLE `transfers` ADD FOREIGN KEY (`destination_account_id`) REFERENCES `accounts` (`id`);

ALTER TABLE `refunds` ADD FOREIGN KEY (`transaction_id`) REFERENCES `financial_transactions` (`id`);

ALTER TABLE `refunds` ADD FOREIGN KEY (`expense_transaction_id`) REFERENCES `expenses` (`transaction_id`);

ALTER TABLE `refund_allocations` ADD FOREIGN KEY (`refund_transaction_id`) REFERENCES `refunds` (`transaction_id`);

ALTER TABLE `refund_allocations` ADD FOREIGN KEY (`expense_payment_id`) REFERENCES `expense_payments` (`id`);

ALTER TABLE `refund_allocations` ADD FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`);

ALTER TABLE `refund_allocations` ADD FOREIGN KEY (`credit_card_id`) REFERENCES `credit_cards` (`id`);

ALTER TABLE `recurring_rules` ADD FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

ALTER TABLE `recurring_rules` ADD FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

ALTER TABLE `recurring_rules` ADD FOREIGN KEY (`currency_code`) REFERENCES `currencies` (`code`);

ALTER TABLE `bills` ADD FOREIGN KEY (`recurring_rule_id`) REFERENCES `recurring_rules` (`id`);

ALTER TABLE `bills` ADD FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

ALTER TABLE `bills` ADD FOREIGN KEY (`currency_code`) REFERENCES `currencies` (`code`);

ALTER TABLE `bills` ADD FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

ALTER TABLE `bills` ADD FOREIGN KEY (`paid_expense_transaction_id`) REFERENCES `expenses` (`transaction_id`);

ALTER TABLE `credit_card_cycles` ADD FOREIGN KEY (`credit_card_id`) REFERENCES `credit_cards` (`id`);

ALTER TABLE `credit_card_charges` ADD FOREIGN KEY (`expense_payment_id`) REFERENCES `expense_payments` (`id`);

ALTER TABLE `credit_card_charges` ADD FOREIGN KEY (`debt_payment_source_id`) REFERENCES `debt_payment_sources` (`id`);

ALTER TABLE `credit_card_charges` ADD FOREIGN KEY (`initial_cycle_id`) REFERENCES `credit_card_cycles` (`id`);

ALTER TABLE `installment_plans` ADD FOREIGN KEY (`credit_card_charge_id`) REFERENCES `credit_card_charges` (`id`);

ALTER TABLE `card_installments` ADD FOREIGN KEY (`installment_plan_id`) REFERENCES `installment_plans` (`id`);

ALTER TABLE `card_installments` ADD FOREIGN KEY (`credit_card_cycle_id`) REFERENCES `credit_card_cycles` (`id`);

ALTER TABLE `credit_card_payments` ADD FOREIGN KEY (`transaction_id`) REFERENCES `financial_transactions` (`id`);

ALTER TABLE `credit_card_payments` ADD FOREIGN KEY (`credit_card_id`) REFERENCES `credit_cards` (`id`);

ALTER TABLE `credit_card_payments` ADD FOREIGN KEY (`credit_card_cycle_id`) REFERENCES `credit_card_cycles` (`id`);

ALTER TABLE `credit_card_interests` ADD FOREIGN KEY (`transaction_id`) REFERENCES `financial_transactions` (`id`);

ALTER TABLE `credit_card_interests` ADD FOREIGN KEY (`credit_card_id`) REFERENCES `credit_cards` (`id`);

ALTER TABLE `credit_card_interests` ADD FOREIGN KEY (`credit_card_cycle_id`) REFERENCES `credit_card_cycles` (`id`);

ALTER TABLE `external_contacts` ADD FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`id`);

ALTER TABLE `parties` ADD FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

ALTER TABLE `parties` ADD FOREIGN KEY (`external_contact_id`) REFERENCES `external_contacts` (`id`);

ALTER TABLE `debts` ADD FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`);

ALTER TABLE `debts` ADD FOREIGN KEY (`creditor_party_id`) REFERENCES `parties` (`id`);

ALTER TABLE `debts` ADD FOREIGN KEY (`debtor_party_id`) REFERENCES `parties` (`id`);

ALTER TABLE `debts` ADD FOREIGN KEY (`currency_code`) REFERENCES `currencies` (`code`);

ALTER TABLE `debt_payments` ADD FOREIGN KEY (`debt_id`) REFERENCES `debts` (`id`);

ALTER TABLE `debt_payments` ADD FOREIGN KEY (`transaction_id`) REFERENCES `financial_transactions` (`id`);

ALTER TABLE `debt_payment_sources` ADD FOREIGN KEY (`debt_payment_id`) REFERENCES `debt_payments` (`id`);

ALTER TABLE `debt_payment_sources` ADD FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`);

ALTER TABLE `debt_payment_sources` ADD FOREIGN KEY (`debit_card_id`) REFERENCES `debit_cards` (`id`);

ALTER TABLE `debt_payment_sources` ADD FOREIGN KEY (`credit_card_id`) REFERENCES `credit_cards` (`id`);

ALTER TABLE `friendships` ADD FOREIGN KEY (`requester_user_id`) REFERENCES `users` (`id`);

ALTER TABLE `friendships` ADD FOREIGN KEY (`addressee_user_id`) REFERENCES `users` (`id`);

ALTER TABLE `groups` ADD FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`id`);

ALTER TABLE `group_members` ADD FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`);

ALTER TABLE `group_members` ADD FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

ALTER TABLE `pools` ADD FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`);

ALTER TABLE `pools` ADD FOREIGN KEY (`currency_code`) REFERENCES `currencies` (`code`);

ALTER TABLE `pool_contributions` ADD FOREIGN KEY (`pool_id`) REFERENCES `pools` (`id`);

ALTER TABLE `pool_contributions` ADD FOREIGN KEY (`member_user_id`) REFERENCES `users` (`id`);

ALTER TABLE `pool_contributions` ADD FOREIGN KEY (`transaction_id`) REFERENCES `financial_transactions` (`id`);

ALTER TABLE `pool_expenses` ADD FOREIGN KEY (`pool_id`) REFERENCES `pools` (`id`);

ALTER TABLE `pool_expenses` ADD FOREIGN KEY (`paid_by_user_id`) REFERENCES `users` (`id`);

ALTER TABLE `pool_expenses` ADD FOREIGN KEY (`transaction_id`) REFERENCES `financial_transactions` (`id`);

ALTER TABLE `saving_goals` ADD FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

ALTER TABLE `saving_goals` ADD FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`);

ALTER TABLE `saving_goals` ADD FOREIGN KEY (`currency_code`) REFERENCES `currencies` (`code`);

ALTER TABLE `goal_reservations` ADD FOREIGN KEY (`saving_goal_id`) REFERENCES `saving_goals` (`id`);
