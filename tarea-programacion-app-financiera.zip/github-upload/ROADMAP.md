# Estado del gestor — fase 3

Consultar `FASE3_ESTADO.md` para la entrega y sus evidencias; `FASE2_ESTADO.md` registra las pruebas funcionales previas y `FASE1_ESTADO.md` la instalación.

## Implementado y probado

- Dashboard: patrimonio, cuentas, reservas, crédito, préstamos, participación en vaquitas y gráficos de seis meses/categorías.
- Cuentas: saldo inicial separado de ingresos, edición, archivo con saldo cero y restauración; débito asociado con estados y vencimiento.
- Crédito: financiación decimal, última cuota ajustada, ciclos mensuales, cierres, intereses sobre saldos vencidos, pagos asignados y estados de cuotas.
- Recurrentes: generación recuperable hasta 30 días por adelantado, calendario con día ancla, promedio de los últimos tres pagos, pausa, edición y pago único de facturas.
- Movimientos: ingresos, gastos divididos, transferencias, reintegros, edición con revisión y anulaciones auditadas mediante contrapartidas.
- Deudas: entrega opcional del préstamo, interés simple diario, pagos parciales desde cuenta/débito/crédito; anulación de pagos en orden inverso.
- Presupuesto por categoría/mes, archivo sin borrar importes, promedio de tres meses completos y proyección sin duplicar obligaciones.
- Metas: reservas disponibles, liberación, edición y archivo con devolución de la reserva.
- Grupos: invitaciones aceptadas dentro de la aplicación, vaquitas, aportes/retiros, gastos repartidos con redondeo exacto y privacidad entre usuarios.
- Historial filtrado y paginado; reportes reales CSV/PDF; perfil, contraseña, tema y privacidad visual.
- Formularios: CSRF, claves de operación atómicas, borradores temporales sin contraseñas, estados de envío y confirmaciones.

## Verificación final y límites

- QA con Brave/Playwright: 21 pantallas a 375, 768 y 1440 px; corregidos el desbordamiento de Presupuesto, las tarjetas estrechas, el foco móvil y el contraste secundario. Sin errores JS/500 ni desbordamientos de página detectados en la ronda final. No se probaron dispositivos físicos ni otros motores de navegador.
- Recuperación real tras respuesta interrumpida y reintento sin duplicados; saldo y persistencia comprobados desde otra conexión. Datos originales conservados por comparación SHA-256. Pruebas aisladas y eliminadas al terminar.
- PDF de cinco páginas y exportación vacía renderizados y revisados. Evidencias locales en `backups/fase3/`; Flask y MariaDB permanecen activos.
- Automatización cada minuto mientras `python app.py` permanece activo y recuperación al acceder; no funciona con Flask apagado.
- Convenciones explícitas: financiación simple, interés mensual anual/12 y mínimo orientativo del 5 %; préstamos con base diaria de 365 días. No son una conciliación bancaria.
- Moneda operativa: PYG, sin conversión. Invitaciones locales, sin envío de correo.
- Los planes antiguos con pagos/cierres inconsistentes se conservan para revisión manual; en esta base no había planes que requirieran revisión.

Fase 3 entregada. La conciliación bancaria completa y las integraciones externas quedan fuera de este alcance.
