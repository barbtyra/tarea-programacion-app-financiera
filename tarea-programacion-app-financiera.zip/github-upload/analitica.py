"""Consultas reales para panel, historial, proyecciones y exportaciones."""
from datetime import date, timedelta
from decimal import Decimal

from conexion import obtener_conexion
from finanzas import CERO, consultar, estado_deuda, fecha, saldo_credito, sumar_meses

TIPOS = {'INCOME': 'Ingreso', 'INITIAL_BALANCE': 'Saldo inicial', 'EXPENSE': 'Gasto', 'TRANSFER': 'Transferencia',
         'CARD_PAYMENT': 'Pago de tarjeta', 'CARD_INTEREST': 'Interés de tarjeta', 'REFUND': 'Reintegro',
         'DEBT_DISBURSEMENT': 'Entrega de préstamo', 'DEBT_PAYMENT': 'Pago / cobro de deuda',
         'POOL_CONTRIBUTION': 'Aporte / retiro de vaquita', 'POOL_EXPENSE': 'Gasto de vaquita', 'ADJUSTMENT': 'Contrapartida'}


def datos(sql, params=(), uno=False):
    cn = obtener_conexion()
    try:
        cur = cn.cursor(dictionary=True)
        result = consultar(cur, sql, params, uno)
        cur.close()
        return result
    finally:
        cn.close()


def eventos(user, start, end):
    """Ingreso y gasto económicos; principal de préstamos, transferencias y pagos quedan fuera."""
    params = (user, start, end)
    income = datos('''SELECT DATE(ft.occurred_at) day,i.amount amount,c.name category,c.id category_id,'income' kind
 FROM incomes i JOIN financial_transactions ft ON ft.id=i.transaction_id JOIN categories c ON c.id=i.category_id
 WHERE ft.user_id=%s AND ft.type='INCOME' AND ft.voided_at IS NULL AND ft.occurred_at>=%s AND ft.occurred_at<%s''', params)
    expense = datos('''SELECT DATE(ft.occurred_at) day,e.total_amount amount,c.name category,c.id category_id,'expense' kind
 FROM expenses e JOIN financial_transactions ft ON ft.id=e.transaction_id JOIN categories c ON c.id=e.category_id
 WHERE ft.user_id=%s AND ft.voided_at IS NULL AND ft.occurred_at>=%s AND ft.occurred_at<%s''', params)
    refunds = datos('''SELECT DATE(ft.occurred_at) day,-r.amount amount,c.name category,c.id category_id,'expense' kind
 FROM refunds r JOIN financial_transactions ft ON ft.id=r.transaction_id JOIN expenses e ON e.transaction_id=r.expense_transaction_id
 JOIN categories c ON c.id=e.category_id WHERE ft.user_id=%s AND ft.voided_at IS NULL AND ft.occurred_at>=%s AND ft.occurred_at<%s''', params)
    interest = datos('''SELECT DATE(ft.occurred_at) day,ci.amount amount,'Intereses de tarjeta' category,NULL category_id,'expense' kind
 FROM credit_card_interests ci JOIN financial_transactions ft ON ft.id=ci.transaction_id
 WHERE ft.user_id=%s AND ft.voided_at IS NULL AND ft.occurred_at>=%s AND ft.occurred_at<%s''', params)
    financing = datos('''SELECT DATE(ft.occurred_at) day,ip.financed_total-cc.principal_amount amount,'Financiación en cuotas' category,NULL category_id,'expense' kind
 FROM installment_plans ip JOIN credit_card_charges cc ON cc.id=ip.credit_card_charge_id
 LEFT JOIN expense_payments ep ON ep.id=cc.expense_payment_id LEFT JOIN debt_payment_sources ds ON ds.id=cc.debt_payment_source_id
 LEFT JOIN debt_payments dp ON dp.id=ds.debt_payment_id JOIN financial_transactions ft ON ft.id=COALESCE(ep.expense_transaction_id,dp.transaction_id)
 WHERE ft.user_id=%s AND ft.voided_at IS NULL AND ft.occurred_at>=%s AND ft.occurred_at<%s AND ip.financed_total>cc.principal_amount''', params)
    loans = datos('''SELECT DATE(ft.occurred_at) day,dp.interest_amount amount,'Intereses de préstamos' category,NULL category_id,
 CASE WHEN p.user_id=ft.user_id THEN 'expense' ELSE 'income' END kind
 FROM debt_payments dp JOIN financial_transactions ft ON ft.id=dp.transaction_id JOIN debts d ON d.id=dp.debt_id JOIN parties p ON p.id=d.debtor_party_id
 WHERE ft.user_id=%s AND ft.voided_at IS NULL AND ft.occurred_at>=%s AND ft.occurred_at<%s AND dp.interest_amount>0''', params)
    shared = datos('''SELECT DATE(ft.occurred_at) day,s.amount amount,'Gastos de vaquitas' category,NULL category_id,'expense' kind
 FROM pool_expense_shares s JOIN pool_expenses pe ON pe.id=s.pool_expense_id JOIN financial_transactions ft ON ft.id=pe.transaction_id
 WHERE s.user_id=%s AND ft.voided_at IS NULL AND ft.occurred_at>=%s AND ft.occurred_at<%s''', params)
    return income + expense + refunds + interest + financing + loans + shared


def movimientos(user, filters=None):
    filters = filters or {}
    where, params = ['ft.user_id=%s', "ft.type<>'ADJUSTMENT'"], [user]
    if not filters.get('voided'):
        where.append('ft.voided_at IS NULL')
    if filters.get('start'):
        where.append('ft.occurred_at>=%s'); params.append(fecha(filters['start']))
    if filters.get('end'):
        where.append('ft.occurred_at<%s'); params.append(fecha(filters['end']) + timedelta(days=1))
    if filters.get('start') and filters.get('end') and filters['start'] > filters['end']:
        raise ValueError('La fecha final debe ser posterior a la fecha inicial.')
    if filters.get('type'):
        if filters['type'] not in TIPOS:
            raise ValueError('Seleccione un tipo de movimiento válido.')
        where.append('ft.type=%s'); params.append(filters['type'])
    if filters.get('q'):
        where.append('ft.description LIKE %s'); params.append('%' + filters['q'][:150] + '%')
    if filters.get('category_id'):
        where.append('COALESCE(i.category_id,e.category_id)=%s'); params.append(filters['category_id'])
    if filters.get('account_id'):
        where.append('EXISTS(SELECT 1 FROM account_entries ae WHERE ae.transaction_id=ft.id AND ae.account_id=%s)'); params.append(filters['account_id'])
    return datos('''SELECT ft.*,c.name category,COALESCE(i.amount,e.total_amount,tr.amount,cp.amount,ci.amount,dp.amount,r.amount,pc.amount,pe.amount,
 (SELECT SUM(ae.amount) FROM account_entries ae WHERE ae.transaction_id=ft.id),0) amount
 FROM financial_transactions ft LEFT JOIN incomes i ON i.transaction_id=ft.id LEFT JOIN expenses e ON e.transaction_id=ft.id
 LEFT JOIN categories c ON c.id=COALESCE(i.category_id,e.category_id) LEFT JOIN transfers tr ON tr.transaction_id=ft.id
 LEFT JOIN credit_card_payments cp ON cp.transaction_id=ft.id LEFT JOIN credit_card_interests ci ON ci.transaction_id=ft.id
 LEFT JOIN debt_payments dp ON dp.transaction_id=ft.id LEFT JOIN refunds r ON r.transaction_id=ft.id
 LEFT JOIN pool_contributions pc ON pc.transaction_id=ft.id LEFT JOIN pool_expenses pe ON pe.transaction_id=ft.id
 WHERE ''' + ' AND '.join(where) + ' ORDER BY ft.occurred_at DESC,ft.created_at DESC,ft.id', tuple(params))


def panel(user):
    today = date.today()
    month = today.replace(day=1)
    end = sumar_meses(month, 1)
    start = sumar_meses(month, -5)
    events = eventos(user, start, end)
    series, categories = [], {}
    for n in range(6):
        current = sumar_meses(start, n)
        next_month = sumar_meses(current, 1)
        selected = [e for e in events if current <= e['day'] < next_month]
        series.append({'month': current.strftime('%m/%Y'), 'income': sum((e['amount'] for e in selected if e['kind'] == 'income'), CERO),
                       'expense': sum((e['amount'] for e in selected if e['kind'] == 'expense'), CERO)})
    for e in events:
        if e['day'] >= month and e['kind'] == 'expense':
            categories[e['category']] = categories.get(e['category'], CERO) + e['amount']
    accounts = datos('''SELECT a.*,COALESCE(SUM(ae.amount),0) balance,
 COALESCE((SELECT SUM(gr.amount_delta) FROM goal_reservations gr JOIN saving_goals sg ON sg.id=gr.saving_goal_id WHERE sg.account_id=a.id AND sg.is_active=TRUE),0) reserved
 FROM accounts a LEFT JOIN account_entries ae ON ae.account_id=a.id WHERE a.user_id=%s GROUP BY a.id ORDER BY a.status,a.name''', (user,))
    cards = datos("SELECT * FROM credit_cards WHERE user_id=%s AND status<>'ARCHIVED'", (user,))
    cn = obtener_conexion()
    try:
        cur = cn.cursor(dictionary=True)
        credit = sum((saldo_credito(cur, c['id']) for c in cards), CERO)
        loans = [estado_deuda(cur, d['id'], user) for d in datos("SELECT id FROM debts WHERE created_by_user_id=%s AND status='OPEN'", (user,))]
        cur.close()
    finally:
        cn.close()
    payable = sum((d['pending'] for d in loans if d['payable']), CERO)
    receivable = sum((d['pending'] for d in loans if not d['payable']), CERO)
    contributions = datos('''SELECT COALESCE(SUM(pc.amount),0) n FROM pool_contributions pc JOIN financial_transactions ft ON ft.id=pc.transaction_id
 WHERE pc.member_user_id=%s AND ft.voided_at IS NULL''', (user,), True)['n']
    shares = datos('''SELECT COALESCE(SUM(s.amount),0) n FROM pool_expense_shares s JOIN pool_expenses pe ON pe.id=s.pool_expense_id JOIN financial_transactions ft ON ft.id=pe.transaction_id
 WHERE s.user_id=%s AND ft.voided_at IS NULL''', (user,), True)['n']
    pool_asset = contributions - shares
    balance = sum((a['balance'] for a in accounts if a['currency_code'] == 'PYG'), CERO)
    reserved = sum((a['reserved'] for a in accounts if a['currency_code'] == 'PYG'), CERO)
    return dict(saldo=balance, reservado=reserved, disponible=balance-reserved, patrimonio=balance+receivable+pool_asset-credit-payable,
                credito=credit, por_pagar=payable, por_cobrar=receivable, en_vaquitas=pool_asset, ingresos=series[-1]['income'], gastos=series[-1]['expense'],
                series=series, chart_max=max([abs(s[k]) for s in series for k in ['income','expense']] + [Decimal(1)]),
                por_categoria=sorted(categories.items(), key=lambda x: x[1], reverse=True), cuentas=accounts,
                movimientos=movimientos(user)[:8], facturas=datos("SELECT * FROM bills WHERE user_id=%s AND status IN ('PENDING','OVERDUE') ORDER BY due_on LIMIT 5", (user,)))
