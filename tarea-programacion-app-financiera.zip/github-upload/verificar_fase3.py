"""QA de navegador y PDF con datos sintéticos en un esquema desechable."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
from datetime import date, timedelta
from urllib.request import urlopen
from urllib.error import URLError
from uuid import uuid4

import mysql.connector

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'backups' / 'fase3'
BASE = 'http://127.0.0.1:5001'


def seed():
    import verificar_fase1 as helper
    helper.BASE = BASE
    original = helper.Cliente.pedir

    def pedir(self, path, data=None, error=False):
        if data is not None:
            if not getattr(self, 'csrf', None): self.pedir('/login')
            data = {'_csrf': self.csrf, '_request_id': str(uuid4()), **data}
        html = original(self, path, data, error)
        found = re.search(r'name="_csrf" value="([^"]+)"', html)
        if found: self.csrf = found[1]
        return html

    helper.Cliente.pedir = pedir
    c = helper.Cliente()
    email = 'visual-fase3@example.invalid'
    c.pedir('/registro', {'full_name': 'Usuario de prueba visual', 'email': email,
                          'password': 'PruebaVisual-2026', 'password_confirmation': 'PruebaVisual-2026'})
    one = helper.uno
    user = one('SELECT id FROM users WHERE email=%s', (email,))['id']
    cash = one("SELECT id FROM accounts WHERE user_id=%s AND type='CASH'", (user,))['id']
    inc = one("SELECT id FROM categories WHERE kind='INCOME' AND user_id IS NULL LIMIT 1")['id']
    exp = one("SELECT id FROM categories WHERE kind='EXPENSE' AND user_id IS NULL LIMIT 1")['id']
    c.pedir('/cuentas', {'name': 'Ahorros para proyectos personales', 'institution': 'Entidad de prueba',
                         'type': 'SAVINGS', 'initial_balance': '2350000.55'})
    bank = one("SELECT id FROM accounts WHERE user_id=%s AND type='SAVINGS'", (user,))['id']
    c.pedir('/tarjetas-debito', {'account_id': bank, 'brand': 'Débito de prueba', 'last_four': '1234', 'status': 'ACTIVE'})
    c.pedir('/tarjetas-credito', {'name': 'Crédito para compras planificadas', 'last_four': '5678',
            'credit_limit': '5000000', 'annual_interest_rate': '24', 'closing_day': '25', 'due_day': '5', 'status': 'ACTIVE'})
    card = one('SELECT id FROM credit_cards WHERE user_id=%s', (user,))['id']
    today = date.today()
    from finanzas import sumar_meses
    for index in range(-5, 1):
        on = min(today, sumar_meses(today.replace(day=1), index) + timedelta(days=9)).isoformat()
        c.pedir('/ingresos', {'account_id': cash, 'category_id': inc, 'amount': str(4000000 + index * 100000),
            'description': 'Ingreso de prueba visual ' + str(index), 'occurred_at': on})
        c.pedir('/gastos', {'category_id': exp, 'amount': str(550000 + index * 15000),
            'description': 'Compra de prueba visual ' + str(index), 'occurred_at': on,
            'payment_method': 'ACCOUNT:' + cash, 'payment_amount': str(550000 + index * 15000)})
    c.pedir('/gastos', {'category_id': exp, 'amount': '1500000.01', 'description': 'Equipo para el hogar · prueba de cuotas',
        'occurred_at': today.isoformat(), 'payment_method': 'CREDIT:' + card, 'payment_amount': '1500000.01',
        'installment_count': '3', 'interest_free': '1'})
    tx = one('SELECT id FROM financial_transactions WHERE user_id=%s AND description=%s',
             (user, 'Equipo para el hogar · prueba de cuotas'))['id']
    for index in range(24):
        description = f'Revisión PDF {index + 1:02} · Ñandutí, café y artículos para el hogar. ' + 'Detalle largo para comprobar saltos de línea y conservación del contenido. ' * 2
        c.pedir('/gastos', {'category_id': exp, 'amount': '12345.67', 'description': description,
            'occurred_at': today.isoformat(), 'payment_method': 'ACCOUNT:' + cash, 'payment_amount': '12345.67'})
    c.pedir('/facturas', {'name': 'Servicio de internet del hogar', 'category_id': exp, 'frequency': 'MONTHLY',
            'expected_amount': '185000', 'next_due_on': (today + timedelta(days=2)).isoformat()})
    c.pedir('/deudas', {'contact_name': 'Contacto de prueba', 'direction': 'PAYABLE', 'original_amount': '250000',
            'annual_interest_rate': '12', 'issued_on': today.isoformat(), 'description': 'Préstamo de prueba visual'})
    c.pedir('/metas', {'name': 'Fondo de tranquilidad y emergencias', 'account_id': bank, 'target_amount': '5000000',
            'target_date': (today + timedelta(days=180)).isoformat()})
    goal = one('SELECT id FROM saving_goals WHERE user_id=%s', (user,))['id']
    c.pedir('/metas/' + goal + '/reservar', {'amount': '650000', 'action': 'reserve'})
    c.pedir('/presupuesto/guardar', {'month': today.strftime('%Y-%m'), 'category_id': exp, 'amount': '2500000'})
    c.pedir('/grupos', {'name': 'Proyecto compartido de prueba'})
    group = one('SELECT id FROM `groups` WHERE owner_user_id=%s', (user,))['id']
    c.pedir('/grupos/' + group + '/vaquitas', {'name': 'Vacaciones en familia', 'target_amount': '3000000'})
    pool = one('SELECT id FROM pools WHERE group_id=%s', (group,))['id']
    c.pedir('/vaquitas/' + pool + '/aportar', {'account_id': cash, 'amount': '350000', 'occurred_at': today.isoformat(), 'action': 'contribute'})
    config = {'base': BASE, 'email': email, 'password': 'PruebaVisual-2026', 'user': user, 'cash': cash, 'bank': bank,
              'card': card, 'tx': tx, 'group': group, 'pool': pool, 'expense_category': exp, 'output': str(OUT)}
    (OUT / 'contexto.json').write_text(json.dumps(config), encoding='utf-8')
    with c.http.open(BASE + '/reportes.pdf?start=' + today.replace(month=1, day=1).isoformat() + '&end=' + today.isoformat()) as response:
        (OUT / 'reporte-prueba.pdf').write_bytes(response.read())
    print('Datos sintéticos preparados; PDF descargado desde Flask.', flush=True)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    db = 'app_finanzas_pruebas_fase3_' + uuid4().hex[:10]
    admin = mysql.connector.connect(host='127.0.0.1', user='root', password='')
    server = log = None
    dump_command = ['C:/xampp/mysql/bin/mysqldump.exe', '--host=127.0.0.1', '--user=root', '--no-create-info',
                    '--skip-comments', '--skip-extended-insert', '--order-by-primary', 'app_finanzas']
    before = subprocess.run(dump_command, check=True, capture_output=True).stdout
    try:
        cur = admin.cursor(); cur.execute('CREATE DATABASE `' + db + '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci'); cur.close()
        shape = subprocess.run(['C:/xampp/mysql/bin/mysqldump.exe', '--host=127.0.0.1', '--user=root', '--no-data',
                                '--default-character-set=utf8mb4', 'app_finanzas'], check=True, capture_output=True).stdout
        subprocess.run(['C:/xampp/mysql/bin/mysql.exe', '--host=127.0.0.1', '--user=root', db], input=shape, check=True)
        os.environ['DB_NAME'] = db
        env = {**os.environ, 'FLASK_DEBUG': '0', 'PYTHONIOENCODING': 'utf-8'}
        log = (OUT / 'flask-pruebas.log').open('w', encoding='utf-8')
        server = subprocess.Popen([sys.executable, '-m', 'flask', '--app', 'app', 'run', '--host', '127.0.0.1',
                '--port', '5001', '--no-reload'], cwd=ROOT, env=env, stdout=log, stderr=log,
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        for _ in range(100):
            if server.poll() is not None: raise RuntimeError('Flask de prueba no inició')
            try:
                with urlopen(BASE + '/login', timeout=1): break
            except (URLError, TimeoutError): time.sleep(.2)
        else: raise RuntimeError('Flask de prueba no responde')
        seed()
        from verificar_fase1 import uno, saldo
        config = json.loads((OUT / 'contexto.json').read_text(encoding='utf-8'))
        balance_before = saldo(config['cash'])
        subprocess.run(['node', str(ROOT / 'verificar_navegador.cjs'), str(OUT / 'contexto.json')], check=True)
        from decimal import Decimal
        assert saldo(config['cash']) == balance_before - Decimal('52.37')
        assert uno('SELECT COUNT(*) n FROM financial_transactions WHERE user_id=%s AND description=%s',
                   (config['user'], 'Respuesta interrumpida fase 3'))['n'] == 1
        assert uno('SELECT COUNT(*) n FROM financial_transactions WHERE user_id=%s AND description=%s',
                   (config['user'], 'Formulario que debe conservarse'))['n'] == 0
        assert uno('SELECT theme FROM user_preferences WHERE user_id=%s', (config['user'],))['theme'] == 'dark'
        print('Persistencia independiente: una operación de 52.37, sin duplicado; validación fallida sin asientos; preferencia guardada.', flush=True)
        print('Navegador: comprobaciones terminadas.', flush=True)
    finally:
        if server:
            server.terminate()
            try: server.wait(timeout=8)
            except subprocess.TimeoutExpired: server.kill(); server.wait()
        if log: log.close()
        assert re.fullmatch(r'app_finanzas_pruebas_fase3_[a-f0-9]{10}', db)
        cur = admin.cursor(); cur.execute('DROP DATABASE `' + db + '`'); cur.close(); admin.close()
        after = subprocess.run(dump_command, check=True, capture_output=True).stdout
        def inserts(value): return b'\n'.join(line for line in value.splitlines() if line.startswith(b'INSERT INTO'))
        assert hashlib.sha256(inserts(before)).digest() == hashlib.sha256(inserts(after)).digest(), 'Los datos reales cambiaron durante QA'
        print('Esquema temporal eliminado. Datos reales sin cambios (SHA-256).', flush=True)


if __name__ == '__main__': main()
