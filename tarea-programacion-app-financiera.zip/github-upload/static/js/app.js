(() => {
  'use strict';
  const body=document.body, menu=document.querySelector('.menu-toggle');
  const sidebar=document.querySelector('.sidebar'),shell=document.querySelector('.app-shell');
  const mobile=window.matchMedia('(max-width:960px)');
  function closeMenu(restoreFocus=true){
    const wasOpen=body.classList.contains('nav-open');
    body.classList.remove('nav-open');menu?.setAttribute('aria-expanded','false');
    if(shell)shell.inert=false;
    if(sidebar)sidebar.inert=mobile.matches;
    if(wasOpen&&restoreFocus)menu?.focus();
  }
  menu?.addEventListener('click',()=>{
    if(body.classList.contains('nav-open')){closeMenu();return;}
    body.classList.add('nav-open');menu.setAttribute('aria-expanded','true');
    if(sidebar){sidebar.inert=false;sidebar.querySelector('nav a')?.focus();}
    if(shell)shell.inert=true;
  });
  document.querySelector('.fondo-nav')?.addEventListener('click',()=>closeMenu());
  mobile.addEventListener('change',()=>closeMenu(false));closeMenu(false);
  document.addEventListener('keydown',e=>{
    if(e.key==='Escape')closeMenu();
    if(e.key==='Tab'&&body.classList.contains('nav-open')&&sidebar){
      const links=[...sidebar.querySelectorAll('a[href],button:not([disabled])')];
      if(e.shiftKey&&document.activeElement===links[0]){e.preventDefault();links.at(-1)?.focus();}
      else if(!e.shiftKey&&document.activeElement===links.at(-1)){e.preventDefault();links[0]?.focus();}
    }
  });
  document.querySelectorAll('.table-scroll').forEach(region=>{
    region.tabIndex=0;region.setAttribute('role','region');
    region.setAttribute('aria-label','Tabla con desplazamiento horizontal');
  });
  document.querySelector('#toggle-balances')?.addEventListener('click',()=>body.classList.toggle('ocultar-saldos'));
  const heading=document.querySelector('h1');if(heading&&document.querySelector('#page-label'))document.querySelector('#page-label').textContent=heading.textContent;
  const prefix='balance:'+body.dataset.user+':';
  const parse=text=>{try{return JSON.parse(text);}catch{return null;}};
  const store={get:key=>{try{return parse(sessionStorage.getItem(key));}catch{return null;}},set:(key,value)=>{try{sessionStorage.setItem(key,JSON.stringify(value));}catch{}},remove:key=>{try{sessionStorage.removeItem(key);}catch{}}};
  const keys=()=>{try{return Object.keys(sessionStorage);}catch{return[];}};
  const completed=parse(document.querySelector('#completed-operation')?.textContent||'null');
  if(completed)for(const key of keys())if(key.startsWith(prefix)&&store.get(key)?.requestId===completed)store.remove(key);
  document.querySelectorAll('[data-logout]').forEach(link=>link.addEventListener('click',()=>{for(const key of keys())if(key.startsWith('balance:'))store.remove(key);}));
  const posted=parse(document.querySelector('#form-state')?.textContent||'{}')||{};
  const hasError=!!document.querySelector('.mensaje.error');
  const excluded=name=>!name||/password|_csrf|_request_id/i.test(name);
  const dialog=document.querySelector('#confirm-dialog');let pending=null;
  const actionCounts=new Map();
  document.querySelector('#confirm-cancel')?.addEventListener('click',()=>{dialog.close();pending=null;});
  document.querySelector('#confirm-accept')?.addEventListener('click',()=>{if(!pending)return;const{form,submitter}=pending;pending=null;dialog.close();form.dataset.confirmed='true';form.requestSubmit(submitter||undefined);});
  dialog?.addEventListener('cancel',()=>{pending=null;});
  for(const[index,form]of[...document.querySelectorAll('form')].entries()){
    if(form.method.toLowerCase()!=='post')continue;
    const action=new URL(form.action,location.href).pathname;
    const occurrence=actionCounts.get(action)||0;actionCounts.set(action,occurrence+1);
    const key=prefix+body.dataset.path+':'+(form.dataset.formId||`${action}:${occurrence}`);
    const draft=store.get(key),valid=draft&&Date.now()-draft.time<12*3600*1000;
    const values=hasError&&form===document.querySelector('form[method="post"]')&&Object.keys(posted).length?posted:(valid?draft.values:null);
    if(values){
      const count=values.payment_method?.length||0,template=document.querySelector('#medio-template'),rows=form.querySelector('#medios-pago');
      if(rows&&template)while(rows.children.length<Math.min(count,20))rows.appendChild(template.content.cloneNode(true));
      for(const name of Object.keys(values)){
        if(excluded(name))continue;
        [...form.elements].filter(el=>el.name===name&&el.type!=='hidden').forEach((el,i)=>{
          if(el.type==='checkbox'||el.type==='radio')el.checked=values[name].includes(el.value);
          else if(values[name][i]!==undefined&&!['submit','button','file'].includes(el.type))el.value=values[name][i];
        });
      }
      if(valid&&draft.requestId&&!hasError&&form.elements._request_id)form.elements._request_id.value=draft.requestId;
      const note=document.createElement('p');note.className='draft-note';note.textContent='Borrador recuperado en esta pestaña. Las contraseñas no se conservan.';form.append(note);
    }
    function save(){
      const values={};
      for(const el of form.elements){
        if(excluded(el.name)||['submit','button','file','hidden'].includes(el.type))continue;
        if((el.type==='checkbox'||el.type==='radio')&&!el.checked){values[el.name]||=[];continue;}
        (values[el.name]||=[]).push(el.value);
      }
      store.set(key,{time:Date.now(),values,requestId:form.elements._request_id?.value,submitted:form.dataset.submitted==='true'});
    }
    form.addEventListener('input',()=>{if(form.dataset.submitted==='true'){if(form.elements._request_id)form.elements._request_id.value=crypto.randomUUID();delete form.dataset.submitted;}save();});
    form.addEventListener('change',save);
    form.addEventListener('submit',e=>{
      if(form.dataset.busy==='true'){e.preventDefault();return;}
      const confirm=form.dataset.confirm||/\/(anular|eliminar|cancelar|archivar|quitar)$/.test(action);
      if(confirm&&form.dataset.confirmed!=='true'){
        e.preventDefault();
        if(dialog?.showModal){pending={form,submitter:e.submitter};document.querySelector('#confirm-message').textContent=form.dataset.confirm||'Los saldos se actualizarán. Las anulaciones conservan el movimiento y su contrapartida.';dialog.showModal();}
        else if(window.confirm(form.dataset.confirm||'¿Confirma esta operación?')){form.dataset.confirmed='true';form.requestSubmit(e.submitter||undefined);}
        return;
      }
      form.dataset.busy='true';form.dataset.submitted='true';save();
      if(e.submitter?.name){const hidden=document.createElement('input');hidden.type='hidden';hidden.name=e.submitter.name;hidden.value=e.submitter.value;form.append(hidden);}
      for(const button of form.querySelectorAll('button[type="submit"],button:not([type]),input[type="submit"]')){button.disabled=true;button.setAttribute('aria-busy','true');}
      if(e.submitter)e.submitter.textContent='Guardando…';
    });
  }
  window.addEventListener('pageshow',e=>{if(e.persisted)location.reload();});
})();
