# Fase 2 — 20/10/2026

Implementación funcional operativa; falta QA visual real porque la captura del navegador agotó el tiempo de espera. No se inició fase 3.

- Cambiados: `app.py`, `avanzado.py`, `conexion.py`, plantillas, CSS/JS y pruebas. Nuevos: `finanzas.py`, `analitica.py`, `gestion.py`, `automatizacion.py`, `experiencia.py`, `migrar_datos_fase2.py`, `migracion_fase2.sql`.
- Esquema: 45 tablas, 95 FK. Ampliadas `financial_transactions`, `debts`, `debt_payments`, `recurring_rules`. Nuevas: `user_preferences`, `category_budgets`, `operation_receipts`, `transaction_audit`, `card_payment_allocations`, `automation_events`, `group_invitations`, `pool_expense_shares`.
- Funciones probadas: dashboard/gráficos, cuentas/débito, crédito/cuotas/ciclos/intereses/pagos, recurrentes, préstamos, presupuestos trimestrales, metas, grupos/vaquitas, filtros, CSV/PDF, perfil/contraseña/preferencias, ediciones y anulaciones auditadas.
- Integridad: Decimal; redondeo final exacto; transferencias y capital no son ingresos/gastos; pagos de tarjeta no duplican gastos; reintegros reducen gastos. CSRF y recibos atómicos evitan duplicados; reservas y permisos se validan. Pagos de deuda se anulan en orden inverso.
- Pruebas: `python verificar_fase2.py`, regresión previa y 10 grupos ampliados HTTP/MariaDB en base temporal eliminada; `node verificar_formularios.cjs`, 6 grupos DOM. jsdom sólo en `%TEMP%\balance-fase2-dom-tests`; sin nuevas dependencias de ejecución. Registros: `verificacion_fase2.log`, `verificacion_formularios.log`. Hashes de los datos originales coinciden con el respaldo previo.
- Automatización: al acceder y cada minuto con Flask activo; facturas hasta 30 días. Crédito: financiación simple, interés anual/12, mínimo estimado 5 %. Préstamos: interés simple diario/365. Sólo PYG; invitaciones locales.
- Respaldos anteriores en `backups/*antes_fase2*`; `.secret_key` persistente excluida de Git. Inicio: `.\.venv\Scripts\python.exe app.py`; URL http://127.0.0.1:5000. XAMPP/MariaDB sin cambios de infraestructura.

Fase 3: QA visual y accesibilidad reales; contrastar convenciones con extractos bancarios y añadir conciliación.
