# App financiera — Tarea de programación

Aplicación de finanzas personales desarrollada con Python, Flask y MariaDB. Permite gestionar ingresos, gastos, cuentas, tarjetas, transferencias, deudas, presupuestos, metas de ahorro y vaquitas, con reportes CSV/PDF.

## Requisitos

- Python con `pip` y soporte para las versiones de `requirements.txt` (el entorno original usa Python 3.14).
- MariaDB, por ejemplo mediante MySQL en XAMPP.

## Instalación en Windows

1. Descarga el repositorio con **Code → Download ZIP** y descomprímelo, o clónalo con Git.
2. Abre una terminal dentro de la carpeta y prepara el entorno:

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\python.exe -m pip install -r requirements.txt
   ```

3. Inicia MySQL en XAMPP. En phpMyAdmin crea una base de datos vacía llamada `app_finanzas`, con cotejamiento `utf8mb4_unicode_ci`. Dentro de esa base, importa primero `Database_MariaDB_XAMPP.sql` y después `migracion_fase2.sql`.
4. La conexión local predeterminada usa `127.0.0.1:3306`, usuario `root` y contraseña vacía. Si tu instalación usa otros valores, configúralos en la misma terminal antes de arrancar:

   ```powershell
   $env:DB_HOST = "127.0.0.1"
   $env:DB_PORT = "3306"
   $env:DB_USER = "tu_usuario"
   $env:DB_PASSWORD = "tu_contrasena"
   $env:DB_NAME = "app_finanzas"
   ```

   Estos son valores de ejemplo. La aplicación lee variables de entorno; no carga archivos `.env` automáticamente.

5. Ejecuta:

   ```powershell
   .\.venv\Scripts\python.exe app.py
   ```

6. Abre <http://127.0.0.1:5000>. Puedes registrar tu propia cuenta o usar la cuenta de demostración local: `demo@app-finanzas.local`, contraseña `demo1234`.

La aplicación crea sus datos mínimos de demostración y genera una clave local `.secret_key` al iniciarse. La automatización requiere mantener Flask activo. El servidor está configurado para uso local.

## Archivos principales

- `app.py`: inicio de la aplicación y rutas principales.
- `conexion.py`: conexión y transacciones con MariaDB.
- `finanzas.py`, `gestion.py`, `avanzado.py`, `analitica.py`, `automatizacion.py`, `experiencia.py`: funciones de gestión, cálculos, reportes y formularios.
- `templates/` y `static/`: interfaz HTML, CSS y JavaScript.
- `Database_MariaDB_XAMPP.sql` y `migracion_fase2.sql`: esquema y ampliaciones de la base de datos.
- `ROADMAP.md` y `FASE*_ESTADO.md`: estado del proyecto e historial de verificaciones locales.

## Contenido compartido

Este repositorio contiene el código y los esquemas SQL. Las claves locales, entornos virtuales, logs, respaldos con datos y materiales externos de referencia se excluyen de la publicación. Las evidencias de pruebas mencionadas en los documentos de estado permanecen en el equipo original.
