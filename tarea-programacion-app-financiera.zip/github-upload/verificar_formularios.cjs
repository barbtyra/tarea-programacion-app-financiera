// Prueba del JavaScript real en DOM, sin navegador ni datos personales.
// jsdom se instala únicamente en %TEMP%/balance-fase2-dom-tests.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {JSDOM}=require(path.join(os.tmpdir(),'balance-fase2-dom-tests/node_modules/jsdom'));
const code=fs.readFileSync(path.join(__dirname,'static/js/app.js'),'utf8');
const fixture=name=>fs.readFileSync(path.join(__dirname,'backups',name),'utf8');
const normal=fixture('fase2_formulario_prueba.html');

function dom(html,storage={},completed=null){
  const result=new JSDOM(html,{url:'http://127.0.0.1:5001/gastos',runScripts:'outside-only',pretendToBeVisual:true});
  const w=result.window;
  w.matchMedia=()=>({matches:false,addEventListener(){},removeEventListener(){}});
  for(const[k,v]of Object.entries(storage))w.sessionStorage.setItem(k,v);
  if(completed)w.document.querySelector('#completed-operation').textContent=JSON.stringify(completed);
  for(const script of w.document.querySelectorAll('script:not([src])'))if(script.type!=='application/json')w.eval(script.textContent);
  const dialog=w.document.querySelector('dialog');
  dialog.showModal=()=>{dialog.open=true;};dialog.close=()=>{dialog.open=false;};
  w.eval(code);
  return w;
}
const postForm=w=>w.document.querySelector('form[method="post"]');
const storage=w=>Object.fromEntries(Object.keys(w.sessionStorage).map(k=>[k,w.sessionStorage.getItem(k)]));
const input=(w,element,value)=>{element.value=value;element.dispatchEvent(new w.Event('input',{bubbles:true}));};

let w=dom(fixture('fase2_formulario_error_prueba.html'));
let form=postForm(w);
assert.equal(form.elements.amount.value,'125.50');
assert.equal(form.elements.description.value,'Compra que debe conservarse');
assert.equal(form.querySelectorAll('[name="payment_method"]').length,2);
assert.deepEqual([...form.querySelectorAll('[name="payment_amount"]')].map(e=>e.value),['100','20']);
console.log('OK: Recuperación del formulario completo después de una validación fallida, incluidos medios repetidos');
w.close();

w=dom(normal);form=postForm(w);
const password=w.document.createElement('input');password.type='password';password.name='password';form.append(password);
const revision=w.document.createElement('input');revision.type='hidden';revision.name='revision';revision.value='2';form.append(revision);
input(w,form.elements.amount,'52.37');input(w,form.elements.description,'Borrador seguro');input(w,password,'NoDebeGuardarse');
let saved=storage(w);let record=JSON.parse(Object.values(saved)[0]);
assert.equal(record.values.amount[0],'52.37');assert(!('password'in record.values));assert(!('revision'in record.values));
const requestId=form.elements._request_id.value;
let submit=new w.SubmitEvent('submit',{bubbles:true,cancelable:true,submitter:form.querySelector('button[type="submit"]')});
form.dispatchEvent(submit);
assert(!submit.defaultPrevented);assert.equal(form.dataset.busy,'true');
assert(form.querySelector('button[type="submit"]').disabled);
let duplicate=new w.SubmitEvent('submit',{bubbles:true,cancelable:true});form.dispatchEvent(duplicate);assert(duplicate.defaultPrevented);
saved=storage(w);w.close();
w=dom(normal,saved);form=postForm(w);
assert.equal(form.elements.amount.value,'52.37');assert.equal(form.elements.description.value,'Borrador seguro');assert.equal(form.elements._request_id.value,requestId);
console.log('OK: Borrador tras interrupción, clave de reintento conservada, contraseña excluida y doble envío bloqueado');
w.close();
w=dom(normal,saved,requestId);assert.equal(Object.keys(w.sessionStorage).length,0);assert.equal(postForm(w).elements.amount.value,'');w.close();
console.log('OK: Borrador eliminado únicamente cuando el servidor confirma que la operación fue guardada');

const expired=Object.fromEntries(Object.entries(saved).map(([k,v])=>[k,JSON.stringify({...JSON.parse(v),time:Date.now()-13*3600*1000})]));
w=dom(normal,expired);assert.equal(postForm(w).elements.amount.value,'');w.close();
console.log('OK: No se restauran borradores vencidos');

w=dom(fixture('fase2_detalle_prueba.html'));
let draftForm=[...w.document.forms].find(f=>new URL(f.action).pathname.endsWith('/anular'));
input(w,draftForm.elements.reason,'Un motivo que debe conservarse');
const orderedStorage=storage(w);w.close();
const reordered=fixture('fase2_detalle_prueba.html').replace('<div id="mensajes"','<form method="post" action="/otra-operacion"><input name="otro"></form><div id="mensajes"');
w=dom(reordered,orderedStorage);
draftForm=[...w.document.forms].find(f=>new URL(f.action).pathname.endsWith('/anular'));
assert.equal(draftForm.elements.reason.value,'Un motivo que debe conservarse');w.close();
console.log('OK: Borrador ligado a la operación aunque cambie el orden de los formularios de la página');

w=dom(fixture('fase2_detalle_prueba.html'));
form=[...w.document.forms].find(f=>new URL(f.action).pathname.endsWith('/anular'));
assert(form);input(w,form.elements.reason,'Prueba de confirmación');
const button=form.querySelector('button');let submitted=0;
form.requestSubmit=submitter=>{const event=new w.SubmitEvent('submit',{bubbles:true,cancelable:true,submitter});form.dispatchEvent(event);if(!event.defaultPrevented)submitted++;};
let confirmation=new w.SubmitEvent('submit',{bubbles:true,cancelable:true,submitter:button});form.dispatchEvent(confirmation);
assert(confirmation.defaultPrevented);assert(w.document.querySelector('dialog').open);assert.equal(submitted,0);
w.document.querySelector('#confirm-cancel').click();assert(!w.document.querySelector('dialog').open);assert.equal(submitted,0);
confirmation=new w.SubmitEvent('submit',{bubbles:true,cancelable:true,submitter:button});form.dispatchEvent(confirmation);
w.document.querySelector('#confirm-accept').click();assert.equal(submitted,1);assert.equal(form.dataset.busy,'true');
console.log('OK: Cancelar la confirmación no envía; aceptar envía una sola anulación');
w.close();
console.log('RESULTADO: 6 grupos de comportamiento de formularios correctos. No incluye evaluación visual.');
