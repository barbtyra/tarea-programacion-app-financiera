-- Ampliaciones aditivas. Ejecutar después de respaldar app_finanzas.
ALTER TABLE financial_transactions ADD COLUMN IF NOT EXISTS voided_at DATETIME NULL;
ALTER TABLE financial_transactions ADD COLUMN IF NOT EXISTS void_reason VARCHAR(255) NULL;
ALTER TABLE financial_transactions ADD COLUMN IF NOT EXISTS revision INT NOT NULL DEFAULT 1;
ALTER TABLE debts ADD COLUMN IF NOT EXISTS disbursement_transaction_id CHAR(36) NULL;
ALTER TABLE debt_payments ADD COLUMN IF NOT EXISTS principal_amount DECIMAL(18,2) NULL;
ALTER TABLE debt_payments ADD COLUMN IF NOT EXISTS interest_amount DECIMAL(18,2) NOT NULL DEFAULT 0;
ALTER TABLE debt_payments ADD COLUMN IF NOT EXISTS payment_order BIGINT UNSIGNED NOT NULL AUTO_INCREMENT UNIQUE;
ALTER TABLE recurring_rules ADD COLUMN IF NOT EXISTS anchor_day SMALLINT NULL;
ALTER TABLE recurring_rules ADD COLUMN IF NOT EXISTS anchor_month SMALLINT NULL;
CREATE TABLE IF NOT EXISTS user_preferences (
 user_id CHAR(36) PRIMARY KEY, theme ENUM('light','dark','system') NOT NULL DEFAULT 'light',
 hide_balances BOOLEAN NOT NULL DEFAULT FALSE, monthly_income DECIMAL(18,2) NULL,
 FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS category_budgets (
 id CHAR(36) PRIMARY KEY, user_id CHAR(36) NOT NULL, category_id CHAR(36) NOT NULL,
 month DATE NOT NULL, amount DECIMAL(18,2) NOT NULL, is_active BOOLEAN NOT NULL DEFAULT TRUE,
 UNIQUE KEY budget_month(user_id,category_id,month),
 FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(category_id) REFERENCES categories(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE category_budgets ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT TRUE;
CREATE TABLE IF NOT EXISTS operation_receipts (
 user_scope VARCHAR(64) NOT NULL, request_id CHAR(36) NOT NULL, fingerprint CHAR(64) NOT NULL,
 redirect_to VARCHAR(255) NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(user_scope,request_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS transaction_audit (
 id CHAR(36) PRIMARY KEY, transaction_id CHAR(36) NOT NULL, user_id CHAR(36) NOT NULL,
 action VARCHAR(30) NOT NULL, snapshot LONGTEXT NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 reversal_transaction_id CHAR(36) NULL,
 FOREIGN KEY(transaction_id) REFERENCES financial_transactions(id), FOREIGN KEY(user_id) REFERENCES users(id),
 FOREIGN KEY(reversal_transaction_id) REFERENCES financial_transactions(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS card_payment_allocations (
 payment_transaction_id CHAR(36) NOT NULL, cycle_id CHAR(36) NOT NULL, amount DECIMAL(18,2) NOT NULL,
 PRIMARY KEY(payment_transaction_id,cycle_id),
 FOREIGN KEY(payment_transaction_id) REFERENCES credit_card_payments(transaction_id),
 FOREIGN KEY(cycle_id) REFERENCES credit_card_cycles(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS automation_events (
 user_id CHAR(36) NOT NULL, kind VARCHAR(30) NOT NULL, reference_id CHAR(36) NOT NULL,
 period DATE NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(user_id,kind,reference_id,period), FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS group_invitations (
 id CHAR(36) PRIMARY KEY, group_id CHAR(36) NOT NULL, invited_email VARCHAR(254) NOT NULL,
 status ENUM('PENDING','ACCEPTED','DECLINED') NOT NULL DEFAULT 'PENDING',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY group_email(group_id,invited_email), FOREIGN KEY(group_id) REFERENCES `groups`(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS pool_expense_shares (
 pool_expense_id CHAR(36) NOT NULL, user_id CHAR(36) NOT NULL, amount DECIMAL(18,2) NOT NULL,
 PRIMARY KEY(pool_expense_id,user_id), FOREIGN KEY(pool_expense_id) REFERENCES pool_expenses(id),
 FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
