from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from uuid import uuid4
import os
import secrets
from pathlib import Path

from flask import Flask, flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from conexion import obtener_conexion
from finanzas import dinero, cuenta_propia, crear_cargo, asiento, transaccion

app = Flask(__name__)
secret_file = Path(__file__).with_name('.secret_key')
if not secret_file.exists():
    secret_file.write_text(secrets.token_hex(32), encoding='ascii')
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or secret_file.read_text(encoding='ascii').strip()
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax', MAX_CONTENT_LENGTH=1024 * 1024)

USUARIO_DEMO = "00000000-0000-0000-0000-000000000001"
MONEDA = "PYG"


def uid():
    return str(uuid4())


def cerrar(conexion, cursor):
    if cursor:
        cursor.close()
    if conexion:
        conexion.close()


def usuario_actual():
    return session.get("user_id", USUARIO_DEMO)


def asegurar_cuenta_efectivo(user_id):
    """Prepara la moneda y una cuenta de efectivo para cada usuario registrado."""
    conexion = cursor = None
    try:
        conexion = obtener_conexion(); cursor = conexion.cursor()
        cursor.execute("SELECT code FROM currencies WHERE code = 'PYG'")
        if not cursor.fetchone():
            cursor.execute("INSERT INTO currencies (code,name,symbol,decimal_places) VALUES ('PYG','Guaraní paraguayo','₲',0)")
        cursor.execute("SELECT id FROM accounts WHERE user_id=%s AND type='CASH' AND status='ACTIVE' LIMIT 1", (user_id,))
        if not cursor.fetchone():
            cursor.execute("INSERT INTO accounts (id,user_id,currency_code,name,type,status,opened_at,created_at) VALUES (%s,%s,'PYG','Efectivo','CASH','ACTIVE',%s,%s)", (uid(),user_id,date.today(),datetime.now()))
        conexion.commit()
    except Exception:
        if conexion: conexion.rollback()
        raise
    finally:
        cerrar(conexion,cursor)


def preparar_credenciales():
    """Migración mínima necesaria: el esquema original no incluye contraseñas."""
    conexion = cursor = None
    try:
        conexion = obtener_conexion(); cursor = conexion.cursor()
        cursor.execute("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='password_hash'")
        if cursor.fetchone()[0] == 0:
            cursor.execute("ALTER TABLE users ADD COLUMN password_hash VARCHAR(255) NULL")
        cursor.execute("UPDATE users SET password_hash=%s WHERE email=%s AND (password_hash IS NULL OR password_hash='')", (generate_password_hash("demo1234"), "demo@app-finanzas.local"))
        conexion.commit()
    except Exception:
        if conexion: conexion.rollback()
        raise
    finally:
        cerrar(conexion,cursor)


@app.before_request
def exigir_sesion():
    if request.endpoint in {"login", "registro", "static"} or request.endpoint is None:
        return None
    if "user_id" not in session:
        return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        conexion = cursor = None
        try:
            conexion = obtener_conexion(); cursor = conexion.cursor(dictionary=True)
            password = request.form.get("password", "")
            cursor.execute("SELECT id,full_name,password_hash FROM users WHERE email=%s", (email,))
            user = cursor.fetchone()
            if not user or not user["password_hash"] or not check_password_hash(user["password_hash"], password):
                flash("Correo o contraseña incorrectos.", "error")
            else:
                session["user_id"] = user["id"]; session["user_name"] = user["full_name"]
                asegurar_cuenta_efectivo(user["id"])
                return redirect(url_for("inicio"))
        finally:
            cerrar(conexion,cursor)
    return render_template("login.html")


@app.route("/registro", methods=["GET", "POST"])
def registro():
    if request.method == "POST":
        nombre = request.form.get("full_name", "").strip(); email = request.form.get("email", "").strip().lower(); password = request.form.get("password", ""); confirmacion = request.form.get("password_confirmation", "")
        if not nombre or len(nombre)>150 or len(email)>254 or "@" not in email or not 6<=len(password)<=128:
            flash("Ingrese nombre, correo y una contraseña de al menos 6 caracteres.", "error")
        elif password != confirmacion:
            flash("Las contraseñas no coinciden.", "error")
        else:
            conexion = cursor = None
            try:
                conexion=obtener_conexion(); cursor=conexion.cursor(); user_id=uid()
                cursor.execute("INSERT INTO users (id,full_name,email,created_at,password_hash) VALUES (%s,%s,%s,%s,%s)",(user_id,nombre,email,datetime.now(),generate_password_hash(password)))
                cursor.execute("INSERT INTO accounts (id,user_id,currency_code,name,type,status,opened_at,created_at) VALUES (%s,%s,'PYG','Efectivo','CASH','ACTIVE',%s,%s)", (uid(),user_id,date.today(),datetime.now()))
                conexion.commit()
                session["user_id"]=user_id; session["user_name"]=nombre
                return redirect(url_for("inicio"))
            except Exception:
                if conexion: conexion.rollback()
                flash("Ese correo ya está registrado.", "error")
            finally:
                cerrar(conexion,cursor)
    return render_template("registro.html")


@app.route("/salir")
def salir():
    session.clear()
    return redirect(url_for("login"))


def monto_valido(valor):
    return dinero(valor)


def fecha_valida(valor):
    try:
        return datetime.strptime(valor, "%Y-%m-%d")
    except (TypeError, ValueError):
        raise ValueError("La fecha no es válida.")


def preparar_datos():
    """Crea únicamente los datos mínimos requeridos por las claves foráneas."""
    preparar_credenciales()
    conexion = cursor = None
    try:
        conexion = obtener_conexion()
        cursor = conexion.cursor()
        cursor.execute("SELECT id FROM users WHERE id = %s", (USUARIO_DEMO,))
        if not cursor.fetchone():
            cursor.execute(
                "INSERT INTO users (id, full_name, email, created_at, password_hash) VALUES (%s, %s, %s, %s, %s)",
                (USUARIO_DEMO, "Usuario demo", "demo@app-finanzas.local", datetime.now(), generate_password_hash("demo1234")),
            )
        cursor.execute("SELECT code FROM currencies WHERE code = %s", (MONEDA,))
        if not cursor.fetchone():
            cursor.execute(
                "INSERT INTO currencies (code, name, symbol, decimal_places) VALUES (%s, %s, %s, %s)",
                (MONEDA, "Guaraní paraguayo", "₲", 0),
            )
        cursor.execute("SELECT COUNT(*) FROM categories")
        if cursor.fetchone()[0] == 0:
            categorias = [
                (uid(), None, "INCOME", "Salario"),
                (uid(), None, "INCOME", "Otros ingresos"),
                (uid(), None, "EXPENSE", "Alimentación"),
                (uid(), None, "EXPENSE", "Transporte"),
                (uid(), None, "EXPENSE", "Servicios"),
                (uid(), None, "EXPENSE", "Otros gastos"),
            ]
            cursor.executemany(
                "INSERT INTO categories (id, user_id, kind, name) VALUES (%s, %s, %s, %s)",
                categorias,
            )
        # Una cuenta de efectivo permite registrar gastos aunque su saldo quede negativo.
        cursor.execute(
            "SELECT id FROM accounts WHERE user_id = %s AND type = 'CASH' AND status = 'ACTIVE' LIMIT 1",
            (USUARIO_DEMO,),
        )
        if not cursor.fetchone():
            cursor.execute(
                "INSERT INTO accounts (id, user_id, currency_code, name, type, status, opened_at, created_at) "
                "VALUES (%s, %s, %s, %s, 'CASH', 'ACTIVE', %s, %s)",
                (uid(), USUARIO_DEMO, MONEDA, "Efectivo", date.today(), datetime.now()),
            )
        conexion.commit()
    except Exception:
        if conexion:
            conexion.rollback()
        raise
    finally:
        cerrar(conexion, cursor)


def obtener_cuentas():
    conexion = cursor = None
    try:
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        cursor.execute(
            "SELECT a.id, a.name, a.type, a.currency_code, COALESCE(SUM(ae.amount), 0) AS balance, "
            "COALESCE((SELECT SUM(gr.amount_delta) FROM saving_goals sg JOIN goal_reservations gr ON gr.saving_goal_id=sg.id WHERE sg.account_id=a.id AND sg.is_active=TRUE),0) AS reserved "
            "FROM accounts a LEFT JOIN account_entries ae ON ae.account_id = a.id "
            "WHERE a.user_id = %s AND a.status = 'ACTIVE' "
            "GROUP BY a.id, a.name, a.type, a.currency_code ORDER BY a.name",
            (usuario_actual(),),
        )
        return cursor.fetchall()
    finally:
        cerrar(conexion, cursor)


def obtener_categorias(tipo):
    conexion = cursor = None
    try:
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        cursor.execute(
            "SELECT id, name FROM categories WHERE kind = %s AND is_active = TRUE "
            "AND (user_id IS NULL OR user_id = %s) ORDER BY name",
            (tipo, usuario_actual()),
        )
        return cursor.fetchall()
    finally:
        cerrar(conexion, cursor)


def obtener_medios_pago():
    """Cuentas y tarjetas disponibles para un gasto dividido."""
    conexion = cursor = None
    try:
        conexion = obtener_conexion(); cursor = conexion.cursor(dictionary=True)
        cursor.execute("SELECT dc.id, dc.brand, dc.last_four, a.name AS account_name, a.id AS account_id FROM debit_cards dc JOIN accounts a ON a.id=dc.account_id WHERE a.user_id=%s AND dc.status='ACTIVE'", (usuario_actual(),))
        debitos = cursor.fetchall()
        cursor.execute("SELECT id,name,brand,last_four,annual_interest_rate FROM credit_cards WHERE user_id=%s AND status='ACTIVE'", (usuario_actual(),))
        return debitos, cursor.fetchall()
    finally:
        cerrar(conexion, cursor)


@app.template_filter("pesos")
def pesos(valor):
    amount = Decimal(valor or 0)
    formatted = format(amount, ',.2f' if amount % 1 else ',.0f').replace(',', '_').replace('.', ',').replace('_', '.')
    return f'₲ {formatted}'


@app.route("/")
def inicio():
    from analitica import panel
    return render_template('inicio.html', **panel(usuario_actual()))


@app.route("/cuentas", methods=["GET", "POST"])
def cuentas():
    if request.method == "POST":
        nombre = request.form.get("name", "").strip()
        institucion = request.form.get("institution", "").strip()
        tipo = request.form.get("type", "")
        if not nombre or len(nombre)>100 or len(institucion)>150 or tipo not in {"CASH", "SAVINGS", "CHECKING", "DIGITAL", "OTHER"}:
            flash("Complete un nombre y tipo de cuenta válidos.", "error")
        else:
            conexion = cursor = None
            try:
                conexion = obtener_conexion()
                cursor = conexion.cursor()
                institution_id = None
                if institucion:
                    cursor.execute("SELECT id FROM institutions WHERE name=%s", (institucion,))
                    encontrada = cursor.fetchone()
                    institution_id = encontrada[0] if encontrada else uid()
                    if not encontrada:
                        cursor.execute("INSERT INTO institutions (id,name) VALUES (%s,%s)", (institution_id, institucion))
                account_id = uid()
                cursor.execute(
                    "INSERT INTO accounts (id, user_id, institution_id, currency_code, name, type, status, opened_at, created_at) "
                    "VALUES (%s, %s, %s, %s, %s, %s, 'ACTIVE', %s, %s)",
                    (account_id, usuario_actual(), institution_id, MONEDA, nombre, tipo, date.today(), datetime.now()),
                )
                initial = dinero(request.form.get('initial_balance') or '0', positivo=False)
                if initial:
                    tx = transaccion(cursor, usuario_actual(), 'INITIAL_BALANCE', date.today(), 'Saldo inicial · '+nombre)
                    asiento(cursor, tx, account_id, initial)
                conexion.commit()
                flash("Cuenta creada correctamente.", "ok")
                return redirect(url_for("cuentas"))
            except Exception:
                if conexion:
                    conexion.rollback()
                flash("No fue posible crear la cuenta.", "error")
            finally:
                cerrar(conexion, cursor)
    from analitica import datos
    return render_template("cuentas.html", cuentas=obtener_cuentas(), archivadas=datos("SELECT * FROM accounts WHERE user_id=%s AND status='ARCHIVED' ORDER BY name",(usuario_actual(),)))


def registrar_movimiento(tipo):
    cuentas = obtener_cuentas()
    categorias = obtener_categorias(tipo)
    debitos, creditos = obtener_medios_pago() if tipo == "EXPENSE" else ([], [])
    if request.method == "POST":
        conexion = cursor = None
        try:
            categoria_id = request.form.get("category_id", "")
            monto = monto_valido(request.form.get("amount", ""))
            ocurrido = fecha_valida(request.form.get("occurred_at"))
            if ocurrido.date() > date.today():
                raise ValueError('Los movimientos reales no pueden tener una fecha futura. Utilice Facturas para planificar gastos.')
            descripcion = request.form.get("description", "").strip() or None
            if categoria_id not in {categoria["id"] for categoria in categorias}:
                raise ValueError("Seleccione una categoría válida.")
            cuenta_id = request.form.get("account_id", "")
            if tipo == "INCOME" and cuenta_id not in {cuenta["id"] for cuenta in cuentas}:
                raise ValueError("Seleccione una cuenta válida.")
            transaccion_id = uid()
            conexion = obtener_conexion()
            cursor = conexion.cursor()
            cursor.execute(
                "INSERT INTO financial_transactions (id, user_id, currency_code, type, occurred_at, description, created_at) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s)",
                (transaccion_id, usuario_actual(), MONEDA, tipo, ocurrido, descripcion, datetime.now()),
            )
            if tipo == "INCOME":
                cuenta_propia(cursor, cuenta_id, usuario_actual())
                cursor.execute(
                    "INSERT INTO incomes (transaction_id, category_id, amount, is_projectable) VALUES (%s, %s, %s, TRUE)",
                    (transaccion_id, categoria_id, monto),
                )
                asiento = monto
            else:
                cursor.execute("INSERT INTO expenses (transaction_id, category_id, merchant, total_amount) VALUES (%s, %s, %s, %s)", (transaccion_id, categoria_id, (descripcion or "")[:150] or None, monto))
                filas = []
                medios = request.form.getlist("payment_method")
                valores = request.form.getlist("payment_amount")
                if len(medios) != len(valores) or len(medios)>20:
                    raise ValueError('Revise los medios de pago y sus montos.')
                for medio, valor in zip(medios, valores):
                    if medio or valor:
                        if not medio or not valor: raise ValueError("Cada medio de pago debe tener monto.")
                        filas.append((medio, monto_valido(valor)))
                if not filas:
                    if cuenta_id not in {cuenta["id"] for cuenta in cuentas}: raise ValueError("Seleccione una cuenta o medio de pago.")
                    filas = [(f"ACCOUNT:{cuenta_id}", monto)]
                if sum(x[1] for x in filas) != monto: raise ValueError("La suma de los medios debe coincidir con el gasto.")
                debit_map = {x["id"]: x for x in debitos}; credit_map = {x["id"]: x for x in creditos}; credit_ids = set(credit_map); account_ids = {x["id"] for x in cuentas}
                for medio, importe in filas:
                    clase, medio_id = medio.split(":", 1)
                    payment_id = uid()
                    if clase == "ACCOUNT" and medio_id in account_ids:
                        cuenta_propia(cursor, medio_id, usuario_actual(), importe)
                        cursor.execute("INSERT INTO expense_payments (id,expense_transaction_id,account_id,amount) VALUES (%s,%s,%s,%s)", (payment_id,transaccion_id,medio_id,importe))
                        cursor.execute("INSERT INTO account_entries (id,transaction_id,account_id,amount,created_at) VALUES (%s,%s,%s,%s,%s)", (uid(),transaccion_id,medio_id,-importe,datetime.now()))
                    elif clase == "DEBIT" and medio_id in debit_map:
                        cuenta_propia(cursor, debit_map[medio_id]['account_id'], usuario_actual(), importe)
                        cursor.execute('SELECT expires_on FROM debit_cards WHERE id=%s', (medio_id,))
                        expires = cursor.fetchone()[0]
                        if expires and expires < ocurrido.date():
                            raise ValueError('La tarjeta de débito está vencida.')
                        cursor.execute("INSERT INTO expense_payments (id,expense_transaction_id,debit_card_id,amount) VALUES (%s,%s,%s,%s)", (payment_id,transaccion_id,medio_id,importe))
                        cursor.execute("INSERT INTO account_entries (id,transaction_id,account_id,amount,created_at) VALUES (%s,%s,%s,%s,%s)", (uid(),transaccion_id,debit_map[medio_id]["account_id"],-importe,datetime.now()))
                    elif clase == "CREDIT" and medio_id in credit_ids:
                        cursor.execute("INSERT INTO expense_payments (id,expense_transaction_id,credit_card_id,amount) VALUES (%s,%s,%s,%s)", (payment_id,transaccion_id,medio_id,importe))
                        crear_cargo(cursor, usuario_actual(), medio_id, importe, ocurrido.date(), expense_payment=payment_id,
                                    count=request.form.get('installment_count', '1'), sin_interes=request.form.get('interest_free') == '1')
                    else: raise ValueError("Medio de pago inválido.")
            if tipo == "INCOME":
                cursor.execute("INSERT INTO account_entries (id, transaction_id, account_id, amount, created_at) VALUES (%s, %s, %s, %s, %s)", (uid(), transaccion_id, cuenta_id, monto, datetime.now()))
            conexion.commit()
            flash("Ingreso registrado correctamente." if tipo == "INCOME" else "Gasto registrado correctamente.", "ok")
            return redirect(url_for("inicio"))
        except ValueError as error:
            if conexion: conexion.rollback()
            flash(str(error), "error")
        except Exception:
            if conexion:
                conexion.rollback()
            flash("No fue posible registrar el movimiento.", "error")
        finally:
            cerrar(conexion, cursor)
    titulo = "Registrar ingreso" if tipo == "INCOME" else "Registrar gasto"
    return render_template("movimiento.html", titulo=titulo, tipo=tipo, cuentas=cuentas, categorias=categorias, debitos=debitos, creditos=creditos, hoy=date.today().isoformat())


@app.route("/ingresos", methods=["GET", "POST"])
def ingresos():
    return registrar_movimiento("INCOME")


@app.route("/gastos", methods=["GET", "POST"])
def gastos():
    return registrar_movimiento("EXPENSE")


@app.route("/transferencias", methods=["GET", "POST"])
def transferencias():
    cuentas = obtener_cuentas()
    if request.method == "POST":
        conexion = cursor = None
        try:
            origen = request.form.get("source_account_id", "")
            destino = request.form.get("destination_account_id", "")
            monto = monto_valido(request.form.get("amount", ""))
            ocurrido = fecha_valida(request.form.get("occurred_at"))
            descripcion = request.form.get("description", "").strip() or "Transferencia entre cuentas"
            ids = {cuenta["id"] for cuenta in cuentas}
            if origen not in ids or destino not in ids or origen == destino:
                raise ValueError("Seleccione dos cuentas distintas y válidas.")
            transaccion_id = uid()
            conexion = obtener_conexion()
            cursor = conexion.cursor()
            if ocurrido.date() > date.today(): raise ValueError('La fecha no puede ser futura.')
            cuenta_propia(cursor, origen, usuario_actual(), monto)
            cuenta_propia(cursor, destino, usuario_actual())
            cursor.execute(
                "INSERT INTO financial_transactions (id, user_id, currency_code, type, occurred_at, description, created_at) "
                "VALUES (%s, %s, %s, 'TRANSFER', %s, %s, %s)",
                (transaccion_id, usuario_actual(), MONEDA, ocurrido, descripcion, datetime.now()),
            )
            cursor.execute(
                "INSERT INTO transfers (transaction_id, source_account_id, destination_account_id, amount) VALUES (%s, %s, %s, %s)",
                (transaccion_id, origen, destino, monto),
            )
            for cuenta_id, importe in ((origen, -monto), (destino, monto)):
                cursor.execute(
                    "INSERT INTO account_entries (id, transaction_id, account_id, amount, created_at) VALUES (%s, %s, %s, %s, %s)",
                    (uid(), transaccion_id, cuenta_id, importe, datetime.now()),
                )
            conexion.commit()
            flash("Transferencia registrada correctamente.", "ok")
            return redirect(url_for("inicio"))
        except ValueError as error:
            if conexion: conexion.rollback()
            flash(str(error), "error")
        except Exception:
            if conexion:
                conexion.rollback()
            flash("No fue posible registrar la transferencia.", "error")
        finally:
            cerrar(conexion, cursor)
    return render_template("transferencias.html", cuentas=cuentas, hoy=date.today().isoformat())


@app.route("/historial")
def historial():
    from analitica import movimientos, datos
    try:
        rows = movimientos(usuario_actual(), request.args)
    except ValueError as error:
        flash(str(error), 'error')
        rows = []
    total_rows=len(rows)
    try:page=max(1,int(request.args.get('page','1')))
    except ValueError:page=1
    pages=max(1,(total_rows+49)//50);page=min(page,pages)
    filters={k:v for k,v in request.args.items() if k in {'q','start','end','type','account_id','category_id','voided'}}
    return render_template('historial.html', movimientos=rows[(page-1)*50:page*50], total_rows=total_rows,page=page,pages=pages,history_filters=filters,
                           previous_url=url_for('historial',**filters,page=page-1),next_url=url_for('historial',**filters,page=page+1),cuentas=obtener_cuentas(),
                           categorias=datos('SELECT id,name FROM categories WHERE user_id IS NULL OR user_id=%s ORDER BY name', (usuario_actual(),)))


from avanzado import avanzado
app.register_blueprint(avanzado)
from gestion import gestion
app.register_blueprint(gestion)
from experiencia import instalar_experiencia
instalar_experiencia(app)
from analitica import TIPOS
app.jinja_env.globals['tipos_movimiento'] = TIPOS

preparar_datos()
from migrar_datos_fase2 import migrar_planes_legacy
resultado_migracion = migrar_planes_legacy()
if resultado_migracion['revision_manual']:
    app.logger.warning('Planes antiguos requieren revisión sin alterar pagos/cierres: %s', resultado_migracion['revision_manual'])

if __name__ == "__main__":
    from automatizacion import iniciar_automatizacion
    iniciar_automatizacion()
    app.run(host="127.0.0.1", port=5000, debug=False)
