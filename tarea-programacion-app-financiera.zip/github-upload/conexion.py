import os

import mysql.connector


class ConexionTransaccional:
    """Guarda la clave de una operación en el mismo COMMIT que sus datos."""
    def __init__(self, conexion):
        self._conexion = conexion

    def __getattr__(self, name):
        return getattr(self._conexion, name)

    def commit(self):
        from flask import g, has_request_context
        registrar = (has_request_context() and getattr(g, 'track_operation', False)
                     and getattr(g, 'operation_id', None) and not getattr(g, 'receipt_saved', False))
        if registrar:
            cursor = self._conexion.cursor()
            try:
                cursor.execute('INSERT INTO operation_receipts (user_scope,request_id,fingerprint) VALUES (%s,%s,%s)',
                               (g.operation_scope, g.operation_id, g.operation_fingerprint))
            finally:
                cursor.close()
        self._conexion.commit()
        if registrar:
            g.receipt_saved = True


def obtener_conexion():
    """Abre una conexión a la base creada en MariaDB/XAMPP."""
    return ConexionTransaccional(mysql.connector.connect(
        host=os.environ.get("DB_HOST", "127.0.0.1"),
        port=int(os.environ.get("DB_PORT", "3306")),
        user=os.environ.get("DB_USER", "root"),
        password=os.environ.get("DB_PASSWORD", ""),
        database=os.environ.get("DB_NAME", "app_finanzas"),
        charset="utf8mb4",
        connection_timeout=5,
    ))
