"""Módulos funcionales avanzados de la demo financiera."""
from calendar import monthrange
from datetime import date, datetime, timedelta
from decimal import Decimal
from uuid import uuid4

from flask import Blueprint, flash, redirect, render_template, request, session, url_for, g

from conexion import obtener_conexion
from finanzas import (dinero, tasa, fecha, texto, consultar, ciclo, saldo_credito, estado_ciclos,
                      pagar_credito, estado_deuda, pagar_deuda as pagar_deuda_contable,
                      reintegrar, cuenta_propia, transaccion, asiento)

USUARIO_DEMO = "00000000-0000-0000-0000-000000000001"
MONEDA = "PYG"


def usuario_actual():
    return session.get("user_id", USUARIO_DEMO)


def uid(): return str(uuid4())


def cerrar(conexion, cursor):
    if cursor: cursor.close()
    if conexion: conexion.close()


def monto_valido(valor):
    return dinero(valor)


def fecha_valida(valor):
    try: return datetime.strptime(valor, "%Y-%m-%d")
    except Exception: raise ValueError("La fecha no es válida.")


def obtener_cuentas():
    return datos("SELECT a.id,a.name,a.type,a.currency_code,COALESCE(SUM(ae.amount),0) balance,COALESCE((SELECT SUM(gr.amount_delta) FROM saving_goals sg JOIN goal_reservations gr ON gr.saving_goal_id=sg.id WHERE sg.account_id=a.id AND sg.is_active=TRUE),0) reserved FROM accounts a LEFT JOIN account_entries ae ON ae.account_id=a.id WHERE a.user_id=%s AND a.status='ACTIVE' GROUP BY a.id,a.name,a.type,a.currency_code ORDER BY a.name",(usuario_actual(),))


def obtener_categorias(tipo):
    return datos("SELECT id,name FROM categories WHERE kind=%s AND is_active=TRUE AND (user_id IS NULL OR user_id=%s) ORDER BY name",(tipo,usuario_actual()))

avanzado = Blueprint("avanzado", __name__)


def datos(sql, params=(), uno=False):
    cn = cur = None
    try:
        cn = obtener_conexion(); cur = cn.cursor(dictionary=True); cur.execute(sql, params)
        return cur.fetchone() if uno else cur.fetchall()
    finally: cerrar(cn, cur)


def medios_pago():
    cuentas = obtener_cuentas()
    debitos = datos("SELECT dc.id, dc.brand, dc.last_four, a.name account_name, a.id account_id FROM debit_cards dc JOIN accounts a ON a.id=dc.account_id WHERE a.user_id=%s AND dc.status='ACTIVE'", (usuario_actual(),))
    creditos = datos("SELECT id, name, brand, last_four FROM credit_cards WHERE user_id=%s AND status='ACTIVE'", (usuario_actual(),))
    return cuentas, debitos, creditos


def dias_mes(anio, mes, dia): return date(anio, mes, min(dia, monthrange(anio, mes)[1]))


def ciclo_actual(cur, tarjeta_id, hoy=None):
    return ciclo(cur, tarjeta_id, hoy)['id']


def saldo_tarjeta(tarjeta_id):
    cn = obtener_conexion()
    try:
        cur = cn.cursor(dictionary=True)
        result = saldo_credito(cur, tarjeta_id)
        cur.close()
        return result
    finally:
        cn.close()


@avanzado.route("/tarjetas-debito", methods=["GET", "POST"])
def tarjetas_debito():
    cuentas = [x for x in obtener_cuentas() if x["type"] != "CASH"]
    if request.method == "POST":
        cn = cur = None
        try:
            account = request.form.get("account_id"); last = request.form.get("last_four", "").strip(); brand = request.form.get("brand", "").strip() or None
            if account not in {x["id"] for x in cuentas} or not (last.isdigit() and len(last)==4): raise ValueError("Seleccione cuenta y cuatro dígitos válidos.")
            cn=obtener_conexion(); cur=cn.cursor(); cur.execute("INSERT INTO debit_cards (id,account_id,brand,last_four,expires_on,status,created_at) VALUES (%s,%s,%s,%s,%s,%s,%s)", (uid(),account,brand,last,request.form.get("expires_on") or None,request.form.get("status","ACTIVE"),datetime.now())); cn.commit(); flash("Tarjeta de débito agregada.","ok"); return redirect(url_for("avanzado.tarjetas_debito"))
        except ValueError as e: flash(str(e),"error")
        except Exception:
            if cn: cn.rollback()
            flash("No fue posible guardar la tarjeta.","error")
        finally: cerrar(cn,cur)
    cards=datos("SELECT dc.*,a.name account_name FROM debit_cards dc JOIN accounts a ON a.id=dc.account_id WHERE a.user_id=%s ORDER BY a.name",(usuario_actual(),))
    return render_template("tarjetas_debito.html", cuentas=cuentas, cards=cards)


@avanzado.route("/tarjetas-credito", methods=["GET", "POST"])
def tarjetas_credito():
    if request.method == "POST":
        cn=cur=None
        try:
            nombre=texto(request.form.get("name"),100); last=request.form.get("last_four","").strip(); limite=monto_valido(request.form.get("credit_limit","")); cierre=int(request.form.get("closing_day",0)); vence=int(request.form.get("due_day",0))
            if not nombre or not(last.isascii() and last.isdigit() and len(last)==4) or not 1<=cierre<=31 or not 1<=vence<=31 or request.form.get("status","ACTIVE") not in {"ACTIVE","BLOCKED","EXPIRED","ARCHIVED"}: raise ValueError("Revise los datos obligatorios de la tarjeta.")
            cn=obtener_conexion();cur=cn.cursor(); inst=request.form.get("institution","").strip()
            institution_id=None
            if inst:
                cur.execute("SELECT id FROM institutions WHERE name=%s",(inst,)); found=cur.fetchone(); institution_id=found[0] if found else uid()
                if not found: cur.execute("INSERT INTO institutions (id,name) VALUES (%s,%s)",(institution_id,inst))
            cur.execute("INSERT INTO credit_cards (id,user_id,institution_id,currency_code,name,brand,last_four,credit_limit,annual_interest_rate,closing_day,due_day,status,created_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)", (uid(),usuario_actual(),institution_id,MONEDA,nombre,request.form.get("brand") or None,last,limite,tasa(request.form.get("annual_interest_rate")),cierre,vence,request.form.get("status","ACTIVE"),datetime.now()));cn.commit();flash("Tarjeta de crédito creada.","ok");return redirect(url_for("avanzado.tarjetas_credito"))
        except (ValueError,TypeError) as e: flash(str(e) or "Datos inválidos.","error")
        except Exception:
            if cn:cn.rollback()
            flash("No fue posible crear la tarjeta.","error")
        finally: cerrar(cn,cur)
    cards=datos("SELECT cc.*,i.name institution FROM credit_cards cc LEFT JOIN institutions i ON i.id=cc.institution_id WHERE cc.user_id=%s ORDER BY cc.created_at DESC",(usuario_actual(),))
    for c in cards:
        c["used"]=saldo_tarjeta(c["id"]); c["available"]=c["credit_limit"]-c["used"]
    return render_template("tarjetas_credito.html", cards=cards)


@avanzado.route("/tarjetas-credito/<card_id>/editar", methods=["POST"])
def editar_tarjeta_credito(card_id):
    cn=cur=None
    try:
        cn=obtener_conexion();cur=cn.cursor(dictionary=True)
        card=consultar(cur,'SELECT * FROM credit_cards WHERE id=%s AND user_id=%s FOR UPDATE',(card_id,usuario_actual()),True)
        if not card:raise ValueError('La tarjeta no está disponible.')
        name=texto(request.form.get('name'),100);last=request.form.get('last_four','');limit=dinero(request.form.get('credit_limit'));annual=tasa(request.form.get('annual_interest_rate'))
        closing=int(request.form.get('closing_day','0'));due=int(request.form.get('due_day','0'));status=request.form.get('status','ACTIVE')
        if len(last)!=4 or not last.isascii() or not last.isdigit() or not 1<=closing<=31 or not 1<=due<=31 or status not in {'ACTIVE','BLOCKED','EXPIRED','ARCHIVED'}:raise ValueError('Revise los dígitos, días y estado de la tarjeta.')
        balance=saldo_credito(cur,card_id)
        if limit<balance:raise ValueError('El límite no puede ser inferior al saldo utilizado.')
        if status=='ARCHIVED' and balance:raise ValueError('Deje el saldo de la tarjeta en cero antes de archivarla.')
        if closing!=card['closing_day'] or due!=card['due_day']:
            if consultar(cur,'SELECT id FROM credit_card_charges WHERE initial_cycle_id IN (SELECT id FROM credit_card_cycles WHERE credit_card_id=%s) LIMIT 1',(card_id,),True):
                raise ValueError('Con compras registradas, los días de cierre y vencimiento se conservan para no alterar ciclos existentes.')
            for cy in consultar(cur,'SELECT * FROM credit_card_cycles WHERE credit_card_id=%s',(card_id,)):
                close=date(cy['closes_on'].year,cy['closes_on'].month,min(closing,monthrange(cy['closes_on'].year,cy['closes_on'].month)[1]))
                from finanzas import sumar_meses
                start=sumar_meses(close,-1,closing)+timedelta(days=1)
                due_on=date(close.year,close.month,min(due,monthrange(close.year,close.month)[1]))
                if due_on<=close:due_on=sumar_meses(due_on,1,due)
                cur.execute('UPDATE credit_card_cycles SET starts_on=%s,closes_on=%s,due_on=%s WHERE id=%s',(start,close,due_on,cy['id']))
        cur.execute('UPDATE credit_cards SET name=%s,brand=%s,last_four=%s,credit_limit=%s,annual_interest_rate=%s,closing_day=%s,due_day=%s,status=%s WHERE id=%s',(name,(request.form.get('brand') or '')[:40] or None,last,limit,annual,closing,due,status,card_id))
        cn.commit();flash('Tarjeta actualizada.','ok')
    except (ValueError,TypeError) as e:
        if cn:cn.rollback()
        flash(str(e),'error')
    except Exception:
        if cn:cn.rollback()
        flash('No fue posible actualizar la tarjeta.','error')
    finally:cerrar(cn,cur)
    return redirect(url_for('avanzado.detalle_tarjeta',card_id=card_id))


@avanzado.route("/tarjetas-credito/<card_id>")
def detalle_tarjeta(card_id):
    card=datos("SELECT * FROM credit_cards WHERE id=%s AND user_id=%s",(card_id,usuario_actual()),True)
    if not card: return redirect(url_for("avanzado.tarjetas_credito"))
    cn=obtener_conexion();cur=cn.cursor(dictionary=True)
    try:ciclos=estado_ciclos(cur,card_id)
    finally:cerrar(cn,cur)
    plans=datos("SELECT ip.*,cc.principal_amount FROM installment_plans ip JOIN credit_card_charges cc ON cc.id=ip.credit_card_charge_id LEFT JOIN expense_payments ep ON ep.id=cc.expense_payment_id LEFT JOIN debt_payment_sources ds ON ds.id=cc.debt_payment_source_id WHERE ep.credit_card_id=%s OR ds.credit_card_id=%s",(card_id,card_id))
    for p in plans:
        p['installments']=datos('SELECT ci.*,cy.due_on FROM card_installments ci LEFT JOIN credit_card_cycles cy ON cy.id=ci.credit_card_cycle_id WHERE ci.installment_plan_id=%s ORDER BY ci.installment_number',(p['id'],))
        p["paid"]=datos("SELECT COUNT(*) n FROM card_installments WHERE installment_plan_id=%s AND status='PAID'",(p["id"],),True)["n"]; p["pending"]=sum(1 for q in p["installments"] if q["status"] in {"PENDING","BILLED"})
    return render_template("tarjeta_detalle.html",card=card,used=saldo_tarjeta(card_id),ciclos=ciclos,plans=plans,cuentas=obtener_cuentas(),today=date.today().isoformat())


@avanzado.route("/tarjetas-credito/<card_id>/pagar",methods=["POST"])
def pagar_tarjeta(card_id):
    cn=cur=None
    try:
        cn=obtener_conexion();cur=cn.cursor(dictionary=True)
        on=fecha(request.form.get('occurred_at'))
        if on>date.today(): raise ValueError('El pago no puede tener una fecha futura.')
        pagar_credito(cur,usuario_actual(),card_id,request.form.get('account_id'),dinero(request.form.get('amount')),on,request.form.get('cycle_id') or None)
        cn.commit();flash('Pago registrado y asignado a sus ciclos.','ok')
    except ValueError as e:
        if cn:cn.rollback()
        flash(str(e),'error')
    except Exception:
        if cn:cn.rollback()
        from flask import current_app
        current_app.logger.exception('Error en pago de tarjeta')
        flash('No fue posible registrar el pago. Sus datos se conservan.','error')
    finally:cerrar(cn,cur)
    return redirect(url_for('avanzado.detalle_tarjeta',card_id=card_id))


@avanzado.route("/categorias",methods=["GET","POST"])
def categorias():
    if request.method=="POST":
        cn=cur=None
        try:
            name=texto(request.form.get("name"),80); kind=request.form.get("kind")
            if not name or kind not in {"INCOME","EXPENSE"}:raise ValueError("Ingrese una categoría válida.")
            cn=obtener_conexion();cur=cn.cursor();cur.execute("INSERT INTO categories (id,user_id,kind,name,is_active) VALUES (%s,%s,%s,%s,TRUE)",(uid(),usuario_actual(),kind,name));cn.commit();flash("Categoría creada.","ok")
        except Exception:
            if cn:cn.rollback()
            flash("No fue posible crear la categoría.","error")
        finally:cerrar(cn,cur)
    cats=datos("SELECT * FROM categories WHERE user_id IS NULL OR user_id=%s ORDER BY kind,name",(usuario_actual(),));return render_template("categorias.html",categorias=cats)


@avanzado.route("/categorias/<cat_id>/desactivar",methods=["POST"])
def desactivar_categoria(cat_id):
    cn=cur=None
    try:
        cn=obtener_conexion();cur=cn.cursor();cur.execute("UPDATE categories SET is_active=FALSE WHERE id=%s AND user_id=%s",(cat_id,usuario_actual()));cn.commit();flash("Categoría desactivada.","ok")
    finally:cerrar(cn,cur)
    return redirect(url_for("avanzado.categorias"))


@avanzado.route("/metas",methods=["GET","POST"])
def metas():
    if request.method=="POST":
        cn=cur=None
        try:
            account=request.form.get("account_id");
            texto(request.form.get("name"),120)
            if account not in {x["id"] for x in obtener_cuentas()}:raise ValueError("Seleccione cuenta válida.")
            cn=obtener_conexion();cur=cn.cursor();cur.execute("INSERT INTO saving_goals (id,user_id,account_id,currency_code,name,target_amount,target_date,is_active,created_at) VALUES (%s,%s,%s,%s,%s,%s,%s,TRUE,%s)",(uid(),usuario_actual(),account,MONEDA,request.form.get("name"),monto_valido(request.form.get("target_amount")),request.form.get("target_date") or None,datetime.now()));cn.commit();flash("Meta creada.","ok")
        except Exception:
            if cn:cn.rollback()
            flash("No fue posible crear la meta.","error")
        finally:cerrar(cn,cur)
    goals=datos("SELECT sg.*,a.name account_name,COALESCE(SUM(gr.amount_delta),0) reserved FROM saving_goals sg JOIN accounts a ON a.id=sg.account_id LEFT JOIN goal_reservations gr ON gr.saving_goal_id=sg.id WHERE sg.user_id=%s GROUP BY sg.id,a.name ORDER BY sg.is_active DESC",(usuario_actual(),));return render_template("metas.html",goals=goals,cuentas=obtener_cuentas())


@avanzado.route("/metas/<goal_id>/reservar",methods=["POST"])
def reservar_meta(goal_id):
    cn=cur=None
    try:
        amount=dinero(request.form.get('amount')); action=request.form.get('action')
        if action not in {'reserve','release'}:raise ValueError('Seleccione reservar o liberar.')
        cn=obtener_conexion();cur=cn.cursor(dictionary=True)
        goal=consultar(cur,'SELECT * FROM saving_goals WHERE id=%s AND user_id=%s AND is_active=TRUE FOR UPDATE',(goal_id,usuario_actual()),True)
        if not goal:raise ValueError('La meta no está disponible.')
        account=cuenta_propia(cur,goal['account_id'],usuario_actual())
        reserved=consultar(cur,'SELECT COALESCE(SUM(amount_delta),0) n FROM goal_reservations WHERE saving_goal_id=%s',(goal_id,),True)['n']
        balance=consultar(cur,'SELECT COALESCE(SUM(amount),0) n FROM account_entries WHERE account_id=%s',(account['id'],),True)['n']
        total_reserved=consultar(cur,'SELECT COALESCE(SUM(gr.amount_delta),0) n FROM goal_reservations gr JOIN saving_goals sg ON sg.id=gr.saving_goal_id WHERE sg.account_id=%s AND sg.is_active=TRUE',(account['id'],),True)['n']
        if action=='release' and amount>reserved:raise ValueError('No puede liberar más de lo reservado en esta meta.')
        if action=='reserve' and amount>balance-total_reserved:raise ValueError('La cuenta no tiene saldo libre suficiente para esta reserva.')
        cur.execute('INSERT INTO goal_reservations (id,saving_goal_id,amount_delta,reserved_at,note) VALUES (%s,%s,%s,%s,%s)',(uid(),goal_id,-amount if action=='release' else amount,datetime.now(),(request.form.get('note') or '')[:255] or None))
        cn.commit();flash('Reserva actualizada. El saldo contable no cambia.','ok')
    except ValueError as e:
        if cn:cn.rollback()
        flash(str(e),'error')
    except Exception:
        if cn:cn.rollback()
        flash('No fue posible actualizar la reserva.','error')
    finally:cerrar(cn,cur)
    return redirect(url_for('avanzado.metas'))


def gasto_desde_cuenta(cur, categoria, cuenta, monto, descripcion, ocurrido, bill_id=None):
    """Genera gasto y asiento; se usa al pagar una factura pendiente."""
    cuenta_propia(cur,cuenta,usuario_actual(),monto)
    tx=uid(); now=datetime.now()
    cur.execute("INSERT INTO financial_transactions (id,user_id,currency_code,type,occurred_at,description,created_at) VALUES (%s,%s,%s,'EXPENSE',%s,%s,%s)",(tx,usuario_actual(),MONEDA,ocurrido,descripcion,now))
    cur.execute("INSERT INTO expenses (transaction_id,category_id,merchant,total_amount) VALUES (%s,%s,%s,%s)",(tx,categoria,(descripcion or "")[:150],monto))
    cur.execute("INSERT INTO expense_payments (id,expense_transaction_id,account_id,amount) VALUES (%s,%s,%s,%s)",(uid(),tx,cuenta,monto))
    cur.execute("INSERT INTO account_entries (id,transaction_id,account_id,amount,created_at) VALUES (%s,%s,%s,%s,%s)",(uid(),tx,cuenta,-monto,now))
    if bill_id: cur.execute("UPDATE bills SET status='PAID',paid_expense_transaction_id=%s WHERE id=%s",(tx,bill_id))
    return tx


@avanzado.route("/facturas", methods=["GET","POST"])
def facturas():
    if request.method=="POST":
        cn=cur=None
        try:
            cat=request.form.get("category_id"); cats={x["id"] for x in obtener_categorias("EXPENSE")}
            if cat not in cats: raise ValueError("Seleccione una categoría.")
            amount=monto_valido(request.form.get("expected_amount")); due=request.form.get("next_due_on"); fecha_valida(due)
            cn=obtener_conexion();cur=cn.cursor(); rule=uid(); variable=request.form.get("is_variable_amount")=="1"
            texto(request.form.get('name'),120)
            if request.form.get('frequency') not in {'WEEKLY','MONTHLY','QUARTERLY','YEARLY'}:raise ValueError('Seleccione una frecuencia válida.')
            cur.execute("INSERT INTO recurring_rules (id,user_id,category_id,currency_code,name,merchant,frequency,is_variable_amount,expected_amount,next_due_on,is_active) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,TRUE)",(rule,usuario_actual(),cat,MONEDA,request.form.get("name"),request.form.get("merchant") or None,request.form.get("frequency"),variable,amount,due))
            cur.execute("INSERT INTO bills (id,recurring_rule_id,user_id,currency_code,category_id,description,amount,due_on,status,created_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,'PENDING',%s)",(uid(),rule,usuario_actual(),MONEDA,cat,request.form.get("name"),amount,due,datetime.now()))
            cn.commit();flash("Gasto recurrente y su factura inicial creados.","ok");return redirect(url_for("avanzado.facturas"))
        except Exception:
            if cn:cn.rollback()
            flash("No fue posible crear la factura recurrente.","error")
        finally:cerrar(cn,cur)
    cn=cur=None
    try:
        tracking=getattr(g,'track_operation',False);g.track_operation=False
        cn=obtener_conexion();cur=cn.cursor();cur.execute("UPDATE bills SET status='OVERDUE' WHERE user_id=%s AND status='PENDING' AND due_on<CURDATE()",(usuario_actual(),));cn.commit()
        g.track_operation=tracking
    finally:cerrar(cn,cur)
    bills=datos("SELECT b.*,c.name category,rr.frequency,rr.is_variable_amount FROM bills b LEFT JOIN categories c ON c.id=b.category_id LEFT JOIN recurring_rules rr ON rr.id=b.recurring_rule_id WHERE b.user_id=%s ORDER BY b.status='PAID',b.due_on",(usuario_actual(),))
    for b in bills:
        if b["is_variable_amount"]:
            recent=datos("SELECT e.total_amount FROM bills old JOIN expenses e ON e.transaction_id=old.paid_expense_transaction_id JOIN financial_transactions ft ON ft.id=e.transaction_id WHERE old.recurring_rule_id=%s AND old.status='PAID' AND ft.voided_at IS NULL ORDER BY old.due_on DESC LIMIT 3",(b['recurring_rule_id'],))
            avg=sum((x['total_amount'] for x in recent),Decimal('0'))/len(recent) if recent else None
            b["estimate"]=avg or b["amount"]
    return render_template("facturas.html",rules=datos("SELECT rr.*,c.name category FROM recurring_rules rr JOIN categories c ON c.id=rr.category_id WHERE rr.user_id=%s ORDER BY rr.name",(usuario_actual(),)),bills=bills,categorias=obtener_categorias("EXPENSE"),cuentas=obtener_cuentas(),hoy=date.today().isoformat())


@avanzado.route("/facturas/<bill_id>/pagar",methods=["POST"])
def pagar_factura(bill_id):
    cn=cur=None
    try:
        cn=obtener_conexion();cur=cn.cursor(dictionary=True)
        bill=consultar(cur,"SELECT * FROM bills WHERE id=%s AND user_id=%s AND status IN ('PENDING','OVERDUE') FOR UPDATE",(bill_id,usuario_actual()),True)
        if not bill:raise ValueError('La factura ya fue pagada, cancelada o no está disponible.')
        on=fecha(request.form.get('occurred_at'))
        if on>date.today():raise ValueError('La fecha de pago no puede ser futura.')
        gasto_desde_cuenta(cur,bill['category_id'],request.form.get('account_id'),bill['amount'],bill['description'],on,bill_id)
        cn.commit();flash('Factura pagada. El gasto se registró una sola vez.','ok')
    except ValueError as e:
        if cn:cn.rollback()
        flash(str(e),'error')
    except Exception:
        if cn:cn.rollback()
        flash('No fue posible pagar la factura.','error')
    finally:cerrar(cn,cur)
    return redirect(url_for('avanzado.facturas'))


@avanzado.route("/facturas/<bill_id>/cancelar",methods=["POST"])
def cancelar_factura(bill_id):
    cn=cur=None
    try:
        cn=obtener_conexion();cur=cn.cursor();cur.execute("UPDATE bills SET status='CANCELLED' WHERE id=%s AND user_id=%s AND status IN ('PENDING','OVERDUE')",(bill_id,usuario_actual()));cn.commit();flash("Factura cancelada.","ok")
    finally:cerrar(cn,cur)
    return redirect(url_for("avanzado.facturas"))


def party_usuario(cur):
    cur.execute("SELECT id FROM parties WHERE user_id=%s LIMIT 1",(usuario_actual(),)); row=cur.fetchone()
    if row:return row[0]
    value=uid();cur.execute("INSERT INTO parties (id,user_id,external_contact_id,created_at) VALUES (%s,%s,NULL,%s)",(value,usuario_actual(),datetime.now()));return value


@avanzado.route("/deudas",methods=["GET","POST"])
def deudas():
    if request.method=='POST':
        cn=cur=None
        try:
            contact=texto(request.form.get('contact_name'),150,'El contacto'); direction=request.form.get('direction')
            if direction not in {'PAYABLE','RECEIVABLE'}:raise ValueError('Seleccione por pagar o por cobrar.')
            amount=dinero(request.form.get('original_amount')); annual=tasa(request.form.get('annual_interest_rate'))
            issued=fecha(request.form.get('issued_on') or date.today().isoformat())
            due=fecha(request.form.get('due_on')) if request.form.get('due_on') else None
            if issued>date.today() or (due and due<issued):raise ValueError('Revise las fechas de entrega y vencimiento.')
            cn=obtener_conexion();cur=cn.cursor();user_party=party_usuario(cur);contact_id=uid();contact_party=uid();debt_id=uid()
            cur.execute('INSERT INTO external_contacts (id,owner_user_id,name,phone,email,created_at) VALUES (%s,%s,%s,%s,%s,%s)',(contact_id,usuario_actual(),contact,(request.form.get('phone') or '')[:40] or None,(request.form.get('email') or '')[:254] or None,datetime.now()))
            cur.execute('INSERT INTO parties (id,external_contact_id,created_at) VALUES (%s,%s,%s)',(contact_party,contact_id,datetime.now()))
            creditor,debtor=(contact_party,user_party) if direction=='PAYABLE' else (user_party,contact_party)
            description=(request.form.get('description') or '')[:255] or None
            delivery=None
            if request.form.get('disbursement_account_id'):
                account=request.form['disbursement_account_id'];cuenta_propia(cur,account,usuario_actual(),amount if direction=='RECEIVABLE' else None)
                delivery=transaccion(cur,usuario_actual(),'DEBT_DISBURSEMENT',issued,'Entrega de préstamo · '+contact)
                asiento(cur,delivery,account,amount if direction=='PAYABLE' else -amount)
            cur.execute("INSERT INTO debts (id,created_by_user_id,creditor_party_id,debtor_party_id,currency_code,description,original_amount,annual_interest_rate,issued_on,due_on,status,disbursement_transaction_id) VALUES (%s,%s,%s,%s,'PYG',%s,%s,%s,%s,%s,'OPEN',%s)",(debt_id,usuario_actual(),creditor,debtor,description,amount,annual,issued,due,delivery))
            cn.commit();flash('Deuda registrada. Los intereses se calculan sobre el capital pendiente.','ok')
            return redirect(url_for('avanzado.deudas'))
        except ValueError as e:
            if cn:cn.rollback()
            flash(str(e),'error')
        except Exception:
            if cn:cn.rollback()
            from flask import current_app
            current_app.logger.exception('Alta de deuda')
            flash('No fue posible guardar la deuda.','error')
        finally:cerrar(cn,cur)
    debts=datos('SELECT d.id,ec.name contact FROM debts d JOIN parties p ON p.id=d.debtor_party_id JOIN parties ex ON ex.id=IF(p.user_id=%s,d.creditor_party_id,d.debtor_party_id) JOIN external_contacts ec ON ec.id=ex.external_contact_id WHERE d.created_by_user_id=%s ORDER BY d.status,d.due_on',(usuario_actual(),usuario_actual()))
    cn=obtener_conexion();cur=cn.cursor(dictionary=True)
    try:
        for d in debts:
            d.update(estado_deuda(cur,d['id'],usuario_actual()))
            d['direction']='Por pagar' if d['payable'] else 'Por cobrar'
    finally:cerrar(cn,cur)
    accounts,debits,credits=medios_pago()
    return render_template('deudas.html',debts=debts,cuentas=accounts,debitos=debits,creditos=credits,hoy=date.today().isoformat())


@avanzado.route("/deudas/<debt_id>/pagar",methods=["POST"])
def pagar_deuda(debt_id):
    cn=cur=None
    try:
        cn=obtener_conexion();cur=cn.cursor(dictionary=True)
        method=request.form.get('payment_method') or 'ACCOUNT:'+request.form.get('account_id','')
        pagar_deuda_contable(cur,usuario_actual(),debt_id,method,dinero(request.form.get('amount')),fecha(request.form.get('occurred_at')),request.form.get('installment_count',1),request.form.get('interest_free')=='1')
        cn.commit();flash('Pago / cobro registrado; primero se aplicó a intereses y después al capital.','ok')
    except ValueError as e:
        if cn:cn.rollback()
        flash(str(e),'error')
    except Exception:
        if cn:cn.rollback()
        from flask import current_app
        current_app.logger.exception('Pago de deuda')
        flash('No fue posible registrar el pago.','error')
    finally:cerrar(cn,cur)
    return redirect(url_for('avanzado.deudas'))


@avanzado.route("/presupuesto")
def presupuesto():
    from gestion import mostrar_presupuesto
    return mostrar_presupuesto()


@avanzado.route("/movimientos/<tx_id>")
def detalle_movimiento(tx_id):
    tx=datos("SELECT ft.*,c.name category FROM financial_transactions ft LEFT JOIN incomes i ON i.transaction_id=ft.id LEFT JOIN expenses e ON e.transaction_id=ft.id LEFT JOIN categories c ON c.id=COALESCE(i.category_id,e.category_id) WHERE ft.id=%s AND ft.user_id=%s",(tx_id,usuario_actual()),True)
    if not tx:return redirect(url_for("inicio"))
    payments=datos("SELECT ep.*,a.name account_name,dc.brand debit_brand,dc.last_four debit_last,cc.name credit_name,cc.last_four credit_last FROM expense_payments ep LEFT JOIN accounts a ON a.id=ep.account_id LEFT JOIN debit_cards dc ON dc.id=ep.debit_card_id LEFT JOIN credit_cards cc ON cc.id=ep.credit_card_id WHERE ep.expense_transaction_id=%s",(tx_id,))
    refund=datos("SELECT COALESCE(SUM(r.amount),0) total FROM refunds r JOIN financial_transactions ft ON ft.id=r.transaction_id WHERE r.expense_transaction_id=%s AND ft.voided_at IS NULL",(tx_id,),True)["total"] if tx["type"]=="EXPENSE" else 0
    plans=datos("SELECT ip.* FROM credit_card_charges cc JOIN installment_plans ip ON ip.credit_card_charge_id=cc.id WHERE cc.expense_payment_id IN (SELECT id FROM expense_payments WHERE expense_transaction_id=%s)",(tx_id,))
    entries=datos('SELECT ae.amount,a.name FROM account_entries ae JOIN accounts a ON a.id=ae.account_id WHERE ae.transaction_id=%s',(tx_id,))
    audit=datos('SELECT * FROM transaction_audit WHERE transaction_id=%s ORDER BY created_at',(tx_id,))
    return render_template("movimiento_detalle.html",tx=tx,payments=payments,refund=refund,plans=plans,entries=entries,audit=audit,hoy=date.today().isoformat())


@avanzado.route("/gastos/<tx_id>/reintegro",methods=["POST"])
def reintegro(tx_id):
    cn=cur=None
    try:
        cn=obtener_conexion();cur=cn.cursor(dictionary=True)
        reintegrar(cur,usuario_actual(),tx_id,dinero(request.form.get('amount')),fecha(request.form.get('occurred_at')))
        cn.commit();flash('Reintegro registrado en los medios originales. No se considera ingreso.','ok')
    except ValueError as e:
        if cn:cn.rollback()
        flash(str(e),'error')
    except Exception:
        if cn:cn.rollback()
        flash('No fue posible registrar el reintegro.','error')
    finally:cerrar(cn,cur)
    return redirect(url_for('avanzado.detalle_movimiento',tx_id=tx_id))


@avanzado.route("/ingresos/<tx_id>/eliminar", methods=["POST"])
def eliminar_ingreso(tx_id):
    from gestion import anular_movimiento
    return anular_movimiento(tx_id)
