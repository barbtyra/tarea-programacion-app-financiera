"""Prueba HTTP contra Flask local; elimina sólo los usuarios temporales que crea."""
from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta
from decimal import Decimal
from http.cookiejar import CookieJar
from urllib.parse import urlencode
from urllib.request import HTTPCookieProcessor, build_opener
from uuid import uuid4

from conexion import obtener_conexion

BASE = "http://127.0.0.1:5000"
HOY = date.today().isoformat()
USUARIOS = []
RESULTADOS = []


def sql(query, params=()):
    cn = obtener_conexion()
    try:
        cur = cn.cursor(dictionary=True)
        cur.execute(query, params)
        rows = cur.fetchall()
        cur.close()
        return rows
    finally:
        cn.close()


def uno(query, params=()):
    rows = sql(query, params)
    assert len(rows) == 1, (query, rows)
    return rows[0]


def ok(nombre):
    RESULTADOS.append(nombre)
    print("OK:", nombre, flush=True)


class Cliente:
    def __init__(self):
        self.http = build_opener(HTTPCookieProcessor(CookieJar()))

    def pedir(self, path, data=None, error=False):
        body = urlencode(data, doseq=True).encode() if data is not None else None
        with self.http.open(BASE + path, body, timeout=15) as response:
            assert response.status == 200, path
            html = response.read().decode("utf-8")
            tiene_error = 'class="mensaje error"' in html
            assert tiene_error == error, (path, html)
            return html

    def registrar(self):
        email = f"fase1-{uuid4().hex}@example.invalid"
        self.pedir("/registro", {"full_name": "Prueba temporal Fase 1", "email": email,
                                "password": "PruebaFase1-2026", "password_confirmation": "PruebaFase1-2026"})
        user = uno("SELECT id FROM users WHERE email=%s", (email,))["id"]
        USUARIOS.append(user)
        return user


def saldo(account):
    return uno("SELECT COALESCE(SUM(amount),0) n FROM account_entries WHERE account_id=%s", (account,))["n"]


def limpiar(user):
    """Las FK permanecen activas; cada DELETE se limita a este usuario de prueba."""
    cn = obtener_conexion()
    try:
        cur = cn.cursor()
        tx = "SELECT id FROM financial_transactions WHERE user_id=%s"
        accounts = "SELECT id FROM accounts WHERE user_id=%s"
        cards = "SELECT id FROM credit_cards WHERE user_id=%s"
        payments = f"SELECT id FROM expense_payments WHERE expense_transaction_id IN ({tx})"
        charges = f"SELECT id FROM credit_card_charges WHERE expense_payment_id IN ({payments})"
        plans = f"SELECT id FROM installment_plans WHERE credit_card_charge_id IN ({charges})"
        debts = "SELECT id FROM debts WHERE created_by_user_id=%s"
        debt_pays = f"SELECT id FROM debt_payments WHERE debt_id IN ({debts})"
        operations = [
            f"DELETE FROM refund_allocations WHERE refund_transaction_id IN ({tx})",
            f"DELETE FROM refunds WHERE transaction_id IN ({tx})",
            f"DELETE FROM card_installments WHERE installment_plan_id IN ({plans})",
            f"DELETE FROM installment_plans WHERE credit_card_charge_id IN ({charges})",
            f"DELETE FROM credit_card_charges WHERE expense_payment_id IN ({payments})",
            f"DELETE FROM credit_card_payments WHERE transaction_id IN ({tx})",
            f"DELETE FROM credit_card_interests WHERE transaction_id IN ({tx})",
            f"DELETE FROM debt_payment_sources WHERE debt_payment_id IN ({debt_pays})",
            f"DELETE FROM debt_payments WHERE debt_id IN ({debts})",
            "DELETE FROM bills WHERE user_id=%s",
            "DELETE FROM recurring_rules WHERE user_id=%s",
            f"DELETE FROM expense_splits WHERE expense_transaction_id IN ({tx})",
            f"DELETE FROM expense_payments WHERE expense_transaction_id IN ({tx})",
            f"DELETE FROM expenses WHERE transaction_id IN ({tx})",
            f"DELETE FROM incomes WHERE transaction_id IN ({tx})",
            f"DELETE FROM transfers WHERE transaction_id IN ({tx})",
            f"DELETE FROM account_entries WHERE account_id IN ({accounts})",
            "DELETE FROM financial_transactions WHERE user_id=%s",
            "DELETE FROM debts WHERE created_by_user_id=%s",
            "DELETE FROM parties WHERE external_contact_id IN (SELECT id FROM external_contacts WHERE owner_user_id=%s)",
            "DELETE FROM parties WHERE user_id=%s",
            "DELETE FROM external_contacts WHERE owner_user_id=%s",
            "DELETE FROM goal_reservations WHERE saving_goal_id IN (SELECT id FROM saving_goals WHERE user_id=%s)",
            "DELETE FROM saving_goals WHERE user_id=%s",
            f"DELETE FROM credit_card_cycles WHERE credit_card_id IN ({cards})",
            "DELETE FROM credit_cards WHERE user_id=%s",
            f"DELETE FROM debit_cards WHERE account_id IN ({accounts})",
            "DELETE FROM accounts WHERE user_id=%s",
            "DELETE FROM categories WHERE user_id=%s",
            "DELETE FROM users WHERE id=%s",
        ]
        for query in operations:
            cur.execute(query, (user,))
        cn.commit()
        cur.close()
    except Exception:
        cn.rollback()
        raise
    finally:
        cn.close()


def probar():
    client = Cliente()
    assert "Iniciar sesión" in client.pedir("/")
    client.pedir("/login", {"email": "demo@app-finanzas.local", "password": "incorrecta"}, error=True)
    client.pedir("/login", {"email": "demo@app-finanzas.local", "password": "demo1234"})
    ok("Redirección sin sesión y autenticación demo válida/inválida")
    client.pedir("/salir")
    user = client.registrar()
    cash = uno("SELECT id FROM accounts WHERE user_id=%s AND type='CASH'", (user,))["id"]
    income_cat = uno("SELECT id FROM categories WHERE user_id IS NULL AND kind='INCOME' ORDER BY name LIMIT 1")["id"]
    expense_cat = uno("SELECT id FROM categories WHERE user_id IS NULL AND kind='EXPENSE' ORDER BY name LIMIT 1")["id"]
    pages = ["/", "/cuentas", "/ingresos", "/gastos", "/transferencias", "/historial", "/tarjetas-debito",
             "/tarjetas-credito", "/categorias", "/metas", "/facturas", "/deudas", "/presupuesto", "/registro", "/login", "/static/css/styles.css"]
    for path in pages:
        client.pedir(path)
    ok("Registro y 16 páginas/recursos HTTP 200")
    client.pedir("/cuentas", {"name": "Cuenta Fase1", "type": "SAVINGS"})
    bank = uno("SELECT id FROM accounts WHERE user_id=%s AND type='SAVINGS'", (user,))["id"]
    client.pedir("/ingresos", {"account_id": cash, "category_id": income_cat, "amount": "100000", "occurred_at": HOY, "description": "Ingreso Fase1"})
    assert saldo(cash) == Decimal("100000")
    income = uno("SELECT id FROM financial_transactions WHERE user_id=%s AND type='INCOME'", (user,))["id"]
    ok("Cuenta e ingreso confirmados desde conexiones independientes (COMMIT)")

    def gasto(description, amount, methods, amounts, installments=1):
        client.pedir("/gastos", {"category_id": expense_cat, "amount": amount, "description": description,
                                "occurred_at": HOY, "payment_method": methods, "payment_amount": amounts, "installment_count": installments})
        return uno("SELECT id FROM financial_transactions WHERE user_id=%s AND description=%s", (user, description))["id"]

    client.pedir("/gastos", {"category_id": expense_cat, "amount": "100", "occurred_at": HOY,
                            "payment_method": "ACCOUNT:" + cash, "payment_amount": "99"}, error=True)
    assert uno("SELECT COUNT(*) n FROM financial_transactions WHERE user_id=%s", (user,))["n"] == 1
    expense = gasto("Gasto efectivo", "10000", ["ACCOUNT:" + cash], ["10000"])
    client.pedir("/transferencias", {"source_account_id": cash, "destination_account_id": bank, "amount": "20000", "occurred_at": HOY})
    assert saldo(cash) == Decimal("70000") and saldo(bank) == Decimal("20000")
    client.pedir("/tarjetas-debito", {"account_id": bank, "last_four": "1234", "brand": "Prueba", "status": "ACTIVE"})
    debit = uno("SELECT id FROM debit_cards WHERE account_id=%s", (bank,))["id"]
    gasto("Gasto débito", "5000", ["DEBIT:" + debit], ["5000"])
    assert saldo(bank) == Decimal("15000")
    ok("Gasto efectivo, débito, transferencia y rechazo sin escritura de suma inválida")
    card_data = {"name": "Crédito Fase1", "last_four": "5678", "credit_limit": "100000", "annual_interest_rate": "12", "closing_day": "20", "due_day": "5", "status": "ACTIVE"}
    client.pedir("/tarjetas-credito", card_data)
    card = uno("SELECT id FROM credit_cards WHERE user_id=%s", (user,))["id"]
    gasto("Gasto crédito", "12000", ["CREDIT:" + card], ["12000"])
    installment_expense = gasto("Gasto cuotas", "9000", ["CREDIT:" + card], ["9000"], 3)
    assert uno("SELECT COUNT(*) n FROM card_installments ci JOIN installment_plans ip ON ip.id=ci.installment_plan_id JOIN credit_card_charges cc ON cc.id=ip.credit_card_charge_id JOIN expense_payments ep ON ep.id=cc.expense_payment_id WHERE ep.expense_transaction_id=%s", (installment_expense,))["n"] == 3
    assert all(row['closed_at'] is None for row in sql("SELECT closed_at FROM credit_card_cycles WHERE credit_card_id=%s", (card,)))
    split = gasto("Gasto dividido", "6000", ["ACCOUNT:" + cash, "DEBIT:" + debit, "CREDIT:" + card], ["2000", "1000", "3000"])
    client.pedir(f"/gastos/{expense}/reintegro", {"amount": "4000", "occurred_at": HOY})
    client.pedir(f"/gastos/{split}/reintegro", {"amount": "6000", "occurred_at": HOY})
    assert saldo(cash) == Decimal("74000") and saldo(bank) == Decimal("15000")
    client.pedir(f"/tarjetas-credito/{card}")
    client.pedir(f"/tarjetas-credito/{card}/editar", {**card_data, "name": "Crédito editado"})
    client.pedir(f"/tarjetas-credito/{card}/pagar", {"account_id": cash, "amount": "5000", "occurred_at": HOY})
    assert uno("SELECT amount FROM credit_card_payments WHERE credit_card_id=%s", (card,))["amount"] == Decimal("5000")
    ok("Crédito, ciclo abierto, cuotas, gasto dividido, reintegros y pago/edición de tarjeta")
    client.pedir("/metas", {"account_id": bank, "name": "Meta temporal", "target_amount": "10000"})
    goal = uno("SELECT id FROM saving_goals WHERE user_id=%s", (user,))["id"]
    for action, amount in [("reserve", "1000"), ("release", "500")]:
        client.pedir(f"/metas/{goal}/reservar", {"action": action, "amount": amount})
    assert uno("SELECT SUM(amount_delta) n FROM goal_reservations WHERE saving_goal_id=%s", (goal,))["n"] == Decimal("500")
    assert saldo(bank) == Decimal("15000")
    ok("Reserva/liberación de meta sin alterar el saldo contable")
    for name, variable in [("Factura pagada", "1"), ("Factura cancelada", "0")]:
        client.pedir("/facturas", {"name": name, "category_id": expense_cat, "frequency": "MONTHLY", "is_variable_amount": variable,
                                  "expected_amount": "2000", "next_due_on": (date.today() + timedelta(days=10)).isoformat()})
        bill = uno("SELECT id FROM bills WHERE user_id=%s AND description=%s", (user, name))["id"]
        action = "pagar" if variable == "1" else "cancelar"
        client.pedir(f"/facturas/{bill}/{action}", {"account_id": cash, "occurred_at": HOY})
        assert uno("SELECT status FROM bills WHERE id=%s", (bill,))["status"] == ("PAID" if action == "pagar" else "CANCELLED")
    ok("Recurrentes, factura variable pagada, promedio y cancelación")
    for direction, total in [("PAYABLE", 10000), ("RECEIVABLE", 5000)]:
        client.pedir("/deudas", {"contact_name": "Contacto " + direction, "direction": direction, "original_amount": str(total), "annual_interest_rate": "0", "description": direction})
        debt = uno("SELECT id FROM debts WHERE created_by_user_id=%s AND description=%s", (user, direction))["id"]
        before = saldo(cash)
        for part in [2000, total - 2000]:
            client.pedir(f"/deudas/{debt}/pagar", {"account_id": cash, "amount": str(part), "occurred_at": HOY})
        assert uno("SELECT status FROM debts WHERE id=%s", (debt,))["status"] == "SETTLED"
        assert saldo(cash) == before + (total if direction == "RECEIVABLE" else -total)
    ok("Deudas por pagar/cobrar, pagos parciales, saldos y liquidación")
    client.pedir("/categorias", {"name": "Categoría temporal Fase1", "kind": "EXPENSE"})
    category = uno("SELECT id FROM categories WHERE user_id=%s", (user,))["id"]
    client.pedir(f"/categorias/{category}/desactivar", {})
    assert uno("SELECT is_active FROM categories WHERE id=%s", (category,))["is_active"] == 0
    before = saldo(cash)
    client.pedir("/ingresos", {"account_id": cash, "category_id": income_cat, "amount": "7000", "occurred_at": HOY, "description": "Ingreso a eliminar"})
    removable = uno("SELECT id FROM financial_transactions WHERE user_id=%s AND description='Ingreso a eliminar'", (user,))["id"]
    client.pedir(f"/ingresos/{removable}/eliminar", {})
    assert saldo(cash) == before
    assert uno("SELECT COUNT(*) n FROM financial_transactions WHERE id=%s", (income,))["n"] == 1
    ok("Categoría propia/desactivación y eliminación de ingreso sin reiniciar otros saldos")
    for tx in sql("SELECT id FROM financial_transactions WHERE user_id=%s", (user,)):
        client.pedir("/movimientos/" + tx["id"])
    for path in pages:
        client.pedir(path)
    second = Cliente()
    other = second.registrar()
    second.pedir("/cuentas", {"name": "Privada otro usuario", "type": "SAVINGS"})
    before_refunds = uno("SELECT COUNT(*) n FROM refunds")["n"]
    second.pedir(f"/gastos/{expense}/reintegro", {"amount": "1000", "occurred_at": HOY}, error=True)
    assert uno("SELECT COUNT(*) n FROM refunds")["n"] == before_refunds
    other_cash = uno("SELECT id FROM accounts WHERE user_id=%s AND type='CASH'", (other,))["id"]
    before_payments = uno("SELECT COUNT(*) n FROM credit_card_payments")["n"]
    second.pedir(f"/tarjetas-credito/{card}/pagar", {"account_id": other_cash, "amount": "1000", "occurred_at": HOY}, error=True)
    assert uno("SELECT COUNT(*) n FROM credit_card_payments")["n"] == before_payments
    def aislamiento(pair):
        browser, forbidden = pair
        assert forbidden not in browser.pedir("/cuentas")
        browser.pedir("/metas")
    with ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(aislamiento, [(client, "Privada otro usuario"), (second, "Cuenta Fase1")] * 6))
    ok("Detalles, páginas con datos y aislamiento de dos sesiones concurrentes")
    client.pedir("/salir")
    assert "Iniciar sesión" in client.pedir("/historial")
    ok("Cierre de sesión y protección de rutas")


if __name__ == "__main__":
    print('El proyecto está en fase 2: la regresión de fase 1 se ejecutará en una base temporal segura.')
    from verificar_fase2 import main
    main()
