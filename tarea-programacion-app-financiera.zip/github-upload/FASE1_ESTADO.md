# Fase 1 — 20/10/2026

Aplicación operativa y comprobada por HTTP. Queda pendiente la comprobación visual: el control de Windows se detuvo al no poder identificar con seguridad la URL del navegador. No se avanzó a fase 2.

- Entorno: Python 3.14, `.venv\Scripts\python.exe`; dependencias verificadas con `pip check` y fijadas en `requirements.txt`. El entorno de macOS se conserva en `.venv-macos-original`.
- XAMPP: `C:\xampp`; MariaDB 10.4.32 activo en `127.0.0.1:3306`, usuario `root`, contraseña vacía. Apache no se utiliza para Flask. No se modificó la configuración global de XAMPP.
- `app_finanzas` no existía. Se creó con utf8mb4/InnoDB: 37 tablas y 83 relaciones. Se añadieron `password_hash` y definiciones explícitas de TIMESTAMP al esquema original. `Database.sql` es un alias binario de macOS: no importarlo.
- Datos finales: usuario demo, moneda PYG, seis categorías y una cuenta Efectivo; cero movimientos y cero usuarios temporales. Copia inicial: `backups\app_finanzas_fase1_inicial.sql`.
- Cambios: `app.py`, `avanzado.py`, `conexion.py`, `requirements.txt`, `Database_MariaDB_XAMPP.sql`. Corregidos inicialización/contraseña demo, aislamiento de sesiones, autorización de reintegros/pagos de tarjeta y eliminación de ingresos. El inicio ya no cambia monedas existentes. La conexión permite variables `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`.
- Pruebas: `verificar_fase1.py`, resultados en `verificacion_fase1.log`: 12 grupos correctos; registro/login, 16 páginas/recursos, operaciones existentes, COMMIT leído desde conexiones independientes y sesiones concurrentes. Limpieza limitada a usuarios temporales; conteos originales conservados.

Inicio desde esta carpeta, con MySQL activo en XAMPP:

```powershell
.\.venv\Scripts\python.exe app.py
```

URL: http://127.0.0.1:5000/login. Acceso: `demo@app-finanzas.local` / `demo1234`. El servidor queda iniciado. Registros: `flask.stderr.log` y `flask.stdout.log`. Las limitaciones funcionales previas siguen descritas en `ROADMAP.md`.
