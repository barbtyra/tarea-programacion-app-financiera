"""Generación recuperable al acceder y cada minuto mientras Flask está activo."""
import logging
from datetime import date, datetime, timedelta
from decimal import Decimal
from threading import Event, Thread

from conexion import obtener_conexion
from finanzas import (CENTAVO, CERO, consultar, ciclo, dinero, estado_ciclos,
                      importe_ciclo, sumar_meses, transaccion, uid)


def proxima_fecha(rule, current):
    if rule['frequency'] == 'WEEKLY':
        return current + timedelta(days=7)
    count = {'MONTHLY': 1, 'QUARTERLY': 3, 'YEARLY': 12}[rule['frequency']]
    return sumar_meses(current, count, rule['anchor_day'] or current.day)


def automatizar(user, hoy=None):
    hoy = hoy or date.today()
    cn = obtener_conexion()
    try:
        cur = cn.cursor(dictionary=True)
        if not consultar(cur, 'SELECT id FROM users WHERE id=%s AND deleted_at IS NULL FOR UPDATE', (user,), True):
            return
        rules = consultar(cur, 'SELECT * FROM recurring_rules WHERE user_id=%s AND is_active=TRUE FOR UPDATE', (user,))
        for rule in rules:
            due = rule['next_due_on']
            if not rule['anchor_day']:
                cur.execute('UPDATE recurring_rules SET anchor_day=%s,anchor_month=%s WHERE id=%s', (due.day, due.month, rule['id']))
                rule['anchor_day'] = due.day
            # Tres últimos pagos reales; AVG sobre el subconjunto, no sobre toda la historia.
            amount = rule['expected_amount']
            if rule['is_variable_amount']:
                averages = consultar(cur, '''SELECT b.amount FROM bills b JOIN financial_transactions ft ON ft.id=b.paid_expense_transaction_id
 WHERE b.recurring_rule_id=%s AND b.status='PAID' AND ft.voided_at IS NULL ORDER BY b.due_on DESC LIMIT 3''', (rule['id'],))
                if averages:
                    amount = dinero(sum((r['amount'] for r in averages), CERO) / len(averages))
            if not amount or amount <= 0:
                continue
            count = 0
            while due <= hoy + timedelta(days=30):
                if not consultar(cur, 'SELECT id FROM bills WHERE recurring_rule_id=%s AND due_on=%s LIMIT 1', (rule['id'], due), True):
                    cur.execute('INSERT INTO bills (id,recurring_rule_id,user_id,currency_code,category_id,description,amount,due_on,status,created_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)',
                                (uid(), rule['id'], user, rule['currency_code'], rule['category_id'], rule['name'], amount, due, 'OVERDUE' if due < hoy else 'PENDING', datetime.now()))
                due = proxima_fecha(rule, due)
                count += 1
                if count >= 5200:
                    raise ValueError('Revise la fecha inicial de la regla recurrente: supera cien años de facturas.')
            cur.execute('UPDATE recurring_rules SET next_due_on=%s WHERE id=%s', (due, rule['id']))
        cur.execute("UPDATE bills SET status='OVERDUE' WHERE user_id=%s AND status='PENDING' AND due_on<%s", (user, hoy))
        cards = consultar(cur, "SELECT * FROM credit_cards WHERE user_id=%s AND status<>'ARCHIVED'", (user,))
        for card in cards:
            earliest = consultar(cur, 'SELECT MIN(closes_on) first_close FROM credit_card_cycles WHERE credit_card_id=%s', (card['id'],), True)['first_close']
            if earliest:
                cursor_date = earliest + timedelta(days=1)
                while cursor_date <= hoy:
                    next_cycle = ciclo(cur, card['id'], cursor_date)
                    cursor_date = next_cycle['closes_on'] + timedelta(days=1)
            ciclo(cur, card['id'], hoy)
            open_cycles = consultar(cur, 'SELECT * FROM credit_card_cycles WHERE credit_card_id=%s AND closes_on<%s AND closed_at IS NULL ORDER BY closes_on', (card['id'], hoy))
            for current in open_cycles:
                prior = estado_ciclos(cur, card['id'])
                overdue = sum((c['pending'] for c in prior if c['due_on'] < current['closes_on'] and c['closes_on'] < current['closes_on']), CERO)
                marker = consultar(cur, "SELECT 1 n FROM automation_events WHERE user_id=%s AND kind='CARD_INTEREST' AND reference_id=%s AND period=%s", (user, card['id'], current['closes_on']), True)
                if not marker:
                    monthly = Decimal(card['annual_interest_rate'] or 0) / Decimal(1200)
                    interest = (overdue * monthly).quantize(CENTAVO)
                    if interest > 0:
                        tx = transaccion(cur, user, 'CARD_INTEREST', current['closes_on'], 'Interés mensual sobre saldo vencido · ' + card['name'], card['currency_code'])
                        cur.execute('INSERT INTO credit_card_interests (transaction_id,credit_card_id,credit_card_cycle_id,amount,rate_applied) VALUES (%s,%s,%s,%s,%s)',
                                    (tx, card['id'], current['id'], interest, monthly))
                    cur.execute("INSERT INTO automation_events (user_id,kind,reference_id,period) VALUES (%s,'CARD_INTEREST',%s,%s)", (user, card['id'], current['closes_on']))
                total = importe_ciclo(cur, current['id'])
                cur.execute('UPDATE credit_card_cycles SET statement_balance=%s,minimum_payment=%s,closed_at=%s WHERE id=%s',
                            (total, (total * Decimal('0.05')).quantize(CENTAVO), datetime.now(), current['id']))
            estado_ciclos(cur, card['id'], actualizar=True)
        cn.commit()
        cur.close()
    except Exception:
        cn.rollback()
        raise
    finally:
        cn.close()


def iniciar_automatizacion():
    def run():
        pause = Event()
        while not pause.wait(60):
            try:
                cn = obtener_conexion()
                try:
                    cur = cn.cursor(dictionary=True)
                    users = consultar(cur, '''SELECT id FROM users WHERE deleted_at IS NULL AND
 (EXISTS(SELECT 1 FROM recurring_rules rr WHERE rr.user_id=users.id AND rr.is_active=TRUE)
 OR EXISTS(SELECT 1 FROM credit_cards cc WHERE cc.user_id=users.id AND cc.status<>'ARCHIVED'))''')
                    cur.close()
                finally:
                    cn.close()
                for user in users:
                    automatizar(user['id'])
            except Exception:
                logging.exception('No se pudo completar la actualización automática; se reintentará.')
    Thread(target=run, name='finanzas-automatizacion', daemon=True).start()
