"""Corrige planes de fase 1 sólo si sus cuotas no están pagadas ni cerradas."""
from datetime import timedelta
import json

from conexion import obtener_conexion
from finanzas import CERO, consultar, ciclo, uid


def migrar_planes_legacy():
    cn=obtener_conexion();pending=[];changed=0
    try:
        cur=cn.cursor(dictionary=True)
        plans=consultar(cur,'''SELECT ip.*,ft.id transaction_id,ft.user_id,ft.occurred_at,
 COALESCE(ep.credit_card_id,ds.credit_card_id) card_id FROM installment_plans ip
 JOIN credit_card_charges cc ON cc.id=ip.credit_card_charge_id
 LEFT JOIN expense_payments ep ON ep.id=cc.expense_payment_id LEFT JOIN debt_payment_sources ds ON ds.id=cc.debt_payment_source_id
 LEFT JOIN debt_payments dp ON dp.id=ds.debt_payment_id JOIN financial_transactions ft ON ft.id=COALESCE(ep.expense_transaction_id,dp.transaction_id)
 WHERE ft.voided_at IS NULL FOR UPDATE''')
        for plan in plans:
            parts=consultar(cur,'SELECT ci.*,cy.closed_at FROM card_installments ci LEFT JOIN credit_card_cycles cy ON cy.id=ci.credit_card_cycle_id WHERE ci.installment_plan_id=%s ORDER BY installment_number',(plan['id'],))
            wrong_cycle=len(parts)>1 and len({p['credit_card_cycle_id'] for p in parts})==1
            wrong_total=sum((p['due_amount'] for p in parts),CERO)!=plan['financed_total']
            if not wrong_cycle and not wrong_total:continue
            if len(parts)!=plan['installment_count'] or any(p['closed_at'] or p['status'] in {'PAID','CANCELLED'} for p in parts):
                pending.append(plan['id']);continue
            remainder=plan['financed_total']-sum((p['due_amount'] for p in parts[:-1]),CERO)
            if remainder<=0:
                pending.append(plan['id']);continue
            cur.execute('INSERT INTO transaction_audit (id,transaction_id,user_id,action,snapshot) VALUES (%s,%s,%s,%s,%s)',
                        (uid(),plan['transaction_id'],plan['user_id'],'MIGRATE_PLAN',json.dumps({'plan':plan,'installments':parts},default=str,ensure_ascii=False)))
            first=ciclo(cur,plan['card_id'],plan['occurred_at'].date());current=first
            for index,part in enumerate(parts):
                cur.execute('UPDATE card_installments SET credit_card_cycle_id=%s,due_amount=%s WHERE id=%s',
                            (current['id'],remainder if index==len(parts)-1 else part['due_amount'],part['id']))
                if index<len(parts)-1:current=ciclo(cur,plan['card_id'],current['closes_on']+timedelta(days=1))
            cur.execute('UPDATE installment_plans SET first_due_on=%s WHERE id=%s',(first['due_on'],plan['id']))
            changed+=1
        cn.commit();cur.close()
        return {'corregidos':changed,'revision_manual':pending}
    except Exception:
        cn.rollback();raise
    finally:cn.close()
