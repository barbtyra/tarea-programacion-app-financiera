"""Ampliaciones del gestor sobre las cuentas y movimientos existentes."""
import csv
import io
import json
from datetime import date, datetime, timedelta
from decimal import Decimal
from functools import wraps
from urllib.parse import urlsplit

from flask import Blueprint, Response, abort, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from analitica import datos, eventos, movimientos, TIPOS
from conexion import obtener_conexion
from finanzas import (CENTAVO, CERO, asiento, consultar, cuenta_propia, dinero, estado_ciclos,
                      estado_deuda, fecha, saldo_credito, sumar_meses, tasa, texto, transaccion, uid, ciclo)

gestion = Blueprint('gestion', __name__)


def usuario():
    return session['user_id']


def volver(default='/'):
    origin = urlsplit(request.referrer or '')
    if origin.netloc == request.host and origin.path.startswith('/') and not origin.path.startswith('//'):
        return origin.path + (('?' + origin.query) if origin.query else '')
    return default


def escritura(default='/'):
    def decorate(function):
        @wraps(function)
        def wrapped(*args, **kwargs):
            cn = obtener_conexion()
            try:
                cur = cn.cursor(dictionary=True)
                consultar(cur, 'SELECT id FROM users WHERE id=%s FOR UPDATE', (usuario(),), True)
                target = function(cur, *args, **kwargs)
                cn.commit()
                flash('Cambios guardados correctamente.', 'ok')
                cur.close()
                return redirect(target or volver(default))
            except ValueError as error:
                cn.rollback()
                flash(str(error), 'error')
                return redirect(volver(default))
            except Exception:
                cn.rollback()
                from flask import current_app
                current_app.logger.exception('Operación %s', function.__name__)
                flash('No pudimos guardar los cambios. Revise los datos e intente nuevamente; su borrador se conserva.', 'error')
                return redirect(volver(default))
            finally:
                cn.close()
        return wrapped
    return decorate


@gestion.route('/configuracion', methods=['GET'])
def configuracion():
    return render_template('configuracion.html')


@gestion.route('/configuracion', methods=['POST'])
@escritura('/configuracion')
def guardar_configuracion(cur):
    name = texto(request.form.get('full_name'), 150, 'El nombre')
    email = texto(request.form.get('email'), 254, 'El correo').lower()
    if '@' not in email or '.' not in email.rsplit('@', 1)[-1]:
        raise ValueError('Ingrese un correo electrónico válido.')
    profile = consultar(cur, 'SELECT * FROM users WHERE id=%s FOR UPDATE', (usuario(),), True)
    new_password = request.form.get('new_password', '')
    if email != profile['email'] or new_password:
        if not check_password_hash(profile['password_hash'], request.form.get('current_password', '')):
            raise ValueError('La contraseña actual no es correcta. Sus otros campos se conservan.')
    if new_password:
        if len(new_password) < 8 or len(new_password)>128 or new_password != request.form.get('password_confirmation'):
            raise ValueError('La nueva contraseña debe tener entre 8 y 128 caracteres y coincidir con la confirmación.')
        cur.execute('UPDATE users SET password_hash=%s WHERE id=%s', (generate_password_hash(new_password), usuario()))
    if consultar(cur, 'SELECT id FROM users WHERE email=%s AND id<>%s', (email, usuario()), True):
        raise ValueError('Ese correo ya está registrado.')
    theme = request.form.get('theme', 'light')
    if theme not in {'light', 'dark', 'system'}:
        raise ValueError('Seleccione un tema válido.')
    income = dinero(request.form['monthly_income'], positivo=False) if request.form.get('monthly_income') else None
    if income is not None and income < 0:
        raise ValueError('El ingreso mensual previsto no puede ser negativo.')
    cur.execute('UPDATE users SET full_name=%s,email=%s WHERE id=%s', (name, email, usuario()))
    cur.execute('''INSERT INTO user_preferences (user_id,theme,hide_balances,monthly_income) VALUES (%s,%s,%s,%s)
 ON DUPLICATE KEY UPDATE theme=VALUES(theme),hide_balances=VALUES(hide_balances),monthly_income=VALUES(monthly_income)''',
                (usuario(), theme, request.form.get('hide_balances') == '1', income))
    session['user_name'] = name
    return '/configuracion'


@gestion.route('/cuentas/<account_id>/editar', methods=['POST'])
@escritura('/cuentas')
def editar_cuenta(cur, account_id):
    account = cuenta_propia(cur, account_id, usuario())
    name = texto(request.form.get('name'), 100)
    kind = request.form.get('type')
    if kind not in {'CASH','SAVINGS','CHECKING','DIGITAL','OTHER'}:
        raise ValueError('Seleccione un tipo de cuenta válido.')
    if kind != account['type'] and consultar(cur, 'SELECT 1 n FROM debit_cards WHERE account_id=%s LIMIT 1', (account_id,), True) and kind == 'CASH':
        raise ValueError('Una cuenta con tarjeta de débito no puede convertirse en efectivo.')
    cur.execute('UPDATE accounts SET name=%s,type=%s WHERE id=%s', (name, kind, account_id))
    return '/cuentas'


@gestion.route('/cuentas/<account_id>/archivar', methods=['POST'])
@escritura('/cuentas')
def archivar_cuenta(cur, account_id):
    cuenta_propia(cur, account_id, usuario())
    balance = consultar(cur, 'SELECT COALESCE(SUM(amount),0) n FROM account_entries WHERE account_id=%s', (account_id,), True)['n']
    if balance or consultar(cur, 'SELECT id FROM saving_goals WHERE account_id=%s AND is_active=TRUE LIMIT 1', (account_id,), True) or consultar(cur, "SELECT id FROM debit_cards WHERE account_id=%s AND status='ACTIVE' LIMIT 1", (account_id,), True):
        raise ValueError('Para archivar, deje el saldo en cero, archive las metas y bloquee las tarjetas de débito asociadas.')
    cur.execute("UPDATE accounts SET status='ARCHIVED' WHERE id=%s", (account_id,))
    return '/cuentas'


@gestion.route('/cuentas/<account_id>/restaurar', methods=['POST'])
@escritura('/cuentas')
def restaurar_cuenta(cur, account_id):
    cur.execute("UPDATE accounts SET status='ACTIVE' WHERE id=%s AND user_id=%s", (account_id, usuario()))
    if not cur.rowcount:
        raise ValueError('No se encontró esa cuenta.')
    return '/cuentas'


@gestion.route('/tarjetas-debito/<card_id>/editar', methods=['POST'])
@escritura('/tarjetas-debito')
def editar_debito(cur, card_id):
    card = consultar(cur, 'SELECT dc.* FROM debit_cards dc JOIN accounts a ON a.id=dc.account_id WHERE dc.id=%s AND a.user_id=%s FOR UPDATE', (card_id, usuario()), True)
    last = request.form.get('last_four', '')
    status = request.form.get('status', 'ACTIVE')
    if not card or len(last) != 4 or not last.isascii() or not last.isdigit() or status not in {'ACTIVE','BLOCKED','EXPIRED','ARCHIVED'}:
        raise ValueError('Revise los cuatro dígitos y el estado de la tarjeta.')
    expires = fecha(request.form['expires_on']) if request.form.get('expires_on') else None
    cur.execute('UPDATE debit_cards SET brand=%s,last_four=%s,expires_on=%s,status=%s WHERE id=%s', ((request.form.get('brand') or '')[:40] or None, last, expires, status, card_id))
    return '/tarjetas-debito'


@gestion.route('/categorias/<category_id>/editar', methods=['POST'])
@escritura('/categorias')
def editar_categoria(cur, category_id):
    category = consultar(cur, 'SELECT * FROM categories WHERE id=%s AND user_id=%s FOR UPDATE', (category_id, usuario()), True)
    if not category:
        raise ValueError('Sólo puede editar sus categorías propias.')
    cur.execute('UPDATE categories SET name=%s,is_active=%s WHERE id=%s', (texto(request.form.get('name'),80), request.form.get('is_active')=='1', category_id))
    return '/categorias'


@gestion.route('/metas/<goal_id>/editar', methods=['POST'])
@escritura('/metas')
def editar_meta(cur, goal_id):
    goal=consultar(cur,'SELECT * FROM saving_goals WHERE id=%s AND user_id=%s FOR UPDATE',(goal_id,usuario()),True)
    if not goal:raise ValueError('La meta no está disponible.')
    target=dinero(request.form.get('target_amount'));name=texto(request.form.get('name'),120)
    active=request.form.get('is_active')=='1'
    if not active:
        reserved=consultar(cur,'SELECT COALESCE(SUM(amount_delta),0) n FROM goal_reservations WHERE saving_goal_id=%s',(goal_id,),True)['n']
        if reserved:
            cur.execute('INSERT INTO goal_reservations (id,saving_goal_id,amount_delta,reserved_at,note) VALUES (%s,%s,%s,%s,%s)',(uid(),goal_id,-reserved,datetime.now(),'Liberación al archivar la meta'))
    due=fecha(request.form['target_date']) if request.form.get('target_date') else None
    cur.execute('UPDATE saving_goals SET name=%s,target_amount=%s,target_date=%s,is_active=%s WHERE id=%s',(name,target,due,active,goal_id))
    return '/metas'


@gestion.route('/recurrentes/<rule_id>/editar', methods=['POST'])
@escritura('/facturas')
def editar_recurrente(cur, rule_id):
    rule=consultar(cur,'SELECT * FROM recurring_rules WHERE id=%s AND user_id=%s FOR UPDATE',(rule_id,usuario()),True)
    if not rule:raise ValueError('La regla no está disponible.')
    due=fecha(request.form.get('next_due_on'));frequency=request.form.get('frequency')
    if frequency not in {'WEEKLY','MONTHLY','QUARTERLY','YEARLY'}:raise ValueError('Seleccione una frecuencia válida.')
    unchanged=due==rule['next_due_on'] and frequency==rule['frequency']
    anchor_day=(rule['anchor_day'] or due.day) if unchanged else due.day
    anchor_month=(rule['anchor_month'] or due.month) if unchanged else due.month
    cur.execute('UPDATE recurring_rules SET name=%s,expected_amount=%s,frequency=%s,next_due_on=%s,anchor_day=%s,anchor_month=%s,is_active=%s,is_variable_amount=%s WHERE id=%s',
                (texto(request.form.get('name'),120),dinero(request.form.get('expected_amount')),frequency,due,anchor_day,anchor_month,request.form.get('is_active')=='1',request.form.get('is_variable_amount')=='1',rule_id))
    return '/facturas'


@gestion.route('/facturas/<bill_id>/editar', methods=['POST'])
@escritura('/facturas')
def editar_factura(cur,bill_id):
    bill=consultar(cur,"SELECT * FROM bills WHERE id=%s AND user_id=%s AND status IN ('PENDING','OVERDUE') FOR UPDATE",(bill_id,usuario()),True)
    if not bill:raise ValueError('Sólo se puede editar una factura pendiente.')
    due=fecha(request.form.get('due_on'))
    cur.execute('UPDATE bills SET description=%s,amount=%s,due_on=%s,status=%s WHERE id=%s',
                (texto(request.form.get('description'),255,'La descripción'),dinero(request.form.get('amount')),due,'OVERDUE' if due<date.today() else 'PENDING',bill_id))
    return '/facturas'


def mostrar_presupuesto():
    from avanzado import obtener_categorias
    today=date.today();month=today.replace(day=1)
    try:
        selected=fecha(request.args.get('month', month.strftime('%Y-%m'))+'-01')
    except ValueError:
        selected=month;flash('Seleccione un mes válido.','error')
    end=sumar_meses(selected,1);quarter_start=sumar_meses(month,-3)
    quarter=eventos(usuario(),quarter_start,month);current=eventos(usuario(),selected,end)
    history={};spent={}
    for e in quarter:
        if e['kind']=='expense' and e['category_id']:
            history[e['category_id']]=history.get(e['category_id'],CERO)+e['amount']/3
    for e in current:
        if e['kind']=='expense' and e['category_id']:
            spent[e['category_id']]=spent.get(e['category_id'],CERO)+e['amount']
    budgets=datos('SELECT b.*,c.name FROM category_budgets b JOIN categories c ON c.id=b.category_id WHERE b.user_id=%s AND b.month=%s AND b.is_active=TRUE AND b.amount>0 ORDER BY c.name',(usuario(),selected))
    for b in budgets:
        b['spent']=spent.get(b['category_id'],CERO);b['average']=history.get(b['category_id'],CERO)
        b['percent']=max(0,min(100,int(100*b['spent']/b['amount'])))
    income=getattr(g,'preferences',{}).get('monthly_income')
    if income is None:income=sum((e['amount'] for e in quarter if e['kind']=='income'),CERO)/3
    # Facturas reales generadas y cuotas pendientes; no se vuelven a sumar como gastos fijos.
    bills=datos("SELECT COALESCE(SUM(amount),0) n FROM bills WHERE user_id=%s AND status IN ('PENDING','OVERDUE') AND due_on<=%s",(usuario(),today+timedelta(days=30)),True)['n']
    cn=obtener_conexion();cur=cn.cursor(dictionary=True)
    try:
        cards=consultar(cur,"SELECT id FROM credit_cards WHERE user_id=%s AND status<>'ARCHIVED'",(usuario(),))
        quotas=sum((c['pending'] for card in cards for c in estado_ciclos(cur,card['id']) if c['due_on']<=today+timedelta(days=30)),CERO)
        debt_rows=consultar(cur,"SELECT id FROM debts WHERE created_by_user_id=%s AND status='OPEN' AND (due_on IS NULL OR due_on<=%s)",(usuario(),today+timedelta(days=30)))
        debts=sum((d['pending'] for row in debt_rows if (d:=estado_deuda(cur,row['id'],usuario()))['payable']),CERO)
    finally:cur.close();cn.close()
    variable=datos('''SELECT COALESCE(SUM(e.total_amount),0)/3 n FROM expenses e JOIN financial_transactions ft ON ft.id=e.transaction_id
 WHERE ft.user_id=%s AND ft.voided_at IS NULL AND ft.occurred_at>=%s AND ft.occurred_at<%s
 AND NOT EXISTS(SELECT 1 FROM bills b WHERE b.paid_expense_transaction_id=ft.id)
 AND NOT EXISTS(SELECT 1 FROM expense_payments ep WHERE ep.expense_transaction_id=ft.id AND ep.credit_card_id IS NOT NULL)''',(usuario(),quarter_start,month),True)['n']
    refunds=datos('''SELECT COALESCE(SUM(r.amount),0)/3 n FROM refunds r JOIN financial_transactions ft ON ft.id=r.transaction_id
 WHERE ft.user_id=%s AND ft.voided_at IS NULL AND ft.occurred_at>=%s AND ft.occurred_at<%s
 AND NOT EXISTS(SELECT 1 FROM bills b WHERE b.paid_expense_transaction_id=r.expense_transaction_id)
 AND NOT EXISTS(SELECT 1 FROM expense_payments ep WHERE ep.expense_transaction_id=r.expense_transaction_id AND ep.credit_card_id IS NOT NULL)''',(usuario(),quarter_start,month),True)['n']
    variable=max(CERO,variable-refunds)
    averages=[{'name':c['name'],'average':history.get(c['id'],CERO),'spent':spent.get(c['id'],CERO)} for c in obtener_categorias('EXPENSE')]
    total=variable+bills+quotas+debts
    return render_template('presupuesto.html',budgets=budgets,categorias=obtener_categorias('EXPENSE'),month=selected,income=income,variable=variable,bills=bills,quotas=quotas,debts=debts,total=total,available=income-total,averages=averages,quarter_start=quarter_start,quarter_end=month-timedelta(days=1))


@gestion.route('/presupuesto/guardar',methods=['POST'])
@escritura('/presupuesto')
def guardar_presupuesto(cur):
    category=consultar(cur,"SELECT * FROM categories WHERE id=%s AND kind='EXPENSE' AND is_active=TRUE AND (user_id IS NULL OR user_id=%s)",(request.form.get('category_id'),usuario()),True)
    if not category:raise ValueError('Seleccione una categoría de gasto válida.')
    month=fecha(request.form.get('month','')+'-01')
    cur.execute('INSERT INTO category_budgets (id,user_id,category_id,month,amount) VALUES (%s,%s,%s,%s,%s) ON DUPLICATE KEY UPDATE amount=VALUES(amount),is_active=TRUE',(uid(),usuario(),category['id'],month,dinero(request.form.get('amount'))))
    return '/presupuesto?month='+month.strftime('%Y-%m')


@gestion.route('/presupuesto/<budget_id>/quitar',methods=['POST'])
@escritura('/presupuesto')
def quitar_presupuesto(cur,budget_id):
    cur.execute('UPDATE category_budgets SET is_active=FALSE WHERE id=%s AND user_id=%s',(budget_id,usuario()))
    return '/presupuesto'


def grupo_propio(cur,group_id,owner=False):
    group=consultar(cur,'SELECT gr.* FROM `groups` gr JOIN group_members gm ON gm.group_id=gr.id WHERE gr.id=%s AND gm.user_id=%s FOR UPDATE',(group_id,usuario()),True)
    if not group or (owner and group['owner_user_id']!=usuario()):
        raise ValueError('El grupo no está disponible o necesita permiso de su administrador.')
    return group


def vaquita_propia(cur,pool_id,owner=False):
    pool=consultar(cur,'SELECT * FROM pools WHERE id=%s FOR UPDATE',(pool_id,),True)
    if not pool:raise ValueError('La vaquita no está disponible.')
    grupo_propio(cur,pool['group_id'],owner)
    return pool


def saldo_vaquita(cur,pool_id,user=None):
    extra=' AND pc.member_user_id=%s' if user else ''
    args=(pool_id,user) if user else (pool_id,)
    contributions=consultar(cur,'SELECT COALESCE(SUM(pc.amount),0) n FROM pool_contributions pc JOIN financial_transactions ft ON ft.id=pc.transaction_id WHERE pc.pool_id=%s AND ft.voided_at IS NULL'+extra,args,True)['n']
    if user:
        expenses=consultar(cur,'SELECT COALESCE(SUM(s.amount),0) n FROM pool_expense_shares s JOIN pool_expenses pe ON pe.id=s.pool_expense_id JOIN financial_transactions ft ON ft.id=pe.transaction_id WHERE pe.pool_id=%s AND s.user_id=%s AND ft.voided_at IS NULL',(pool_id,user),True)['n']
    else:
        expenses=consultar(cur,'SELECT COALESCE(SUM(pe.amount),0) n FROM pool_expenses pe JOIN financial_transactions ft ON ft.id=pe.transaction_id WHERE pe.pool_id=%s AND ft.voided_at IS NULL',(pool_id,),True)['n']
    return contributions-expenses


@gestion.route('/grupos')
def grupos():
    groups=datos('SELECT gr.*,COUNT(allm.user_id) members FROM `groups` gr JOIN group_members mine ON mine.group_id=gr.id LEFT JOIN group_members allm ON allm.group_id=gr.id WHERE mine.user_id=%s GROUP BY gr.id ORDER BY gr.created_at DESC',(usuario(),))
    invites=datos("SELECT inv.*,gr.name,owner.full_name owner_name FROM group_invitations inv JOIN `groups` gr ON gr.id=inv.group_id JOIN users owner ON owner.id=gr.owner_user_id WHERE inv.invited_email=%s AND inv.status='PENDING'",(g.profile['email'],))
    return render_template('grupos.html',grupos=groups,invitaciones=invites)


@gestion.route('/grupos',methods=['POST'])
@escritura('/grupos')
def crear_grupo(cur):
    group_id=uid()
    cur.execute('INSERT INTO `groups` (id,owner_user_id,name,created_at) VALUES (%s,%s,%s,%s)',(group_id,usuario(),texto(request.form.get('name'),120),datetime.now()))
    cur.execute('INSERT INTO group_members (group_id,user_id,joined_at) VALUES (%s,%s,%s)',(group_id,usuario(),datetime.now()))
    return '/grupos/'+group_id


@gestion.route('/grupos/<group_id>')
def detalle_grupo(group_id):
    cn=obtener_conexion();cur=cn.cursor(dictionary=True)
    try:
        group=grupo_propio(cur,group_id)
        members=consultar(cur,'SELECT u.id,u.full_name FROM group_members gm JOIN users u ON u.id=gm.user_id WHERE gm.group_id=%s ORDER BY u.full_name',(group_id,))
        pools=consultar(cur,'SELECT * FROM pools WHERE group_id=%s ORDER BY created_at DESC',(group_id,))
        for pool in pools:
            pool['balance']=saldo_vaquita(cur,pool['id']);pool['mine']=saldo_vaquita(cur,pool['id'],usuario())
        invites=consultar(cur,'SELECT * FROM group_invitations WHERE group_id=%s ORDER BY created_at DESC',(group_id,)) if group['owner_user_id']==usuario() else []
        return render_template('grupo_detalle.html',grupo=group,members=members,pools=pools,invitaciones=invites)
    except ValueError:
        abort(404,description='No se encontró el grupo solicitado.')
    finally:cur.close();cn.close()


@gestion.route('/grupos/<group_id>/invitar',methods=['POST'])
@escritura('/grupos')
def invitar_grupo(cur,group_id):
    grupo_propio(cur,group_id,True)
    email=texto(request.form.get('email'),254,'El correo').lower()
    if '@' not in email or email==g.profile['email']:raise ValueError('Ingrese el correo de otra persona.')
    cur.execute("INSERT INTO group_invitations (id,group_id,invited_email,status) VALUES (%s,%s,%s,'PENDING') ON DUPLICATE KEY UPDATE status='PENDING'",(uid(),group_id,email))
    flash('La invitación aparecerá cuando esa persona acceda con ese correo. No se envía correo electrónico.','ok')
    return '/grupos/'+group_id


@gestion.route('/invitaciones/<invite_id>/responder',methods=['POST'])
@escritura('/grupos')
def responder_invitacion(cur,invite_id):
    invite=consultar(cur,"SELECT * FROM group_invitations WHERE id=%s AND invited_email=%s AND status='PENDING' FOR UPDATE",(invite_id,g.profile['email']),True)
    if not invite:raise ValueError('La invitación no está disponible.')
    accept=request.form.get('action')=='accept'
    if accept:
        cur.execute('INSERT IGNORE INTO group_members (group_id,user_id,joined_at) VALUES (%s,%s,%s)',(invite['group_id'],usuario(),datetime.now()))
    cur.execute('UPDATE group_invitations SET status=%s WHERE id=%s',('ACCEPTED' if accept else 'DECLINED',invite_id))
    return '/grupos/'+invite['group_id'] if accept else '/grupos'


@gestion.route('/grupos/<group_id>/vaquitas',methods=['POST'])
@escritura('/grupos')
def crear_vaquita(cur,group_id):
    grupo_propio(cur,group_id,True);pool_id=uid()
    target=dinero(request.form['target_amount']) if request.form.get('target_amount') else None
    due=fecha(request.form['target_date']) if request.form.get('target_date') else None
    cur.execute("INSERT INTO pools (id,group_id,currency_code,name,target_amount,target_date,status,created_at) VALUES (%s,%s,'PYG',%s,%s,%s,'OPEN',%s)",(pool_id,group_id,texto(request.form.get('name'),120),target,due,datetime.now()))
    return '/vaquitas/'+pool_id


@gestion.route('/vaquitas/<pool_id>')
def detalle_vaquita(pool_id):
    from avanzado import obtener_cuentas
    cn=obtener_conexion();cur=cn.cursor(dictionary=True)
    try:
        pool=vaquita_propia(cur,pool_id);group=grupo_propio(cur,pool['group_id'])
        balance=saldo_vaquita(cur,pool_id);mine=saldo_vaquita(cur,pool_id,usuario())
        members=consultar(cur,'SELECT u.id,u.full_name FROM group_members gm JOIN users u ON u.id=gm.user_id WHERE gm.group_id=%s ORDER BY u.id',(pool['group_id'],))
        for member in members:member['share']=saldo_vaquita(cur,pool_id,member['id'])
        history=consultar(cur,'''SELECT ft.id,ft.occurred_at,ft.description,ft.voided_at,pc.amount,u.full_name,ft.user_id FROM pool_contributions pc
 JOIN financial_transactions ft ON ft.id=pc.transaction_id JOIN users u ON u.id=pc.member_user_id WHERE pc.pool_id=%s
 UNION ALL SELECT ft.id,ft.occurred_at,pe.description,ft.voided_at,-pe.amount,u.full_name,ft.user_id FROM pool_expenses pe
 JOIN financial_transactions ft ON ft.id=pe.transaction_id JOIN users u ON u.id=pe.paid_by_user_id WHERE pe.pool_id=%s ORDER BY occurred_at DESC''',(pool_id,pool_id))
        return render_template('vaquita_detalle.html',pool=pool,grupo=group,balance=balance,mine=mine,members=members,history=history,cuentas=obtener_cuentas(),today=date.today().isoformat())
    except ValueError:
        abort(404,description='No se encontró la vaquita solicitada.')
    finally:cur.close();cn.close()


@gestion.route('/vaquitas/<pool_id>/aportar',methods=['POST'])
@escritura('/grupos')
def aportar_vaquita(cur,pool_id):
    pool=vaquita_propia(cur,pool_id)
    if pool['status']!='OPEN':raise ValueError('La vaquita está cerrada.')
    amount=dinero(request.form.get('amount'));withdraw=request.form.get('action')=='withdraw'
    account=request.form.get('account_id');on=fecha(request.form.get('occurred_at'))
    if on>date.today():raise ValueError('La fecha no puede ser futura.')
    cuenta_propia(cur,account,usuario(),None if withdraw else amount)
    if withdraw and amount>min(saldo_vaquita(cur,pool_id),saldo_vaquita(cur,pool_id,usuario())):
        raise ValueError('El retiro supera su participación disponible en la vaquita.')
    tx=transaccion(cur,usuario(),'POOL_CONTRIBUTION',on,('Retiro' if withdraw else 'Aporte')+' · '+pool['name'])
    cur.execute('INSERT INTO pool_contributions (id,pool_id,member_user_id,transaction_id,amount) VALUES (%s,%s,%s,%s,%s)',(uid(),pool_id,usuario(),tx,-amount if withdraw else amount))
    asiento(cur,tx,account,amount if withdraw else -amount)
    return '/vaquitas/'+pool_id


@gestion.route('/vaquitas/<pool_id>/gastar',methods=['POST'])
@escritura('/grupos')
def gastar_vaquita(cur,pool_id):
    pool=vaquita_propia(cur,pool_id,True)
    if pool['status']!='OPEN':raise ValueError('La vaquita está cerrada.')
    amount=dinero(request.form.get('amount'));description=texto(request.form.get('description'),255,'La descripción')
    on=fecha(request.form.get('occurred_at'))
    if on>date.today() or amount>saldo_vaquita(cur,pool_id):raise ValueError('La fecha es futura o el gasto supera el fondo disponible.')
    members=consultar(cur,'SELECT user_id FROM group_members WHERE group_id=%s ORDER BY user_id',(pool['group_id'],))
    participants=request.form.getlist('participants')
    participants=sorted(set(participants))
    if not participants or not set(participants).issubset({m['user_id'] for m in members}):raise ValueError('Seleccione participantes del grupo.')
    quota=(amount/len(participants)).quantize(CENTAVO)
    shares=[quota]*(len(participants)-1)+[amount-quota*(len(participants)-1)]
    if min(shares)<=0:raise ValueError('El monto es demasiado pequeño para repartirlo entre esos participantes.')
    tx=transaccion(cur,usuario(),'POOL_EXPENSE',on,description);expense_id=uid()
    cur.execute('INSERT INTO pool_expenses (id,pool_id,paid_by_user_id,transaction_id,description,amount) VALUES (%s,%s,%s,%s,%s,%s)',(expense_id,pool_id,usuario(),tx,description,amount))
    for person,part in zip(participants,shares):cur.execute('INSERT INTO pool_expense_shares (pool_expense_id,user_id,amount) VALUES (%s,%s,%s)',(expense_id,person,part))
    return '/vaquitas/'+pool_id


@gestion.route('/vaquitas/<pool_id>/estado',methods=['POST'])
@escritura('/grupos')
def estado_vaquita(cur,pool_id):
    vaquita_propia(cur,pool_id,True);status=request.form.get('status')
    if status not in {'OPEN','CLOSED'}:raise ValueError('Seleccione un estado válido.')
    if status=='CLOSED' and saldo_vaquita(cur,pool_id):raise ValueError('Retire o utilice el saldo restante antes de cerrar la vaquita.')
    cur.execute('UPDATE pools SET status=%s WHERE id=%s',(status,pool_id))
    return '/vaquitas/'+pool_id


@gestion.route('/reportes')
def reportes():
    start=request.args.get('start') or date.today().replace(day=1).isoformat()
    end=request.args.get('end') or date.today().isoformat()
    try:
        first,last=fecha(start),fecha(end)
        if last<first:raise ValueError('Revise el intervalo de fechas.')
        rows=movimientos(usuario(),{**request.args,'start':start,'end':end})
        events=eventos(usuario(),first,last+timedelta(days=1))
        income=sum((e['amount'] for e in events if e['kind']=='income'),CERO)
        expense=sum((e['amount'] for e in events if e['kind']=='expense'),CERO)
        by_category={}
        for event in events:
            key=(event['kind'],event['category']);by_category[key]=by_category.get(key,CERO)+event['amount']
    except ValueError as error:
        flash(str(error),'error');rows=[];income=expense=CERO;by_category={}
    return render_template('reportes.html',movimientos=rows,start=start,end=end,income=income,expense=expense,by_category=by_category)


def exportar_filas():
    return movimientos(usuario(),request.args)


@gestion.route('/reportes.csv')
def reporte_csv():
    try:rows=exportar_filas()
    except ValueError as error:abort(400,description=str(error))
    buffer=io.StringIO(newline='');writer=csv.writer(buffer,delimiter=';')
    writer.writerow(['Fecha','Tipo','Descripción','Categoría','Importe PYG','Estado'])
    def safe(value):
        text=str(value or '')
        return "'"+text if text.lstrip().startswith(('=','+','-','@','\t','\r')) else text
    for row in rows:
        writer.writerow([row['occurred_at'].isoformat(),TIPOS.get(row['type'],row['type']),safe(row['description']),safe(row['category']),str(row['amount']), 'Anulado' if row['voided_at'] else 'Vigente'])
    return Response('\ufeff'+buffer.getvalue(),mimetype='text/csv; charset=utf-8',headers={'Content-Disposition':'attachment; filename=movimientos.csv'})


@gestion.route('/reportes.pdf')
def reporte_pdf():
    from pathlib import Path
    from xml.sax.saxutils import escape
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, LongTable, TableStyle
    try:rows=exportar_filas()
    except ValueError as error:abort(400,description=str(error))
    font=Path('C:/Windows/Fonts/segoeui.ttf')
    if font.exists() and 'SegoeUI' not in pdfmetrics.getRegisteredFontNames():pdfmetrics.registerFont(TTFont('SegoeUI',str(font)))
    family='SegoeUI' if font.exists() else 'Helvetica'
    styles=getSampleStyleSheet()
    for style in styles.byName.values():style.fontName=family
    styles['BodyText'].fontSize=8
    out=io.BytesIO();doc=SimpleDocTemplate(out,pagesize=landscape(A4),rightMargin=28,leftMargin=28,topMargin=30,bottomMargin=30)
    story=[Paragraph('Finanzas personales · Movimientos',styles['Title']),Paragraph(escape(g.profile['full_name'])+' · '+date.today().strftime('%d/%m/%Y'),styles['Normal']),Spacer(1,16)]
    table=[['Fecha','Tipo','Descripción','Categoría','Importe PYG','Estado']]
    for row in rows:
        table.append([row['occurred_at'].strftime('%d/%m/%Y'),Paragraph(escape(TIPOS.get(row['type'],row['type'])),styles['BodyText']),Paragraph(escape(row['description'] or 'Sin descripción'),styles['BodyText']),Paragraph(escape(row['category'] or '—'),styles['BodyText']),f"{row['amount']:,.2f}",'Anulado' if row['voided_at'] else 'Vigente'])
    if not rows:story.append(Paragraph('No hay movimientos para los filtros seleccionados.',styles['Normal']))
    else:
        result=LongTable(table,colWidths=[66,106,253,142,120,74],repeatRows=1,hAlign='LEFT')
        result.setStyle(TableStyle([('FONTNAME',(0,0),(-1,-1),family),('FONTSIZE',(0,0),(-1,-1),8),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e7f0ec')),('TEXTCOLOR',(0,0),(-1,0),colors.HexColor('#163c30')),('VALIGN',(0,0),(-1,-1),'TOP'),('ALIGN',(-2,1),(-2,-1),'RIGHT'),('BOTTOMPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),8),('LINEBELOW',(0,0),(-1,0),0.5,colors.HexColor('#8fa99f')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f7f9f8')])]))
        story.append(result)
    doc.build(story)
    return Response(out.getvalue(),mimetype='application/pdf',headers={'Content-Disposition':'attachment; filename=movimientos.pdf'})


def auditar(cur,tx,action,snapshot,reversal=None):
    cur.execute('INSERT INTO transaction_audit (id,transaction_id,user_id,action,snapshot,reversal_transaction_id) VALUES (%s,%s,%s,%s,%s,%s)',
                (uid(),tx,usuario(),action,json.dumps(snapshot,ensure_ascii=False,default=str),reversal))


@gestion.route('/movimientos/<tx_id>/anular',methods=['POST'])
@escritura('/historial')
def anular_movimiento(cur,tx_id):
    tx=consultar(cur,'SELECT * FROM financial_transactions WHERE id=%s AND user_id=%s AND voided_at IS NULL FOR UPDATE',(tx_id,usuario()),True)
    if not tx or tx['type']=='ADJUSTMENT':raise ValueError('Ese movimiento no está disponible para anular.')
    if request.form.get('revision') and request.form['revision']!=str(tx['revision']):
        raise ValueError('El movimiento cambió desde que abrió la página. Recargue antes de continuar.')
    if tx['type']=='EXPENSE' and consultar(cur,'SELECT r.transaction_id FROM refunds r JOIN financial_transactions ft ON ft.id=r.transaction_id WHERE r.expense_transaction_id=%s AND ft.voided_at IS NULL LIMIT 1',(tx_id,),True):
        raise ValueError('Anule primero los reintegros asociados a este gasto.')
    repayment=consultar(cur,'SELECT * FROM debt_payments WHERE transaction_id=%s',(tx_id,),True)
    if repayment and consultar(cur,'''SELECT dp.id FROM debt_payments dp JOIN financial_transactions ft ON ft.id=dp.transaction_id
 WHERE dp.debt_id=%s AND ft.voided_at IS NULL AND dp.payment_order>%s LIMIT 1''',(repayment['debt_id'],repayment['payment_order']),True):
        raise ValueError('Anule primero los pagos posteriores de esta deuda para conservar la imputación correcta de intereses y capital.')
    debt=consultar(cur,'SELECT * FROM debts WHERE disbursement_transaction_id=%s',(tx_id,),True)
    if debt:
        if consultar(cur,'SELECT dp.id FROM debt_payments dp JOIN financial_transactions ft ON ft.id=dp.transaction_id WHERE dp.debt_id=%s AND ft.voided_at IS NULL LIMIT 1',(debt['id'],),True):
            raise ValueError('Anule primero los pagos de este préstamo.')
        cur.execute("UPDATE debts SET status='CANCELLED' WHERE id=%s",(debt['id'],))
    contribution=consultar(cur,'SELECT * FROM pool_contributions WHERE transaction_id=%s',(tx_id,),True)
    if contribution:
        vaquita_propia(cur,contribution['pool_id'])
        if contribution['amount']>0 and contribution['amount']>min(saldo_vaquita(cur,contribution['pool_id']),saldo_vaquita(cur,contribution['pool_id'],usuario())):
            raise ValueError('No se puede anular un aporte ya utilizado. Anule primero el gasto de la vaquita o retire sólo su saldo disponible.')
    shared=consultar(cur,'SELECT * FROM pool_expenses WHERE transaction_id=%s',(tx_id,),True)
    if shared:vaquita_propia(cur,shared['pool_id'],True)
    entries=consultar(cur,'SELECT * FROM account_entries WHERE transaction_id=%s',(tx_id,))
    reason=texto(request.form.get('reason') or 'Anulación solicitada por el usuario',255,'El motivo')
    reverse=transaccion(cur,usuario(),'ADJUSTMENT',date.today(),'Contrapartida de '+tx_id)
    for entry in entries:asiento(cur,reverse,entry['account_id'],-entry['amount'])
    auditar(cur,tx_id,'VOID',{'transaction':tx,'entries':entries,'reason':reason},reverse)
    cur.execute('UPDATE financial_transactions SET voided_at=%s,void_reason=%s,revision=revision+1 WHERE id=%s',(datetime.now(),reason,tx_id))
    cur.execute("UPDATE bills SET status=IF(due_on<CURDATE(),'OVERDUE','PENDING'),paid_expense_transaction_id=NULL WHERE paid_expense_transaction_id=%s",(tx_id,))
    payment=consultar(cur,'SELECT debt_id FROM debt_payments WHERE transaction_id=%s',(tx_id,),True)
    if payment:cur.execute("UPDATE debts SET status='OPEN' WHERE id=%s",(payment['debt_id'],))
    charges=consultar(cur,'''SELECT cc.id FROM credit_card_charges cc LEFT JOIN expense_payments ep ON ep.id=cc.expense_payment_id
 LEFT JOIN debt_payment_sources ds ON ds.id=cc.debt_payment_source_id LEFT JOIN debt_payments dp ON dp.id=ds.debt_payment_id
 WHERE ep.expense_transaction_id=%s OR dp.transaction_id=%s''',(tx_id,tx_id))
    for charge in charges:
        cur.execute("UPDATE card_installments ci JOIN installment_plans ip ON ip.id=ci.installment_plan_id SET ci.status='CANCELLED' WHERE ip.credit_card_charge_id=%s",(charge['id'],))
    for card in consultar(cur,'SELECT id FROM credit_cards WHERE user_id=%s',(usuario(),)):estado_ciclos(cur,card['id'],actualizar=True)
    return '/movimientos/'+tx_id


@gestion.route('/deudas/<debt_id>/cancelar',methods=['POST'])
@escritura('/deudas')
def cancelar_deuda(cur,debt_id):
    debt=estado_deuda(cur,debt_id,usuario(),bloquear=True)
    if debt['disbursement_transaction_id']:
        raise ValueError('Este préstamo tiene una entrega registrada. Anule su movimiento desde el historial para conservar la contrapartida.')
    if consultar(cur,'SELECT dp.id FROM debt_payments dp JOIN financial_transactions ft ON ft.id=dp.transaction_id WHERE dp.debt_id=%s AND ft.voided_at IS NULL LIMIT 1',(debt_id,),True):
        raise ValueError('Anule primero los pagos asociados a esta deuda.')
    cur.execute("UPDATE debts SET status='CANCELLED' WHERE id=%s",(debt_id,))
    return '/deudas'


@gestion.route('/movimientos/<tx_id>/editar')
def formulario_editar(tx_id):
    from avanzado import obtener_cuentas,obtener_categorias
    tx=datos('SELECT * FROM financial_transactions WHERE id=%s AND user_id=%s AND voided_at IS NULL',(tx_id,usuario()),True)
    if not tx:abort(404,description='El movimiento no está disponible.')
    detail=datos('SELECT * FROM incomes WHERE transaction_id=%s',(tx_id,),True) if tx['type']=='INCOME' else datos('SELECT * FROM expenses WHERE transaction_id=%s',(tx_id,),True)
    transfer=datos('SELECT * FROM transfers WHERE transaction_id=%s',(tx_id,),True)
    entries=datos('SELECT ae.*,a.name FROM account_entries ae JOIN accounts a ON a.id=ae.account_id WHERE ae.transaction_id=%s',(tx_id,))
    pays=datos('SELECT ep.*,COALESCE(a.name,da.name,cc.name) source_name FROM expense_payments ep LEFT JOIN accounts a ON a.id=ep.account_id LEFT JOIN debit_cards dc ON dc.id=ep.debit_card_id LEFT JOIN accounts da ON da.id=dc.account_id LEFT JOIN credit_cards cc ON cc.id=ep.credit_card_id WHERE ep.expense_transaction_id=%s ORDER BY ep.id',(tx_id,))
    accounts=datos('SELECT id,name,status FROM accounts WHERE user_id=%s ORDER BY status,name',(usuario(),))
    categories=datos('SELECT * FROM categories WHERE kind=%s AND (user_id IS NULL OR user_id=%s) ORDER BY is_active DESC,name',('INCOME' if tx['type']=='INCOME' else 'EXPENSE',usuario()))
    return render_template('movimiento_editar.html',tx=tx,detail=detail,transfer=transfer,entries=entries,payments=pays,cuentas=accounts,categorias=categories)


@gestion.route('/movimientos/<tx_id>/editar',methods=['POST'])
@escritura('/historial')
def editar_movimiento(cur,tx_id):
    tx=consultar(cur,'SELECT * FROM financial_transactions WHERE id=%s AND user_id=%s AND voided_at IS NULL FOR UPDATE',(tx_id,usuario()),True)
    if not tx or tx['type']=='ADJUSTMENT':raise ValueError('Ese movimiento no se puede editar.')
    if str(tx['revision'])!=request.form.get('revision'):raise ValueError('El movimiento fue modificado. Recargue la página para evitar sobrescribir cambios.')
    description=(request.form.get('description') or '').strip()
    if len(description)>255:raise ValueError('La descripción admite hasta 255 caracteres.')
    editable=tx['type'] in {'INCOME','EXPENSE','TRANSFER','INITIAL_BALANCE'}
    on=fecha(request.form.get('occurred_at')) if editable else tx['occurred_at'].date()
    if on>date.today():raise ValueError('La fecha no puede ser futura.')
    entries=consultar(cur,'SELECT * FROM account_entries WHERE transaction_id=%s ORDER BY id',(tx_id,))
    snapshot={'transaction':tx,'entries':entries}
    if tx['type'] in {'INCOME','INITIAL_BALANCE'}:
        amount=dinero(request.form.get('amount'),positivo=tx['type']=='INCOME')
        if not amount:raise ValueError('El saldo inicial no puede ser cero. Puede anular el movimiento.')
        if len(entries)!=1:raise ValueError('Este movimiento necesita revisión porque tiene varios asientos.')
        account=request.form.get('account_id')
        if account!=entries[0]['account_id'] or amount!=entries[0]['amount']:
            cuenta_propia(cur,account,usuario())
        if tx['type']=='INCOME':
            category=consultar(cur,"SELECT id FROM categories WHERE id=%s AND kind='INCOME' AND (user_id IS NULL OR user_id=%s)",(request.form.get('category_id'),usuario()),True)
            if not category:raise ValueError('Seleccione una categoría de ingreso propia o del sistema.')
            snapshot['income']=consultar(cur,'SELECT * FROM incomes WHERE transaction_id=%s',(tx_id,),True)
            cur.execute('UPDATE incomes SET amount=%s,category_id=%s WHERE transaction_id=%s',(amount,category['id'],tx_id))
        cur.execute('UPDATE account_entries SET account_id=%s,amount=%s WHERE id=%s',(account,amount,entries[0]['id']))
    elif tx['type']=='TRANSFER':
        amount=dinero(request.form.get('amount'));source=request.form.get('source_account_id');dest=request.form.get('destination_account_id')
        if source==dest:raise ValueError('Seleccione dos cuentas distintas.')
        old=consultar(cur,'SELECT * FROM transfers WHERE transaction_id=%s',(tx_id,),True);snapshot['transfer']=old
        if source!=old['source_account_id'] or dest!=old['destination_account_id'] or amount!=old['amount']:
            deltas={}
            for account,value in [(source,-amount),(dest,amount),(old['source_account_id'],old['amount']),(old['destination_account_id'],-old['amount'])]:
                deltas[account]=deltas.get(account,CERO)+value
            for account,delta in sorted(deltas.items()):cuenta_propia(cur,account,usuario(),max(CERO,-delta))
        if len(entries)!=2:raise ValueError('Revise los asientos de esta transferencia antes de editarla.')
        for entry in entries:
            outgoing=entry['amount']<0
            cur.execute('UPDATE account_entries SET account_id=%s,amount=%s WHERE id=%s',(source if outgoing else dest,-amount if outgoing else amount,entry['id']))
        cur.execute('UPDATE transfers SET source_account_id=%s,destination_account_id=%s,amount=%s WHERE transaction_id=%s',(source,dest,amount,tx_id))
    elif tx['type']=='EXPENSE':
        original=consultar(cur,'SELECT * FROM expenses WHERE transaction_id=%s',(tx_id,),True);snapshot['expense']=original
        payments=consultar(cur,'SELECT ep.*,dc.account_id debit_account FROM expense_payments ep LEFT JOIN debit_cards dc ON dc.id=ep.debit_card_id WHERE ep.expense_transaction_id=%s ORDER BY ep.id',(tx_id,))
        snapshot['payments']=payments
        ids=request.form.getlist('payment_id');amounts=[dinero(x) for x in request.form.getlist('payment_amount')]
        if ids!=[p['id'] for p in payments] or len(amounts)!=len(ids):raise ValueError('Los medios de pago cambiaron. Recargue el formulario.')
        total=sum(amounts,CERO)
        changed=total!=original['total_amount'] or on!=tx['occurred_at'].date() or any(p['amount']!=a for p,a in zip(payments,amounts))
        if changed and consultar(cur,'SELECT r.transaction_id FROM refunds r JOIN financial_transactions ft ON ft.id=r.transaction_id WHERE r.expense_transaction_id=%s AND ft.voided_at IS NULL LIMIT 1',(tx_id,),True):
            raise ValueError('Anule primero los reintegros para cambiar el importe o la fecha del gasto.')
        category=consultar(cur,"SELECT id FROM categories WHERE id=%s AND kind='EXPENSE' AND (user_id IS NULL OR user_id=%s)",(request.form.get('category_id'),usuario()),True)
        if not category:raise ValueError('Seleccione una categoría válida.')
        account_totals={}
        for pay,amount in zip(payments,amounts):
            account=pay['account_id'] or pay['debit_account']
            if account and changed:
                account_totals[account]=account_totals.get(account,CERO)+amount
            if pay['credit_card_id'] and changed:
                charge=consultar(cur,'SELECT * FROM credit_card_charges WHERE expense_payment_id=%s',(pay['id'],),True)
                plan=consultar(cur,'SELECT * FROM installment_plans WHERE credit_card_charge_id=%s',(charge['id'],),True)
                related=consultar(cur,"SELECT cy.closed_at,ci.status FROM card_installments ci JOIN credit_card_cycles cy ON cy.id=ci.credit_card_cycle_id WHERE ci.installment_plan_id=%s",(plan['id'],)) if plan else []
                old_cycle=consultar(cur,'SELECT closed_at FROM credit_card_cycles WHERE id=%s',(charge['initial_cycle_id'],),True)
                if (old_cycle and old_cycle['closed_at']) or any(c['closed_at'] or c['status']=='PAID' for c in related):
                    raise ValueError('El gasto tiene un ciclo cerrado o cuotas pagadas. Puede editar su descripción/categoría, o anularlo con una contrapartida.')
                first=ciclo(cur,pay['credit_card_id'],on)
                if first['closed_at']:raise ValueError('La nueva fecha pertenece a un ciclo cerrado.')
                old_financed=plan['financed_total'] if plan else charge['principal_amount']
                new_financed=dinero(amount*(1+plan['periodic_interest_rate']*plan['installment_count'])) if plan else amount
                card=consultar(cur,'SELECT credit_limit FROM credit_cards WHERE id=%s',(pay['credit_card_id'],),True)
                if saldo_credito(cur,pay['credit_card_id'])-old_financed+new_financed>card['credit_limit']:
                    raise ValueError('El nuevo importe supera el crédito disponible.')
                cur.execute('UPDATE credit_card_charges SET principal_amount=%s,initial_cycle_id=%s WHERE id=%s',(amount,first['id'],charge['id']))
                if plan:
                    quota=(new_financed/plan['installment_count']).quantize(CENTAVO)
                    parts=[quota]*(plan['installment_count']-1)+[new_financed-quota*(plan['installment_count']-1)]
                    if min(parts)<=0:raise ValueError('El importe es demasiado pequeño para esas cuotas.')
                    cur.execute('UPDATE installment_plans SET financed_total=%s,installment_amount=%s,first_due_on=%s WHERE id=%s',(new_financed,quota,first['due_on'],plan['id']))
                    quotas=consultar(cur,'SELECT id FROM card_installments WHERE installment_plan_id=%s ORDER BY installment_number',(plan['id'],))
                    current=first
                    for installment,part in zip(quotas,parts):
                        cur.execute('UPDATE card_installments SET due_amount=%s,credit_card_cycle_id=%s WHERE id=%s',(part,current['id'],installment['id']))
                        current=ciclo(cur,pay['credit_card_id'],current['closes_on']+timedelta(days=1))
            cur.execute('UPDATE expense_payments SET amount=%s WHERE id=%s',(amount,pay['id']))
        for account,total_amount in account_totals.items():
            grouped=[e for e in entries if e['account_id']==account]
            if not grouped:raise ValueError('Faltan asientos para uno de los medios de pago.')
            original_total=sum((-e['amount'] for e in grouped),CERO);remaining=total_amount
            cuenta_propia(cur,account,usuario(),max(CERO,total_amount-original_total))
            for index,entry in enumerate(grouped):
                part=(total_amount*(-entry['amount'])/original_total).quantize(CENTAVO) if index<len(grouped)-1 else remaining
                if part<=0:raise ValueError('El nuevo importe es demasiado pequeño para conservar la distribución de asientos.')
                remaining-=part
                cur.execute('UPDATE account_entries SET amount=%s WHERE id=%s',(-part,entry['id']))
        cur.execute('UPDATE expenses SET total_amount=%s,category_id=%s,merchant=%s WHERE transaction_id=%s',(total,category['id'],description[:150] or None,tx_id))
        cur.execute('UPDATE bills SET amount=%s WHERE paid_expense_transaction_id=%s',(total,tx_id))
    auditar(cur,tx_id,'EDIT',snapshot)
    cur.execute('UPDATE financial_transactions SET occurred_at=%s,description=%s,revision=revision+1 WHERE id=%s',(on,description or None,tx_id))
    return '/movimientos/'+tx_id
