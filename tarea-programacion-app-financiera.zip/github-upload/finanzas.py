"""Operaciones monetarias compartidas; todas reciben el cursor de la transacción."""
from calendar import monthrange
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from uuid import uuid4

CENTAVO = Decimal('0.01')
CERO = Decimal('0.00')


def uid():
    return str(uuid4())


def dinero(value, positivo=True):
    try:
        amount = Decimal(str(value).replace(',', '.'))
        if not amount.is_finite() or abs(amount) >= Decimal('10000000000000000'):
            raise ValueError
        amount = amount.quantize(CENTAVO, rounding=ROUND_HALF_UP)
        if positivo and amount <= 0:
            raise ValueError
        return amount
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError('Ingrese un monto válido mayor que cero, con hasta dos decimales.')


def tasa(value):
    try:
        result = Decimal(str(value or '0').replace(',', '.'))
        if not result.is_finite() or not 0 <= result <= 999:
            raise ValueError
        return result.quantize(Decimal('0.000001'))
    except (InvalidOperation, ValueError):
        raise ValueError('La tasa anual debe estar entre 0 y 999 %.')


def fecha(value):
    try:
        return date.fromisoformat(str(value))
    except (ValueError, TypeError):
        raise ValueError('Ingrese una fecha válida.')


def texto(value, limite, nombre='El nombre'):
    result = str(value or '').strip()
    if not result or len(result) > limite:
        raise ValueError(f'{nombre} es obligatorio y admite hasta {limite} caracteres.')
    return result


def fila(cur):
    row = cur.fetchone()
    return row if row is None or isinstance(row, dict) else dict(zip(cur.column_names, row))


def filas(cur):
    rows = cur.fetchall()
    return [r if isinstance(r, dict) else dict(zip(cur.column_names, r)) for r in rows]


def consultar(cur, sql, params=(), uno=False):
    cur.execute(sql, params)
    return fila(cur) if uno else filas(cur)


def sumar_meses(day, count, anchor=None):
    index = day.year * 12 + day.month - 1 + count
    year, month = divmod(index, 12)
    month += 1
    return date(year, month, min(anchor or day.day, monthrange(year, month)[1]))


def transaccion(cur, user, kind, amount_date, description, currency='PYG'):
    tx = uid()
    cur.execute('INSERT INTO financial_transactions (id,user_id,currency_code,type,occurred_at,description,created_at) VALUES (%s,%s,%s,%s,%s,%s,%s)',
                (tx, user, currency, kind, amount_date, str(description or '')[:255] or None, datetime.now()))
    return tx


def asiento(cur, tx, account, amount):
    if amount:
        cur.execute('INSERT INTO account_entries (id,transaction_id,account_id,amount,created_at) VALUES (%s,%s,%s,%s,%s)',
                    (uid(), tx, account, amount, datetime.now()))


def cuenta_propia(cur, account, user, salida=None):
    row = consultar(cur, "SELECT * FROM accounts WHERE id=%s AND user_id=%s AND status='ACTIVE' FOR UPDATE", (account, user), True)
    if not row:
        raise ValueError('Seleccione una cuenta activa propia.')
    if row['currency_code'] != 'PYG':
        raise ValueError('Esta versión registra operaciones en guaraníes; no realiza conversiones de moneda.')
    if salida and row['type'] != 'CASH':
        balance = consultar(cur, 'SELECT COALESCE(SUM(amount),0) n FROM account_entries WHERE account_id=%s', (account,), True)['n']
        reserved = consultar(cur, 'SELECT COALESCE(SUM(gr.amount_delta),0) n FROM goal_reservations gr JOIN saving_goals sg ON sg.id=gr.saving_goal_id WHERE sg.account_id=%s AND sg.is_active=TRUE', (account,), True)['n']
        if salida > balance - reserved:
            raise ValueError('La cuenta no tiene saldo disponible suficiente. Revise sus reservas o utilice Efectivo si hay dinero por reponer.')
    return row


def ciclo(cur, card_id, on=None):
    on = on or date.today()
    if isinstance(on, datetime):
        on = on.date()
    card = consultar(cur, 'SELECT * FROM credit_cards WHERE id=%s FOR UPDATE', (card_id,), True)
    if not card or not 1 <= card['closing_day'] <= 31 or not 1 <= card['due_day'] <= 31:
        raise ValueError('Revise los días de cierre y vencimiento de la tarjeta.')
    close = date(on.year, on.month, min(card['closing_day'], monthrange(on.year, on.month)[1]))
    if on > close:
        close = sumar_meses(close, 1, card['closing_day'])
    start = sumar_meses(close, -1, card['closing_day']) + timedelta(days=1)
    due = date(close.year, close.month, min(card['due_day'], monthrange(close.year, close.month)[1]))
    if due <= close:
        due = sumar_meses(due, 1, card['due_day'])
    existing = consultar(cur, 'SELECT * FROM credit_card_cycles WHERE credit_card_id=%s AND closes_on=%s', (card_id, close), True)
    if existing:
        return existing
    cycle_id = uid()
    cur.execute('INSERT INTO credit_card_cycles (id,credit_card_id,starts_on,closes_on,due_on,minimum_payment) VALUES (%s,%s,%s,%s,%s,0)',
                (cycle_id, card_id, start, close, due))
    return {'id': cycle_id, 'credit_card_id': card_id, 'starts_on': start, 'closes_on': close, 'due_on': due, 'closed_at': None}


# Las fuentes se enlazan al movimiento real para excluir anulaciones sin borrar su historial.
CARGOS = '''FROM credit_card_charges cc
 LEFT JOIN expense_payments ep ON ep.id=cc.expense_payment_id
 LEFT JOIN debt_payment_sources ds ON ds.id=cc.debt_payment_source_id
 LEFT JOIN debt_payments dp ON dp.id=ds.debt_payment_id
 JOIN financial_transactions ft ON ft.id=COALESCE(ep.expense_transaction_id,dp.transaction_id)
 LEFT JOIN installment_plans ip ON ip.credit_card_charge_id=cc.id
 WHERE COALESCE(ep.credit_card_id,ds.credit_card_id)=%s AND ft.voided_at IS NULL'''


def saldo_credito(cur, card_id):
    charges = consultar(cur, 'SELECT COALESCE(SUM(COALESCE(ip.financed_total,cc.principal_amount)),0) n ' + CARGOS, (card_id,), True)['n']
    payments = consultar(cur, 'SELECT COALESCE(SUM(cp.amount),0) n FROM credit_card_payments cp JOIN financial_transactions ft ON ft.id=cp.transaction_id WHERE cp.credit_card_id=%s AND ft.voided_at IS NULL', (card_id,), True)['n']
    interests = consultar(cur, 'SELECT COALESCE(SUM(ci.amount),0) n FROM credit_card_interests ci JOIN financial_transactions ft ON ft.id=ci.transaction_id WHERE ci.credit_card_id=%s AND ft.voided_at IS NULL', (card_id,), True)['n']
    refunds = consultar(cur, 'SELECT COALESCE(SUM(ra.amount),0) n FROM refund_allocations ra JOIN financial_transactions ft ON ft.id=ra.refund_transaction_id WHERE ra.credit_card_id=%s AND ft.voided_at IS NULL', (card_id,), True)['n']
    return charges + interests - payments - refunds


def crear_cargo(cur, user, card_id, amount, on, expense_payment=None, debt_source=None, count=1, sin_interes=False):
    card = consultar(cur, "SELECT * FROM credit_cards WHERE id=%s AND user_id=%s AND status='ACTIVE' FOR UPDATE", (card_id, user), True)
    if not card or card['currency_code'] != 'PYG':
        raise ValueError('Seleccione una tarjeta activa propia en guaraníes.')
    try:
        count = int(count)
    except (TypeError, ValueError):
        raise ValueError('Ingrese una cantidad de cuotas válida.')
    if not 1 <= count <= 120:
        raise ValueError('La cantidad de cuotas debe estar entre 1 y 120.')
    monthly = CERO if sin_interes or count == 1 else (tasa(card['annual_interest_rate']) / Decimal(1200)).quantize(Decimal('0.000001'))
    financed = dinero(amount * (1 + monthly * count))
    if financed + saldo_credito(cur, card_id) > card['credit_limit']:
        raise ValueError('El importe financiado supera el crédito disponible de la tarjeta.')
    first = ciclo(cur, card_id, on)
    if first['closed_at']:
        raise ValueError('El ciclo de esa fecha ya está cerrado. Seleccione una fecha de un ciclo abierto.')
    charge = uid()
    kind = 'ONE_TIME' if count == 1 else ('INSTALLMENT_WITH_INTEREST' if monthly else 'INSTALLMENT_NO_INTEREST')
    cur.execute('INSERT INTO credit_card_charges (id,expense_payment_id,debt_payment_source_id,initial_cycle_id,financing_type,principal_amount,created_at) VALUES (%s,%s,%s,%s,%s,%s,%s)',
                (charge, expense_payment, debt_source, first['id'], kind, amount, datetime.now()))
    if count > 1:
        plan = uid()
        quota = (financed / count).quantize(CENTAVO, rounding=ROUND_HALF_UP)
        if quota <= 0:
            raise ValueError('El monto es demasiado pequeño para esa cantidad de cuotas.')
        cur.execute('INSERT INTO installment_plans (id,credit_card_charge_id,installment_count,periodic_interest_rate,financed_total,installment_amount,first_due_on) VALUES (%s,%s,%s,%s,%s,%s,%s)',
                    (plan, charge, count, monthly, financed, quota, first['due_on']))
        current = first
        for number in range(1, count + 1):
            part = quota if number < count else financed - quota * (count - 1)
            if part <= 0:
                raise ValueError('El monto es demasiado pequeño para distribuirlo en esas cuotas.')
            cur.execute("INSERT INTO card_installments (id,installment_plan_id,credit_card_cycle_id,installment_number,due_amount,status) VALUES (%s,%s,%s,%s,%s,'PENDING')",
                        (uid(), plan, current['id'], number, part))
            if number < count:
                current = ciclo(cur, card_id, current['closes_on'] + timedelta(days=1))
    return charge


def importe_ciclo(cur, cycle_id):
    row = consultar(cur, 'SELECT credit_card_id FROM credit_card_cycles WHERE id=%s', (cycle_id,), True)
    if not row:
        raise ValueError('El ciclo no existe.')
    params = (row['credit_card_id'], cycle_id)
    direct = consultar(cur, 'SELECT COALESCE(SUM(cc.principal_amount),0) n ' + CARGOS + ' AND ip.id IS NULL AND cc.initial_cycle_id=%s', params, True)['n']
    installments = consultar(cur, '''SELECT COALESCE(SUM(ci.due_amount),0) n FROM card_installments ci
 JOIN installment_plans ip ON ip.id=ci.installment_plan_id JOIN credit_card_charges cc ON cc.id=ip.credit_card_charge_id
 LEFT JOIN expense_payments ep ON ep.id=cc.expense_payment_id LEFT JOIN debt_payment_sources ds ON ds.id=cc.debt_payment_source_id
 LEFT JOIN debt_payments dp ON dp.id=ds.debt_payment_id JOIN financial_transactions ft ON ft.id=COALESCE(ep.expense_transaction_id,dp.transaction_id)
 WHERE ci.credit_card_cycle_id=%s AND ci.status<>'CANCELLED' AND ft.voided_at IS NULL''', (cycle_id,), True)['n']
    interest = consultar(cur, 'SELECT COALESCE(SUM(i.amount),0) n FROM credit_card_interests i JOIN financial_transactions ft ON ft.id=i.transaction_id WHERE i.credit_card_cycle_id=%s AND ft.voided_at IS NULL', (cycle_id,), True)['n']
    # Los reintegros reducen primero los ciclos más próximos de la tarjeta.
    return direct + installments + interest


def estado_ciclos(cur, card_id, actualizar=False):
    cycles = consultar(cur, 'SELECT * FROM credit_card_cycles WHERE credit_card_id=%s ORDER BY closes_on,id', (card_id,))
    refund = consultar(cur, 'SELECT COALESCE(SUM(ra.amount),0) n FROM refund_allocations ra JOIN financial_transactions ft ON ft.id=ra.refund_transaction_id WHERE ra.credit_card_id=%s AND ft.voided_at IS NULL', (card_id,), True)['n']
    # Pagos antiguos sin asignaciones se incorporan al crédito disponible del ciclo más antiguo.
    legacy = consultar(cur, '''SELECT COALESCE(SUM(cp.amount),0) n FROM credit_card_payments cp
 JOIN financial_transactions ft ON ft.id=cp.transaction_id WHERE cp.credit_card_id=%s AND ft.voided_at IS NULL
 AND NOT EXISTS(SELECT 1 FROM card_payment_allocations a WHERE a.payment_transaction_id=cp.transaction_id)''', (card_id,), True)['n']
    credit = refund + legacy
    for item in cycles:
        item['charges'] = importe_ciclo(cur, item['id'])
        item['paid'] = consultar(cur, 'SELECT COALESCE(SUM(a.amount),0) n FROM card_payment_allocations a JOIN financial_transactions ft ON ft.id=a.payment_transaction_id WHERE a.cycle_id=%s AND ft.voided_at IS NULL', (item['id'],), True)['n']
        available = max(CERO, item['charges'] - item['paid'])
        adjustment = min(credit, available)
        credit -= adjustment
        item['pending'] = max(CERO, available - adjustment)
        item['credited'] = adjustment
        if actualizar:
            cuotas = consultar(cur, "SELECT id,due_amount,status FROM card_installments WHERE credit_card_cycle_id=%s AND status<>'CANCELLED' ORDER BY installment_number,id", (item['id'],))
            remaining_paid = max(CERO, item['paid'] + adjustment - (item['charges'] - sum((x['due_amount'] for x in cuotas), CERO)))
            for cuota in cuotas:
                covered = remaining_paid >= cuota['due_amount']
                status = 'PAID' if covered else ('BILLED' if item['closed_at'] else 'PENDING')
                if covered:
                    remaining_paid -= cuota['due_amount']
                cur.execute('UPDATE card_installments SET status=%s WHERE id=%s', (status, cuota['id']))
    return cycles


def pagar_credito(cur, user, card_id, account, amount, on, selected_cycle=None):
    card = consultar(cur, 'SELECT * FROM credit_cards WHERE id=%s AND user_id=%s FOR UPDATE', (card_id, user), True)
    if not card:
        raise ValueError('La tarjeta no existe o no le pertenece.')
    cuenta_propia(cur, account, user, amount)
    if amount > saldo_credito(cur, card_id):
        raise ValueError('El pago supera el saldo total de la tarjeta.')
    cycles = estado_ciclos(cur, card_id)
    if selected_cycle:
        selected = [c for c in cycles if c['id'] == selected_cycle]
        if not selected or amount > selected[0]['pending']:
            raise ValueError('El pago supera el pendiente del ciclo seleccionado.')
        cycles = selected
    tx = transaccion(cur, user, 'CARD_PAYMENT', on, 'Pago de tarjeta · ' + card['name'])
    cur.execute('INSERT INTO credit_card_payments (transaction_id,credit_card_id,credit_card_cycle_id,amount) VALUES (%s,%s,%s,%s)',
                (tx, card_id, selected_cycle, amount))
    remaining = amount
    for item in cycles:
        part = min(item['pending'], remaining)
        if part:
            cur.execute('INSERT INTO card_payment_allocations (payment_transaction_id,cycle_id,amount) VALUES (%s,%s,%s)', (tx, item['id'], part))
            remaining -= part
    if remaining:
        raise ValueError('Revise las asignaciones de los ciclos antes de registrar este pago.')
    asiento(cur, tx, account, -amount)
    estado_ciclos(cur, card_id, actualizar=True)
    return tx


def estado_deuda(cur, debt_id, user, on=None, bloquear=False):
    on = on or date.today()
    debt = consultar(cur, '''SELECT d.*,p.user_id debtor_user FROM debts d JOIN parties p ON p.id=d.debtor_party_id
 WHERE d.id=%s AND d.created_by_user_id=%s''' + (' FOR UPDATE' if bloquear else ''), (debt_id, user), True)
    if not debt:
        raise ValueError('La deuda no existe o no le pertenece.')
    payments = consultar(cur, '''SELECT dp.*,DATE(ft.occurred_at) payment_date FROM debt_payments dp
 JOIN financial_transactions ft ON ft.id=dp.transaction_id WHERE dp.debt_id=%s AND ft.voided_at IS NULL ORDER BY ft.occurred_at,dp.payment_order''', (debt_id,))
    principal, accrued, paid_interest = debt['original_amount'], CERO, CERO
    last = debt['issued_on']
    for pay in payments:
        if pay['payment_date'] > on:
            continue
        days = max(0, (pay['payment_date'] - last).days)
        accrued += principal * debt['annual_interest_rate'] / Decimal(36500) * days
        principal -= pay['principal_amount'] if pay['principal_amount'] is not None else pay['amount']
        paid_interest += pay['interest_amount']
        last = max(last, pay['payment_date'])
    accrued += principal * debt['annual_interest_rate'] / Decimal(36500) * max(0, (on - last).days)
    debt.update(principal=max(CERO, principal), interest=max(CERO, accrued.quantize(CENTAVO, rounding=ROUND_HALF_UP) - paid_interest),
                payable=debt['debtor_user'] == user, last_payment=max([p['payment_date'] for p in payments], default=debt['issued_on']))
    debt['pending'] = debt['principal'] + debt['interest']
    if debt['status'] in {'SETTLED', 'CANCELLED'}:
        debt.update(principal=CERO, interest=CERO, pending=CERO)
    return debt


def pagar_deuda(cur, user, debt_id, method, amount, on, count=1, sin_interes=False):
    debt = estado_deuda(cur, debt_id, user, on, bloquear=True)
    if debt['status'] != 'OPEN' or on < debt['last_payment'] or on > date.today() or amount > debt['pending']:
        raise ValueError('Revise el importe y la fecha: el pago debe ser posterior al último pago y no superar el saldo pendiente.')
    try:
        kind, source = method.split(':', 1)
    except (ValueError, AttributeError):
        raise ValueError('Seleccione un medio de pago.')
    account = debit = card = None
    if kind == 'ACCOUNT':
        account = source
        cuenta_propia(cur, account, user, amount if debt['payable'] else None)
    elif kind == 'DEBIT':
        dc = consultar(cur, "SELECT dc.* FROM debit_cards dc JOIN accounts a ON a.id=dc.account_id WHERE dc.id=%s AND a.user_id=%s AND dc.status='ACTIVE'", (source, user), True)
        if not dc or (dc['expires_on'] and dc['expires_on'] < on):
            raise ValueError('La tarjeta de débito no está disponible.')
        debit, account = source, dc['account_id']
        cuenta_propia(cur, account, user, amount if debt['payable'] else None)
    elif kind == 'CREDIT' and debt['payable']:
        card = source
    else:
        raise ValueError('Para un cobro utilice una cuenta o tarjeta de débito propia.')
    interest = min(amount, debt['interest'])
    principal = amount - interest
    tx = transaccion(cur, user, 'DEBT_PAYMENT', on, ('Pago' if debt['payable'] else 'Cobro') + ' de deuda · ' + (debt['description'] or 'Sin descripción'))
    dp, ds = uid(), uid()
    cur.execute('INSERT INTO debt_payments (id,debt_id,transaction_id,amount,principal_amount,interest_amount) VALUES (%s,%s,%s,%s,%s,%s)', (dp, debt_id, tx, amount, principal, interest))
    cur.execute('INSERT INTO debt_payment_sources (id,debt_payment_id,account_id,debit_card_id,credit_card_id,amount) VALUES (%s,%s,%s,%s,%s,%s)',
                (ds, dp, account if not debit else None, debit, card, amount))
    if card:
        crear_cargo(cur, user, card, amount, on, debt_source=ds, count=count, sin_interes=sin_interes)
    else:
        asiento(cur, tx, account, -amount if debt['payable'] else amount)
    if amount == debt['pending']:
        cur.execute("UPDATE debts SET status='SETTLED' WHERE id=%s", (debt_id,))
    return tx


def reintegrar(cur, user, expense_id, amount, on):
    original = consultar(cur, '''SELECT e.*,ft.occurred_at FROM expenses e JOIN financial_transactions ft ON ft.id=e.transaction_id
 WHERE e.transaction_id=%s AND ft.user_id=%s AND ft.voided_at IS NULL FOR UPDATE''', (expense_id, user), True)
    if not original or on < original['occurred_at'].date() or on > date.today():
        raise ValueError('Revise el gasto y la fecha del reintegro.')
    refunded = consultar(cur, 'SELECT COALESCE(SUM(r.amount),0) n FROM refunds r JOIN financial_transactions ft ON ft.id=r.transaction_id WHERE r.expense_transaction_id=%s AND ft.voided_at IS NULL', (expense_id,), True)['n']
    if amount > original['total_amount'] - refunded:
        raise ValueError('El reintegro supera el importe del gasto pendiente de devolver.')
    payments = consultar(cur, '''SELECT ep.*,dc.account_id debit_account FROM expense_payments ep
 LEFT JOIN debit_cards dc ON dc.id=ep.debit_card_id WHERE ep.expense_transaction_id=%s ORDER BY ep.id''', (expense_id,))
    tx = transaccion(cur, user, 'REFUND', on, 'Reintegro de gasto')
    cur.execute('INSERT INTO refunds (transaction_id,expense_transaction_id,amount) VALUES (%s,%s,%s)', (tx, expense_id, amount))
    remaining = amount
    for pay in payments:
        prior = consultar(cur, 'SELECT COALESCE(SUM(ra.amount),0) n FROM refund_allocations ra JOIN financial_transactions ft ON ft.id=ra.refund_transaction_id WHERE ra.expense_payment_id=%s AND ft.voided_at IS NULL', (pay['id'],), True)['n']
        part = min(remaining, pay['amount'] - prior)
        if part <= 0:
            continue
        account = pay['account_id'] or pay['debit_account']
        cur.execute('INSERT INTO refund_allocations (id,refund_transaction_id,expense_payment_id,account_id,credit_card_id,amount) VALUES (%s,%s,%s,%s,%s,%s)',
                    (uid(), tx, pay['id'], account, pay['credit_card_id'], part))
        if account:
            asiento(cur, tx, account, part)
        remaining -= part
    if remaining:
        raise ValueError('Los medios originales no alcanzan para registrar el reintegro.')
    for card_id in {p['credit_card_id'] for p in payments if p['credit_card_id']}:
        estado_ciclos(cur, card_id, actualizar=True)
    return tx
